import pandas as pd,numpy as np,warnings
warnings.filterwarnings('ignore')
import os
HERE=os.path.dirname(os.path.abspath(__file__))
U=os.path.join(HERE,'..','results')+os.sep
FILES=['study_results.csv','study_round2.csv','study_heavy.csv','study_round3.csv','study_achunk.csv']
def comp(r):
    num=den=0
    for dc in range(1,6):
        for t in ['v1L','v1H','v2L','v2H']:
            n=r.get(f'DC{dc}_{t}_n')
            if pd.notna(n) and n>0:
                num+=n*(r[f'DC{dc}_{t}_wait']+r[f'DC{dc}_{t}_exec']); den+=n
    return num/den if den else np.nan
def load():
    out=[]
    for f in FILES:
        d=pd.read_csv(U+f,low_memory=False); d['file']=f
        d['comp']=d.apply(comp,axis=1) if 'DC1_v1L_n' in d else np.nan
        out.append(d[['file','label','seed','RT_avg','DCPT_avg','comp','broker']+[c for c in ['group','tshare','userScale'] if c in d]])
    return pd.concat(out,ignore_index=True)
