import os,sys;HERE=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,HERE)
from cells import *
from scipy import stats
names={'A1 CDC':r'A, $1.0\times$, CDC','A1 ORT':r'A, $1.0\times$, ORT','A15 CDC':r'A, $1.5\times$, CDC','A15 ORT':r'A, $1.5\times$, ORT','B CDC':'B, CDC','B ORT':'B, ORT','C CDC':'C, CDC','C ORT':'C, ORT'}
ML=[('RT','RT_avg','RT'),('DCPT','DCPT_avg','DCPT'),('comp','comp','Compl.')]
out=[]
for si,s in enumerate(SET):
    for mi,(m,c,lab) in enumerate(ML):
        a,_=rows(s,'SAKMLB',m); cells=[]
        for al in ALGS:
            b,_=rows(s,al,m); v=b[c].mean(); t=f'{v:.1f}'
            if al!='SAKMLB':
                df=a[c].values-b[c].values; h=stats.t.ppf(.975,9)*df.std(ddof=1)/np.sqrt(10)
                if abs(df.mean())<=h: t+=r'$^{\circ}$'
            else: t=r'\textbf{'+t+'}'
            cells.append(t)
        first=(r'\multirow{3}{*}{'+names[s]+'}') if mi==0 else ''
        out.append(f'{first} & {lab} & '+' & '.join(cells)+r' \\')
    out.append(r'\midrule' if si<7 else '')
open(os.path.join(HERE,'out','tab9.tex'),'w').write('\n'.join(out))
print('\n'.join(out[:5]))
