import pandas as pd,numpy as np
import os,sys
sys.path.insert(0,os.path.dirname(os.path.abspath(__file__)))
from load import load
d=load()
ALGS=['RR','ESCEL','Throttled','ETLBA','ReT-ELBa','ESCEL+cap','SAKMLB']
SET=['A1 CDC','A1 ORT','A15 CDC','A15 ORT','B CDC','B ORT','C CDC','C ORT']
def lab(setting,alg,metric):
    t,b=setting.split(); 
    if t in('B','C'):
        k={'RR':'RR','ESCEL':'ESCEL','Throttled':'THROTTLED','ETLBA':'ETLBA','ReT-ELBa':'RETELBA','ESCEL+cap':'ESCEL_CAP90','SAKMLB':'KM2'}[alg]
        return ('study_round3.csv',f'R3_TOPO{t}_{b}_{k}')
    h='H1' if t=='A1' else 'H15'
    if metric=='comp':
        if alg in('ESCEL','Throttled','SAKMLB'):
            k={'ESCEL':'ESCEL','Throttled':'THROTTLED','SAKMLB':'KM2'}[alg]; return ('achunk',f'R4_ACHUNK_{h}_{b}_{k}')
        k={'RR':'RR','ETLBA':'ETLBA','ReT-ELBa':'RETELBA','ESCEL+cap':'ESCEL_CAP90'}[alg]; return ('study_round3.csv',f'R3_MCAP_{h}_{b}_{k}')
    k={'RR':'RR','ESCEL':'ESCEL','Throttled':'THROTTLED','ETLBA':None,'ReT-ELBa':None,'ESCEL+cap':None,'SAKMLB':'KM2'}[alg]
    if k: return ('heavy',f'HV_{h}_{b}_{k}')
    k={'ETLBA':'ETLBA','ReT-ELBa':'RETELBA','ESCEL+cap':'ESCEL_CAP90'}[alg]; return ('study_round3.csv',f'R3_MCAP_{h}_{b}_{k}')
def rows(setting,alg,metric):
    f,l=lab(setting,alg,metric)
    x=d[d.file.str.contains(f)&(d.label==l)].sort_values('seed')
    # cap in A: heavy ESCEL_CAP is floor 70000 -> paper uses CAP90 from round3
    return x,l
