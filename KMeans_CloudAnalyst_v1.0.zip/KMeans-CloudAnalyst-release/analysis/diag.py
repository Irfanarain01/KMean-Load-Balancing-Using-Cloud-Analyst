import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon
plt.rcParams['font.family']='DejaVu Sans'
import os
HERE=os.path.dirname(os.path.abspath(__file__))
OUT=os.path.join(HERE,'figures')+os.sep
BL=('#e8f0fa','#1f4e79'); RD=('#fde8e8','#b03a2e'); GR=('#e6f4ea','#2e7d32'); GY=('#f2f2f2','#555555'); YL=('#fff0d6','#b9770e')
def box(ax,x,y,w,h,title,body='',c=BL,fs=7.5,tfs=None):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=0.06',fc=c[0],ec=c[1],lw=1.1))
    tfs=tfs or fs; lh=1.28/72
    nt=title.count('\n')+1; nb=(body.count('\n')+1) if body else 0
    Ht=nt*tfs*lh+nb*fs*lh; top=y+h/2+Ht/2
    ax.text(x+w/2,top,title,ha='center',va='top',fontsize=tfs,fontweight='bold',linespacing=1.15)
    if body: ax.text(x+w/2,top-nt*tfs*lh,body,ha='center',va='top',fontsize=fs,linespacing=1.15)
def arrow(ax,p,q,color='#222',ls='-',lw=1.1,both=False):
    ax.annotate('',xy=q,xytext=p,arrowprops=dict(arrowstyle='<|-|>' if both else '-|>',color=color,lw=lw,ls=ls,shrinkA=0,shrinkB=0,mutation_scale=9))
def newfig(w,h):
    fig=plt.figure(figsize=(w,h)); ax=fig.add_axes([0,0,1,1]); ax.set_xlim(0,w); ax.set_ylim(0,h); ax.axis('off'); return fig,ax
# Fig 1
fig,ax=newfig(6.0,1.75)
bw,bh=1.3,0.62; xs=[0.05,1.58,3.11,4.64]
y1,y2=1.05,0.05
t1=[("Users' job requests","from different\nlocations"),("Cloudlets","(user requests\nbundled)"),("Data Center\nController",""),("Load Balancer","runs the load-\nbalancing algorithm")]
for x,(a,b),c in zip(xs,t1,[BL,BL,BL,RD]): box(ax,x,y1,bw,bh+0.05,a,b,c)
for i in range(3): arrow(ax,(xs[i]+bw,y1+0.34),(xs[i+1],y1+0.34))
t2=[("VM Manager",""),("Virtual machines","(VMs)"),("Hypervisor",""),("Physical machines","")]
xr=xs[::-1]
for x,(a,b) in zip(xr,t2): box(ax,x,y2,bw,bh,a,b,BL)
for i in range(3): arrow(ax,(xr[i],y2+0.31),(xr[i+1]+bw,y2+0.31))
arrow(ax,(xs[3]+bw/2,y1),(xs[3]+bw/2,y2+bh)); ax.text(xs[3]+bw/2-0.08,(y1+y2+bh)/2,'selects a VM',ha='right',va='center',fontsize=7.5,color='#333')
fig.savefig(OUT+'fig_lb.png',dpi=300); plt.close(fig)
# Fig 2 request path
W,H=6.9,3.35
fig,ax=newfig(W,H)
ax.add_patch(FancyBboxPatch((2.35,0.1),2.95,3.15,boxstyle='round,pad=0,rounding_size=0.08',fc='#fafafa',ec='#999',lw=1.5))
ax.text(3.83,3.07,'Datacenter Controller (per data center)',ha='center',va='center',fontsize=7.5,fontweight='bold')
box(ax,0.05,0.3,0.95,1.0,'User bases','UB1 to UB6',BL)
box(ax,1.15,0.3,1.05,1.0,'Datacenter\nBroker','SBP: CDC,\nORT or DR',BL,tfs=7.5)
box(ax,2.5,2.05,1.3,0.75,'VM monitor','load(v) per VM',GY)
box(ax,3.95,2.05,1.25,0.75,'Speed estimator','updates r(v)\n(Eqs. 5, 6)',RD)
box(ax,2.5,1.2,1.3,0.7,'Admission control','(Eq. 4)\nload(v) < cap(v)',GR)
box(ax,3.95,1.2,1.25,0.7,'Speed tiers','unmeasured, fast,\nslow (Eqs. 7, 8)',RD)
box(ax,2.5,0.55,2.7,0.5,'SAKMLB dispatch','least-loaded eligible VM; ties rotated',RD)
box(ax,2.5,0.15,2.7,0.32,'Waiting queue (SAKMLB returned −1)','',YL,tfs=7.5)
box(ax,5.85,0.55,1.0,2.05,'Virtual\nmachines','1 or 2 vCPU\n8, 10 or 16 GB',BL)
arrow(ax,(1.0,0.8),(1.15,0.8))
arrow(ax,(2.2,0.8),(2.5,0.8))
arrow(ax,(3.15,2.05),(3.15,1.9)); arrow(ax,(4.57,2.05),(4.57,1.9))
arrow(ax,(3.15,1.2),(3.15,1.05)); arrow(ax,(4.57,1.2),(4.57,1.05))
ax.text(3.2,1.97,'load',fontsize=7.3,color='#333',va='center'); ax.text(4.62,1.97,'speeds',fontsize=7.3,color='#333',va='center')
arrow(ax,(3.85,0.47),(3.85,0.55),both=True)
arrow(ax,(5.2,0.8),(5.85,0.8)); ax.text(5.52,0.88,'VM id',fontsize=7.3,ha='center',color='#333')
arrow(ax,(5.85,2.42),(5.2,2.42),color='#b03a2e',ls='--'); ax.text(5.52,2.55,'completion\n(L, T)',fontsize=7.3,ha='center',color='#b03a2e',va='bottom')
ax.text(0.05,2.9,'RR, ESCEL, Throttled, ETLBA\nand ReT-ELBa plug into the\nsame slot as SAKMLB.',fontsize=7,color='#555',va='top',linespacing=1.2)
fig.savefig(OUT+'fig_path.png',dpi=300); plt.close(fig)
# Fig 3 flowchart (width 3.1in)
W,H=3.15,4.1
fig,ax=newfig(W,H)
def dia(x,y,w,h,text,c=YL):
    ax.add_patch(Polygon([(x,y+h/2),(x+w/2,y+h),(x+w,y+h/2),(x+w/2,y)],closed=True,fc=c[0],ec=c[1],lw=1.1))
    ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=7)
bx,bwid=0.05,1.5
box(ax,bx,3.6,bwid,0.45,'Cloudlet of length L arrives\n(or waits in the queue)','',BL,tfs=6.8)
box(ax,bx,2.95,bwid,0.5,'Speed-aware group order','unmeasured, fast, slow',GY,fs=6.8,tfs=6.8)
box(ax,bx,2.45,bwid,0.35,'Take the next group G','',GY,tfs=6.8)
box(ax,bx,1.78,bwid,0.55,'Admission control (Eq. 4)','E = {v in G: load(v) < cap(v)}',GR,fs=6.5,tfs=6.8)
dia(bx,0.95,bwid,0.7,'E empty?')
box(ax,bx,0.05,bwid,0.55,'Pick least-loaded v in E','ties rotated; load(v) += 1;\nreturn v',RD,fs=6.5,tfs=6.8)
box(ax,1.65,2.95,1.45,1.1,'On completion','sample L/T of the VM\n(Eqs. 5, 6); every 25\nsamples re-cluster\n(Eqs. 7, 8)',RD,fs=6.5,tfs=6.8)
dia(1.65,0.95,1.45,0.7,'More groups\nleft?')
box(ax,1.65,0.05,1.45,0.55,'Return −1','request waits in the queue',GY,fs=6.5,tfs=6.8)
for a,b in [((0.8,3.6),(0.8,3.45)),((0.8,2.95),(0.8,2.8)),((0.8,2.45),(0.8,2.33)),((0.8,1.78),(0.8,1.65)),((0.8,0.95),(0.8,0.6))]: arrow(ax,a,b)
arrow(ax,(1.65,3.5),(1.55,3.2),color='#b03a2e',ls='--') if False else arrow(ax,(1.65,3.2),(1.55,3.2),color='#b03a2e',ls='--')
arrow(ax,(1.55,1.3),(1.65,1.3)); ax.text(1.6,1.37,'yes',fontsize=6.3,ha='center')
ax.text(0.86,0.72,'no',fontsize=6.3)
arrow(ax,(2.375,0.95),(2.375,0.6)); ax.text(2.42,0.72,'no',fontsize=6.3)
ax.plot([2.375,2.375],[1.65,2.62],color='#222',lw=1.1); arrow(ax,(2.375,2.62),(1.55,2.62)); ax.text(2.43,2.1,'yes',fontsize=6.3)
fig.savefig(OUT+'fig_flow.png',dpi=300); plt.close(fig)
