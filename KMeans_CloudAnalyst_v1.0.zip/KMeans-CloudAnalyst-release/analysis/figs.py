import os,sys;HERE=os.path.dirname(os.path.abspath(__file__));sys.path.insert(0,HERE)
from cells import *
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, matplotlib.patches as mp
from scipy import stats
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':8,'axes.linewidth':0.6})
COL=['#9e9e9e','#d0d0d0','#616161','#8d6e63','#bcaaa4','#90caf9','#c62828']
HAT=['','','','//','\\\\','xx','']
OUT=os.path.join(HERE,'figures')+os.sep
def stat(s,a,m,c):
    x,_=rows(s,a,m); v=x[c].values; n=len(v)
    return v.mean(), stats.t.ppf(.975,n-1)*v.std(ddof=1)/np.sqrt(n)
# Fig 4
fig,ax=plt.subplots(3,3,figsize=(7.0,5.3))
M=[('RT','RT_avg','RT (ms)'),('DCPT','DCPT_avg','DCPT (ms)'),('comp','comp','Completion time (ms)')]
for j,(s,t) in enumerate([('A15 CDC','Topology A, 1.5× users'),('B CDC','Topology B'),('C CDC','Topology C')]):
    for i,(m,c,yl) in enumerate(M):
        a=ax[i,j]; vals=[stat(s,al,m,c) for al in ALGS]
        for k,(v,e) in enumerate(vals):
            a.bar(k,v,0.8,color=COL[k],edgecolor='black',linewidth=0.5,hatch=HAT[k],yerr=e,capsize=2,error_kw={'elinewidth':0.8})
        lo=min(v-e for v,e in vals); hi=max(v+e for v,e in vals); pad=(hi-lo)*0.08
        a.set_ylim(lo-pad*2.5,hi+pad); a.set_xticks([])
        if j==0: a.set_ylabel(yl,fontsize=8)
        if i==0: a.set_title(t,fontsize=9)
        a.tick_params(labelsize=7.5)
        # value label on SAKMLB bar
        a.text(6,vals[6][0]+vals[6][1]+pad*0.15,f'{vals[6][0]:.0f}',ha='center',va='bottom',fontsize=7,color=COL[6],fontweight='bold')
h=[mp.Patch(facecolor=COL[k],edgecolor='black',hatch=HAT[k],label=ALGS[k]) for k in range(7)]
fig.legend(handles=h,loc='upper center',ncol=7,fontsize=8,frameon=False,bbox_to_anchor=(0.5,1.0),columnspacing=1.0,handlelength=1.4)
fig.tight_layout(rect=(0,0,1,0.95),h_pad=0.8,w_pad=0.8)
fig.savefig(OUT+'fig_main.png',dpi=300); plt.close(fig)
# Fig 5
setl=['A1 CDC','A1 ORT','A1.5 CDC','A1.5 ORT','B CDC','B ORT','C CDC','C ORT']
algs=['vs RR','vs ESCEL','vs Throttled','vs ETLBA','vs ReT-ELBa','vs ESCEL+cap']
G={}
for (m,c,t) in [('RT','RT_avg','RT'),('DCPT','DCPT_avg','DCPT'),('comp','comp','Completion time')]:
    Z=np.zeros((8,6))
    for j,s_ in enumerate(SET):
        sv=rows(s_,'SAKMLB',m)[0][c].mean()
        for i,a_ in enumerate(ALGS[:6]):
            Z[j,i]=(sv/rows(s_,a_,m)[0][c].mean()-1)*100
    G[m]=Z
fig,ax=plt.subplots(1,3,figsize=(6.7,3.0),gridspec_kw={'wspace':0.06})
vmin,vmax=-40,0
for k,(m,t) in enumerate([('RT','RT'),('DCPT','DCPT'),('comp','Completion time')]):
    a=ax[k]; Z=G[m]
    im=a.imshow(np.clip(Z,vmin,vmax),cmap='YlGn_r',vmin=vmin,vmax=vmax,aspect='auto')
    for j in range(8):
        for i in range(6):
            v=Z[j,i]; a.text(i,j,('0.0' if abs(v)<0.05 else f'{v:.1f}'.replace('-','\u2212')),ha='center',va='center',fontsize=6.4,color='white' if v<-24 else 'black')
    a.set_xticks(range(6)); a.set_xticklabels([x.replace('vs ','') for x in algs],fontsize=6.8,rotation=40,ha='right',rotation_mode='anchor')
    a.set_yticks(range(8)); a.set_yticklabels(setl if k==0 else [],fontsize=7)
    a.set_title(t,fontsize=8.5)
cb=fig.colorbar(im,ax=ax,orientation='horizontal',fraction=0.06,pad=0.34,aspect=50)
cb.set_label('Change in mean of SAKMLB relative to each algorithm (%); negative means SAKMLB is faster',fontsize=7)
cb.ax.tick_params(labelsize=6.8)
fig.savefig(OUT+'fig_gain.png',dpi=300,bbox_inches='tight'); plt.close(fig)
np.save(os.path.join(HERE,'out','gain.npy'),np.stack([G['RT'].T,G['DCPT'].T,G['comp'].T]))
# Fig 7 from Table 13
VM=[3000,7000,10000]
disp={'RR':[0.00,0.18,0.02],'ESCEL':[0.25,3.40,11.15],'Throttled':[0.44,1.33,2.31],'ETLBA':[1.88,1.62,9.12],'ReT-ELBa':[0.30,1.29,12.27],'SAKMLB':[1.42,1.94,3.49]}
run={'RR':[31,142,292],'ESCEL':[38,170,368],'Throttled':[26,141,312],'ETLBA':[24,138,313],'ReT-ELBa':[29,149,370],'SAKMLB':[31,183,424]}
clus=[2.4,33.9,110.1]
fig,ax=plt.subplots(1,3,figsize=(7.0,2.5))
mk=['o','s','^','D','v','o']; names=list(disp)
cc={'RR':COL[0],'ESCEL':'#9a9a9a','Throttled':COL[2],'ETLBA':COL[3],'ReT-ELBa':'#a1887f','SAKMLB':COL[6]}
for n,m_ in zip(names,mk):
    ax[0].plot(VM,disp[n],marker=m_,ms=4,color=cc[n],lw=1.3,label=n)
    ax[2].plot(VM,[x/60 for x in run[n]],marker=m_,ms=4,color=cc[n],lw=1.3,label=n)
ax[1].plot(VM,clus,marker='o',ms=4,color=COL[6],lw=1.3,label='SAKMLB')
for a_,yl,tt in zip(ax,['CPU per dispatch decision (µs)','CPU in clustering, whole run (s)','Wall time per run (min)'],['(a) Dispatch','(b) Clustering','(c) Run']):
    a_.set_xlabel('VMs'); a_.set_ylabel(yl,fontsize=7.5); a_.set_xticks(VM); a_.set_xticklabels(['3,000','7,000','10,000'],fontsize=7); a_.tick_params(labelsize=7); a_.set_title(tt,fontsize=8.5)
h,l=ax[0].get_legend_handles_labels()
fig.legend(h,l,loc='upper center',ncol=6,fontsize=7.5,frameon=False,bbox_to_anchor=(0.5,1.02))
fig.tight_layout(rect=(0,0,1,0.9),w_pad=1.0)
fig.savefig(OUT+'fig_over.png',dpi=300); plt.close(fig)

