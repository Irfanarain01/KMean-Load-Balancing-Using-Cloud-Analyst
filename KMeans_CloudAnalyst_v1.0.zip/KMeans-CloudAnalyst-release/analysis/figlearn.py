import pandas as pd,numpy as np,warnings;warnings.filterwarnings('ignore')
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
def ex(r):
    num=den=0
    for dc in range(1,6):
        for t in ['v1L','v1H','v2L','v2H']:
            n=r.get(f'DC{dc}_{t}_n')
            if pd.notna(n) and n>0: num+=n*r[f'DC{dc}_{t}_exec']; den+=n
    return num,den
import os
HERE=os.path.dirname(os.path.abspath(__file__))
U=os.path.join(HERE,'..','results')+os.sep
r3=pd.read_csv(U+'study_round3.csv',low_memory=False); ac=pd.read_csv(U+'study_achunk.csv',low_memory=False)
items=[('Topology A',ac,['R4_ACHUNK_H15_CDC_KM2','R4_ACHUNK_H1_CDC_KM2']),('Topology B',r3,'R3_TOPOB_CDC_KM2'),('Topology C',r3,'R3_TOPOC_CDC_KM2'),('3,000 VMs',r3,'R3_SCALE_S1_CDC_KM2'),('7,000 VMs',r3,'R3_SCALE_S2_CDC_KM2'),('10,000 VMs',r3,'R3_SCALE_S3_CDC_KM2')]
res=[]
for n,d,l in items:
    x=d[d.label.isin(l if isinstance(l,list) else [l])]; b=[];a=[];c=[]
    for _,r in x.iterrows():
        num,den=ex(r); b.append(r.learn_exec); a.append((num-r.learn_exec*r.learn_n)/(den-r.learn_n)); c.append(r.learn_completions)
    res.append((n,np.mean(b),np.mean(a),np.mean(c),len(x)))
    print(n,len(x),round(np.mean(b),1),round(np.mean(a),1),round(np.mean(c)))
fig,ax=plt.subplots(figsize=(6.4,2.6)); plt.rcParams['font.size']=8
for i,(n,b,a,c,_) in enumerate(res):
    ax.bar(i-0.2,b,0.4,color='#ffcdd2',edgecolor='black',lw=0.5,label='while the balancer is still measuring VMs' if i==0 else None)
    ax.bar(i+0.2,a,0.4,color='#c62828',edgecolor='black',lw=0.5,label='after every VM is measured' if i==0 else None)
    ax.text(i-0.2,b+6,f'{b:.0f}',ha='center',fontsize=8); ax.text(i+0.2,a+6,f'{a:.0f}',ha='center',fontsize=8)
    ax.text(i,-56,f'{c:,.0f} compl.',ha='center',fontsize=7.5,color='#444')
ax.set_xticks(range(6)); ax.set_xticklabels([r[0] for r in res],fontsize=8); ax.tick_params(axis='x',pad=20)
ax.set_ylabel('Mean execution time (ms)',fontsize=8.5); ax.set_ylim(0,420); ax.tick_params(labelsize=8)
ax.legend(fontsize=8,loc='upper right',frameon=False,ncol=1)
fig.tight_layout(); fig.savefig(os.path.join(HERE,'figures','fig_learn.png'),dpi=300); 
