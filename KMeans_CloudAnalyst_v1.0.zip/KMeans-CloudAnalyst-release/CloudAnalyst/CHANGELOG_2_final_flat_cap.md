# CORRECTION: weighted admission control restored (the "flat cap" simplification was a mistake)

The previous zip (CloudAnalyst_KMean_FinalHybrid) removed the MIPS-weighted
admission cap on the belief that floor=70000 "collapsed to a flat cap of 1".
That was WRONG. Per-VM MIPS = host speed x vCPUs, and VM_VCPU_TIERS = {1,2},
so each DC has two MIPS levels (DC1 100k/200k, DC2 120k/240k, DC3 90k/180k).
At floor 70000 the caps were DC1 1/2, DC2 1/3, DC3 1/2 -- not all 1.

Running the flat cap of 1 confirmed it: RT 314.97 / DCPT 37.37 (DC3 avg 47.71,
max 225.95), clearly worse than the weighted floor-70000 run (310.42 / 32.61).

## Restored (Constants.java, KMeanVmLoadBalancer.java)
- ENABLE_KMEANS_WEIGHTED_ADMISSION_CONTROL = true
- MIN_MIPS_SHARE_PER_JOB = 70000.0
- capForVm(): cap = max(1, floor(vmMips / MIN_MIPS_SHARE_PER_JOB))
- Defaults: admission control on, weighted on, size-aware routing on.

## Corrected ablation (ORT, size-aware on; RR steady at RT ~310.7, DCPT ~33.3)
| Setting | Caps (1-vCPU / 2-vCPU VM) | K-Means RT / DCPT |
|---|---|---|
| Admission control off | unlimited | 341.41 / 64.49 |
| Flat cap 1 | 1/1 everywhere | 314.97 / 37.37 |
| Weighted, floor 45000 | DC1 2/4, DC2 2/5, DC3 2/4 | 312.94 / 36.41 |
| Weighted, floor 50000 | DC1 2/4, DC2 2/4, DC3 1/3 | 311.47 / 34.52 |
| Weighted, floor 60000 | DC1 1/3, DC2 2/4, DC3 1/3 | 311.51 / 34.37 |
| Weighted, floor 70000 | DC1 1/2, DC2 1/3, DC3 1/2 | 310.42 / 32.61 |

Sweet spot between too loose and too tight. Single runs only: repeat with
multiple seeds before claiming the small margin over RR.

Compiled cleanly (javac -source 8 -target 8) against the project's own jars.
