# Batch runner for the multi-seed study (no GUI clicking)

New: source/cloudsim/ext/study/BatchRunner.java, source/cloudsim/ext/study/StudyDriver.java,
CA_H1.sim (your saved configuration, copied into the project folder).
Changed: Constants.java -- the two attribution flags are now set at launch time.

## Constants.java change (important)
ENABLE_THROTTLED_WEIGHTED_CAP and ENABLE_ESCEL_WEIGHTED_CAP are no longer
edited in the code. Both default to false and are switched on per run with
JVM options:
    -Dca.throttledCap=true     (Throttled with the weighted cap)
    -Dca.escelCap=true         (ESCEL with the weighted cap)
StudyDriver sets these automatically. Only if you run the GUI by hand and want
a capped Throttled/ESCEL run do you add one of them to VM arguments (next to
-Dca.seed=N). All other K-Means settings (floor 70000, K=2, size-aware routing,
heterogeneous VMs) are unchanged and still come from Constants.java.

## What StudyDriver does
For every seed it runs 6 configurations, each in a fresh JVM (same as
restarting CloudAnalyst), using CA_H1.sim with the load balancer swapped:
  KMEANS_HYBRID   KMean
  THROTTLED_CAP   Throttled + weighted cap
  ESCEL_CAP       Equally Spread Current Execution Load + weighted cap
  RR              Round Robin
  ESCEL_UNCAPPED  Equally Spread Current Execution Load (original)
  THROTTLED_FLAT  Throttled (original, single-tenant)
Broker policy comes from CA_H1.sim (Optimise Response Time).
One CSV row per run; console output per run in study_logs/.
Resumable: rows already in the CSV are skipped. Failed runs are retried by
starting the driver again. At the end it prints a PAIRING CHECK: for each
seed, all configurations must have sent the same number of requests.

## Verified here
- CA_H1.sim loads headlessly. RR, ORT, seed 1 through BatchRunner:
  identical per-UB request counts to your GUI seed-1 runs,
  RT 310.5643, DCPT 33.6016, DC1 81,774 cloudlets (your two GUI runs:
  310.56 / 310.57, 33.61 / 33.62, 81,778 / 81,767) -- i.e. the same result
  within the known replay noise.
- -Dca.throttledCap / -Dca.escelCap switch the flags (checked both ways).
- Driver: failed runs are reported and retried; resume skips done rows.

## NOT verified here
A K-Means run did not finish within 20+ minutes on my single slow CPU core
(the time goes into pickLeastLoaded on DC1's 500 VMs), so the capped/K-Means
runs have not been checked end-to-end in my sandbox. Check the seed-1 rows
yourself (see the guide in chat).

## Update: speed fix for K-Means / capped Throttled / capped ESCEL (results unchanged)
Problem found when the first study batch seemed stuck: capForVm() looked up each
VM's MIPS with getVmMips(), which scanned the whole VM list. It is called for every
VM on every dispatch, so a 500-VM data center cost ~250,000 list steps per dispatch
(a full K-Means run took over 25 minutes on my machine and never finished).
Fix (KMeanVmLoadBalancer, ThrottledVmLoadBalancer, ActiveVmLoadBalancer): the
vCPU count of a VM is looked up once and kept in a small map. Same formula, same
values, only faster.
Checked on a 45-minute simulation, seed 1, K-Means: old code RT 159.81 / 159.82,
new code RT 159.87 / 159.79 / 159.83 (identical within replay noise), run time
47 s -> 8 s. Full-length K-Means, seed 1, new code: finished in under 4 minutes,
RT 310.29, DCPT 32.87, 509,816,990 requests (same total as RR seed 1).

## Update 2: K-Means ablation group (size-aware off, K sweep, restarts)
Constants.java: KMEANS_NUM_CLUSTERS, KMEANS_NUM_RESTARTS and
ENABLE_KMEANS_SIZE_AWARE_ROUTING can now be set at launch with
-Dca.k=N, -Dca.restarts=N, -Dca.sizeAware=false. Defaults are unchanged (2, 1, true),
so the GUI and the MAIN study behave exactly as before.
StudyDriver has a new group of six K-Means variants (all with the weighted cap on):
  KMEANS_NOSIZE         K=2, 1 start,  size-aware OFF   (the hybrid with only routing changed)
  KMEANS_K1             K=1 (no clustering)
  KMEANS_K2_R10         K=2, 10 starts (true fast/slow split)
  KMEANS_K2_R10_NOSIZE  K=2, 10 starts, size-aware OFF
  KMEANS_K3_R10         K=3, 10 starts
  KMEANS_K4_R10         K=4, 10 starts
Why restarts matter: with the default single start, K=2 splits DC1/DC2 by RAM, not by
speed (see CHANGELOG_3), so "prefer the fastest cluster" cannot separate fast from slow
VMs there. 10 starts finds the fast/slow split. The MAIN KMEANS_HYBRID row (1 start)
is therefore compared with KMEANS_K2_R10.
Program argument 5 picks the group: MAIN (default, six original configs),
ABLATION (the six above), ALL, or a comma list of labels. CSV rows now end with three
extra columns: kmeans_k, kmeans_restarts, kmeans_sizeAware. Use a SEPARATE csv file for
the ablation (e.g. study_results_ablation.csv) so the columns of the first file are not mixed.
Verified on a 45-minute simulation (seed 1): every option takes effect (console quality
lines match the offline sweep: K=1 WCSS 215.12; K=2 1 start 130.22 / 0.499; K=2 10 starts
90.12 / 0.617; K=3 46.72 / 0.726; K=4 5.22 / 0.902), the driver runs the group, and
resume skips finished rows.
