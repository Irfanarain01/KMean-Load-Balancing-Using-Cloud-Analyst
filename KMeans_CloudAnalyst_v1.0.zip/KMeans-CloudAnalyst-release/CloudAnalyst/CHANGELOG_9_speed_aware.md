# Speed-aware hybrid (KM2) and heavy-load run groups

- datacenter/KMeanVmLoadBalancer.java: speed-aware mode (-Dca.km2, -Dca.km2k, -Dca.km2soft, -Dca.km2sita,
  -Dca.km2refresh). Off by default; the default hybrid is unchanged.
- datacenter/DatacenterController.java: when KM2 is on, records each cloudlet's dispatch time and reports
  (VM, length, execution time) to the balancer on completion.
- study/MechStats.java: instrumentation now also covers DC1.
- study/StudyDriver.java: groups HEAVY (360 runs, seeds 1-10; CDC, ORT and DR) and HTUNE (150 runs, seeds 11-20).

Checked in the sandbox: compiles (Java 8 target); defaults unchanged; KM2 sends DC2 cloudlets to VMs measured at
about 120,000 MIPS per vCPU (the physical maximum there) against about 114,500 for the default hybrid's choice.
Seed-1 to seed-3 runs of the heavy scenario (4x lengths, 1.5x users, CDC): hybrid and KM2 beat RR, ESCEL and
Throttled on RT and DCPT in every seed. Ten-seed confirmation is what this kit runs.

Held-out pre-check (seeds 11-12, never reported), 4x lengths: against the best built-in algorithm, KM2 had lower DCPT
in every case checked (3 to 6 ms) and lower RT under CDC and DR (about 7 ms) and under ORT (0.5 to 2.4 ms in the
cases checked). The default hybrid lost on RT in 2 of 3 ORT cases, so KM2 is the K-Means version for the paper.
DR matched CDC within 0.02 ms (with these pools DR never adds VMs).
