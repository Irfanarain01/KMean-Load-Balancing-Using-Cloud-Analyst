# Round 3: matched cap, ETLBA and ReT-ELBa, alpha sensitivity, topologies B and C, scalability, overhead

## What to do
1. Copy every file under `source\` in this kit over your Eclipse project
   (eclipse-workspace\CloudAnalyst_BatchStudy.zip_expanded\CloudAnalyst), keeping the folder structure, then press F5.
   New files: datacenter\CompletionObserver.java, datacenter\EtlbaVmLoadBalancer.java,
   datacenter\RetElbaVmLoadBalancer.java, study\Overhead.java, study\Topologies.java.
   Check the Problems tab shows no red errors.
2. Run configuration "Study", Program arguments (VM arguments empty):
       CA_H1.sim study_round3.csv auto 4 ROUND3
   Use 4 workers if your PC has 4 or more cores (2 also works, about twice as long). Resumable.
3. When it shows "Failed runs: 0" and every pairing line is OK, send study_round3.csv.
4. Optional, only if you want scalability under all three broker policies (long runs):
       CA_H1.sim study_round3.csv auto 4 SCALE_ORT,SCALE_DR

## Size and time
ROUND3 = 843 runs: MCAP 240, ALPHA 60, TOPOB 240, TOPOC 240, SCALE_CDC 63.
Roughly 4 hours with 4 workers (7 hours with 2). The 10,000-VM runs are the slowest (about 8 to 10 minutes each).
SCALE_ORT and SCALE_DR add 126 runs (about 2 to 3 hours with 4 workers).

## Groups (all use the heavy heterogeneous lengths 1200, 20000, 1200, 6000, 20000, 6000)
| Group | Runs | Purpose |
|---|---|---|
| MCAP | 4 configs x 2 loads x 3 SBPs x seeds 1-10 | Capped ESCEL at T_share 90,000 (same cap as KM2), ETLBA, ReT-ELBa; RR anchors pairing with study_heavy.csv |
| ALPHA | 2 x 3 SBPs x 10 | KM2 smoothing factor 0.1 and 0.5 (0.3 is already in study_heavy.csv), 1.5x users |
| TOPOB | 8 configs x 3 SBPs x 10 | Five data centers in five regions, 200 VMs each, 1.5x users |
| TOPOC | 8 configs x 3 SBPs x 10 | Central data center with 60 VMs (DR can add VMs to it) plus four 235-VM data centers, 1.5x users |
| SCALE_CDC | 7 configs x 3 sizes x seeds 1-3 | 3,000 / 7,000 / 10,000 VMs (hosts and users scaled with VMs), first 180 simulated minutes, CDC |

Configurations: RR, ESCEL, Throttled, default hybrid (HYB), KM2, capped ESCEL at 90,000 (ESCEL_CAP90),
ETLBA, ReT-ELBa. ETLBA and ReT-ELBa are our reimplementations from the published descriptions (see the source headers).

## New columns in the CSV
Per data center (DC1 to DC5): mean/max processing time, request count, VM count, busy VM-time (utilization =
busy VM-time / (VMs x sim_ms)). Overhead: wall_s, heap_peak_mb, dispatch_us (CPU time per dispatch decision),
cluster_ms (CPU time in clustering), update_us (CPU time per completion update), state_entries.
KM2 learning phase: learn_completions, learn_time_s, and mean execution time before (learn_exec) and after (conv_exec)
every VM was measured.
