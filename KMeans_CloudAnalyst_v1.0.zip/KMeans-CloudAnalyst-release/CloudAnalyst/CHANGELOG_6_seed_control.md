# Multi-seed support: one master seed for all randomness

Files changed: source/cloudsim/ext/Constants.java, UserBase.java, Simulation.java,
servicebroker/BestResponseTimeServiceBroker.java,
servicebroker/ServiceProximityServiceBroker.java
New: source/cloudsim/ext/SeedControl.java, tools/SeedControlTest.java

## What the audit found (all randomness in the simulator)
1. UserBase: two gridsim.util.Poisson generators per user base (request
   delay, user count), created with GridSim's DEFAULT seeds. In a fresh JVM
   these come from a fixed global sequence (identical on every restart), but
   the sequence ADVANCES each time a Poisson object is created, so a second
   simulation run inside the same Eclipse session gets different workload
   draws than the first.
2. BestResponseTimeServiceBroker (ORT): `Math.random()` picks closest vs
   quickest DC 50/50 whenever they differ. Never seeded.
3. ServiceProximityServiceBroker (CDC, also used inside ORT): `Math.random()`
   picks among several DCs in one region. Never seeded.
Nothing else is random (K-Means init already used its own seed, KMEANS_BASE_SEED).

Consequence for the existing results: the workload was fixed across fresh-JVM
runs, so the ~0.1 ms RR run-to-run range (RT 310.65-310.75) measures ONLY the
unseeded broker coin flip (item 2/3). It is not a seed-variance estimate
for the workload. Do not describe it as one in the paper.

## Change
SeedControl.java seeds every generator from (master seed, stream name):
Poisson streams keyed by "UB name + generator name", broker draws keyed by
"orb:<UB name>" and "cdc:region<N>". Keying by entity (not global call order)
means one entity's draws cannot shift another's. Seeds are mixed with
splitmix64 and confined to [1, 2^31-2] (larger seeds made Poisson.sample()
return 0 forever, caught by SeedControlTest). SeedControl.reset() runs at the
start of every simulation, so repeated runs in one session are identical.

Master seed: `Constants.MASTER_SEED` (default -1) or, without recompiling, the
JVM option `-Dca.seed=N` (takes precedence). Eclipse: Run > Run Configurations >
Arguments > VM arguments > `-Dca.seed=1`. The console prints
`[SeedControl] master seed = N` at the start of each run.

DEFAULT BEHAVIOUR IS UNCHANGED: with MASTER_SEED = -1 and no -Dca.seed, the
Poisson objects are created exactly as before (verified: first two default
seeds 4851 / 1802577606, same as the original) and the brokers call
Math.random() as before.

## Verified
- Whole project compiles (-source 8 -target 8) against the project jars.
- tools/SeedControlTest, seeds 0, 1, 7, 8, 123456789: broker streams and
  Poisson streams identical after reset(); different user bases get
  different workloads; a stream is unaffected by draws on other streams.
- 120 seeded Poisson streams x 20000 draws: worst |mean - 100| = 0.23.
- Legacy mode: SeedControl.poisson() reproduces the original default seeds.

## NOT verified here
A full end-to-end simulation could not be run in my sandbox with a 3-DC /
6-UB scenario (it stalled after VM creation; the stock single-DC default
scenario ran fine), so I have not shown that two full seeded simulations give
byte-identical RT/DCPT. Please check on your machine before the study:
  1. RR, ORT, `-Dca.seed=1`, run twice (restart between): RT/DCPT must match
     exactly.
  2. `-Dca.seed=2`: must differ from seed 1 by a small amount.
  3. No -Dca.seed: should still give the usual numbers (K-Means hybrid
     310.41 / 32.61).
If 1 fails, some entity ordering is still non-deterministic; tell me and I
will chase it.

## Caveats
- Seeded numbers will NOT numerically match the earlier tables (different
  workload draws). Treat all earlier tables as the "unseeded legacy" run and
  repeat the comparison under seeds.
- CDC draws are keyed by region, so user bases sharing a region share one
  stream; their relative call order is set by the event queue.
- Expect small seed-to-seed spread: each run averages millions of requests,
  so workload noise largely averages out.
