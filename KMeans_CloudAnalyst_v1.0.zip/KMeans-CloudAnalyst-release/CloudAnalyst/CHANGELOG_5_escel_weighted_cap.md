# Attribution test, part 2: ESCEL with the same weighted cap

Files changed: source/cloudsim/ext/Constants.java,
source/cloudsim/ext/datacenter/ActiveVmLoadBalancer.java,
source/cloudsim/ext/Simulation.java

## Purpose
The Throttled-with-weighted-cap test (see CHANGELOG_4) showed Throttled
converges to the K-Means hybrid's result (RT 310.43/DCPT 32.73 vs 310.41/
32.61, DC3 max identical at 130.21) with zero clustering. This second test
checks whether the cap is a GENERAL fix (works on any base algorithm) or
something specific to Throttled's single-tenant starting point, by adding
the identical cap to ESCEL instead.

## New flag (default false = zero behaviour change)
ENABLE_ESCEL_WEIGHTED_CAP in Constants.java. When true,
ActiveVmLoadBalancer (ESCEL) keeps its existing least-loaded selection,
but a VM at or above cap(vm) = max(1, floor(vm.mips / MIN_MIPS_SHARE_PER_JOB))
-- the SAME constant/formula as the K-Means hybrid and capped-Throttled --
is excluded from consideration, and -1 (queue) is returned only if every
VM is at/over its own cap. When false (default), ESCEL is unchanged: it
always dispatches to the least-loaded VM, never blocks.

Simulation.java now also passes real host MIPS to ESCEL, mirroring the
existing calls for K-Means and Throttled; only read when the flag is on.

## Verified
- Compiled cleanly (javac -source 8 -target 8) against the project jars.
- Offline harness: with the flag off (default), ESCEL's dispatch hash
  over 8000 calls per DC is IDENTICAL between the pre- and post-change
  builds -- zero default-behaviour change.
- Targeted unit check (3 hand-set VM loads) confirms the cap logic: an
  over-cap VM is excluded, the least-loaded eligible VM is chosen, and -1
  is returned only when every VM is at/over cap -- same three cases
  verified for the Throttled variant, same result.
- Did NOT run the full CloudAnalyst simulator.

## How to run
Set ENABLE_ESCEL_WEIGHTED_CAP = true (MIN_MIPS_SHARE_PER_JOB stays 70000).
Run ESCEL under ORT, same heterogeneous config as the rest of the table.

Compare against:
  K-Means hybrid        : RT 310.41  DCPT 32.61
  Throttled + weighted  : RT 310.43  DCPT 32.73
  Round Robin           : RT 310.71  DCPT 33.32
  ESCEL (uncapped)      : RT 312.09  DCPT 34.33
If capped ESCEL also lands near 310.4/32.7, the cap is confirmed general
-- independent of which base algorithm carries it.
