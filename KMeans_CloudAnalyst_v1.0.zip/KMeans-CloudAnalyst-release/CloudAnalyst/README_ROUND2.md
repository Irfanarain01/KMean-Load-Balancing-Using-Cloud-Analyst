# Round-2 runs (answers the review)

## What to do
1. Copy these files over your Eclipse project (CloudAnalyst_BatchStudy.zip_expanded\CloudAnalyst), then press F5:
   - source\cloudsim\ext\Constants.java
   - source\cloudsim\ext\datacenter\DatacenterController.java
   - source\cloudsim\ext\study\BatchRunner.java
   - source\cloudsim\ext\study\StudyDriver.java
   - source\cloudsim\ext\study\MechStats.java   (new file)
2. Run configuration "Study", Program arguments (VM arguments empty):
       CA_H1.sim study_round2.csv auto 2 ROUND2
   "auto" lets each group use its own seeds. Use 3 or 4 instead of 2 if your PC has the cores.
   It is resumable: if it stops, start it again with the same arguments.
3. When the last lines show "Failed runs: 0" and no pairing mismatches, send study_round2.csv.

About 370 runs. Your last batch ran about 3 runs per minute with 2 workers, so expect
roughly 2 hours (less with more workers). HETERO and LOAD runs are heavier than the others.

## Groups (labels start with the group name)
| Group | Runs | Question it answers |
|---|---|---|
| TUNE | 7 x seeds 11-20 | Is T_share = 70,000 best when chosen on seeds the paper does not report? Adds 90,000 (cap = vCPU count everywhere), 100,000 and 120,000 |
| LOAD | 4 x 10 | Does the cap still carry the gain with 1.5x users? |
| PROC | 4 x 10 | ... and with 4x instruction length, where processing is a larger share of RT? |
| REPLAY | 20 x seeds 1-3 | Replay noise from 10 repeats per seed (sets the equivalence margin) |
| MECH | 5 x 10 | Ten-seed confirmation of where each variant sends DC2 cloudlets and how fast they run |
| HETERO | 9 x 10 | The workload the design describes: UB1..UB6 = 300, 5000, 300, 1500, 5000, 1500 instructions per request, with size-aware routing on the per-request length (PERREQ) |
| DRFINAL | 3 x 10 | DR with the final VM pools (DR cannot add VMs above 100 per data center) |

## New launch options (defaults keep earlier behaviour exactly)
-Dca.tshare=N, -Dca.theta=N, -Dca.userScale=x, -Dca.lenScale=x, -Dca.ubLengths=a,b,c,d,e,f,
-Dca.perRequestLength=true, -Dca.mech=true, -Dca.broker=<policy name>, -Dca.group=<name>.
The CSV now ends with: group, tshare, theta, userScale, lenScale, then mechanism columns
(zeros unless ca.mech=true).

## Two findings behind the new groups
- CA_H1.sim stores no per-user-base instruction length, so every user base used the default 1000.
  All earlier results (legacy tables and both ten-seed studies) therefore ran with a uniform length.
  Re-running the legacy hybrid reproduces the paper (RT 310.416, DCPT 32.614, DC3 max 130.21);
  with the heterogeneous lengths it gives RT 289.24 and DCPT 31.65.
- The balancer compares the heavy-job threshold with the grouped cloudlet length (per-request length x
  requests in the cloudlet), so with theta = 2000 every cloudlet counted as heavy (204,598 of 204,598 at seed 1).
