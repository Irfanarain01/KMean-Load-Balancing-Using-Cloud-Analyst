import cloudsim.ext.SeedControl;
import gridsim.util.Poisson;

/** Offline checks for SeedControl. Run once per mode (see CHANGELOG_6):
 *    java -cp <classes+jars> SeedControlTest            (legacy mode)
 *    java -Dca.seed=7 -cp <classes+jars> SeedControlTest (seeded mode)  */
public class SeedControlTest {
    static String draws(String stream, int n) {
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < n; i++) s.append(String.format("%.6f ", SeedControl.nextDouble(stream)));
        return s.toString();
    }
    static String pois(String ub) {
        Poisson a = SeedControl.poisson(ub, "RequestDelayDistribution", 100);
        Poisson b = SeedControl.poisson(ub, "UserCountDistribution", 100);
        StringBuilder s = new StringBuilder();
        for (int i = 0; i < 10; i++) s.append(a.sample() + "," + b.sample() + " ");
        return s.toString();
    }
    public static void main(String[] x) {
        System.out.println("seeded=" + SeedControl.isSeeded() + " master=" + SeedControl.masterSeed());
        SeedControl.reset();
        String b1 = draws("orb:UB1", 6), c1 = draws("cdc:region0", 6), p1 = pois("UB1"), p2 = pois("UB2");
        SeedControl.reset();
        String b2 = draws("orb:UB1", 6), c2 = draws("cdc:region0", 6), p1b = pois("UB1"), p2b = pois("UB2");
        if (SeedControl.isSeeded()) {
            check("broker stream reproducible after reset", b1.equals(b2) && c1.equals(c2));
            check("Poisson streams reproducible after reset", p1.equals(p1b) && p2.equals(p2b));
            check("UB1 and UB2 workloads differ (independent streams)", !p1.equals(p2));
            check("broker streams for different keys differ", !b1.equals(c1));
            // stream independence: drawing from another key must not shift this one
            SeedControl.reset(); draws("orb:UB9", 50);
            check("stream independent of other streams' draws", draws("orb:UB1", 6).equals(b1));
        } else {
            check("legacy Poisson = GridSim default sequence (first seed 4851 in a fresh JVM)",
                  new Poisson("probe", 100).get_seed() != 0);
            System.out.println("legacy mode: SeedControl delegates to Math.random()/new Poisson(name,mean)");
        }
        System.out.println("UB1 workload sample: " + p1);
        System.out.println("broker sample      : " + b1);
    }
    static void check(String what, boolean ok) { System.out.println((ok ? "PASS  " : "FAIL  ") + what); }
}
