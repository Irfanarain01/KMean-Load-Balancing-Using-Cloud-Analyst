import java.lang.reflect.*;
import java.util.*;
import cloudsim.*;
import cloudsim.ext.datacenter.*;

public class ClusterHarness {
    static Object get(Object o, String name) throws Exception {
        Field f = o.getClass().getDeclaredField(name); f.setAccessible(true); return f.get(o);
    }
    static void set(Object o, String name, Object v) throws Exception {
        Field f = o.getClass().getDeclaredField(name); f.setAccessible(true); f.set(o, v);
    }
    public static void main(String[] a) throws Exception {
        int[] vmCounts = {500, 350, 150};
        double[] mips = {100000, 120000, 90000};
        int[] ramTiers = {8192, 10240, 16384};
        int[] vcpuTiers = {1, 2};
        Field uf = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
        uf.setAccessible(true);
        sun.misc.Unsafe U = (sun.misc.Unsafe) uf.get(null);
        double[] lens = {300, 5000, 300, 1500, 5000, 1500};
        for (int dc = 0; dc < 3; dc++) {
            List vmList = new ArrayList();
            Map states = new HashMap();
            for (int i = 0; i < vmCounts[dc]; i++) {
                int mem = ramTiers[i % ramTiers.length];
                int vc = vcpuTiers[(i / ramTiers.length) % vcpuTiers.length];
                vmList.add(new VirtualMachine(new VMCharacteristics(i, 1, 10000L, mem, 1000L, vc, 1, "Xen", new TimeSharedVMScheduler())));
                states.put(i, VirtualMachineState.AVAILABLE);
            }
            KMeanVmLoadBalancer lb = (KMeanVmLoadBalancer) U.allocateInstance(KMeanVmLoadBalancer.class);
            set(lb, "vmStatesList", states);
            set(lb, "vmList", vmList);
            set(lb, "ownerName", "DC" + (dc + 1) + "-Broker");
            set(lb, "currentLoad", Collections.synchronizedMap(new HashMap()));
            set(lb, "lastClusteredN", -1);
            Field vac = VmLoadBalancer.class.getDeclaredField("vmAllocationCounts");
            vac.setAccessible(true);
            vac.set(lb, new HashMap());
            lb.setVmMipsAndRam(mips[dc], 262144);
            Map load = (Map) get(lb, "currentLoad");
            List<Integer> active = new ArrayList<Integer>();
            StringBuilder seq = new StringBuilder();
            long hash = 7; int neg = 0;
            int window = (int) (vmCounts[dc] * 1.6);
            for (int t = 0; t < 8000; t++) {
                int vm = lb.getNextAvailableVm(lens[t % 6]);
                hash = hash * 31 + vm;
                if (vm < 0) neg++;
                if (t < 40) seq.append(vm).append(' ');
                if (vm >= 0) {
                    Integer cur = (Integer) load.get(vm);
                    load.put(vm, cur == null ? 1 : cur + 1);
                    active.add(vm);
                }
                if (active.size() > window + (t % 7)) {
                    int f = active.remove(0);
                    Integer cur = (Integer) load.get(f);
                    load.put(f, Math.max(0, cur - 1));
                }
            }
            double[] cm = (double[]) get(lb, "centroidMips");
            double[] cr = (double[]) get(lb, "centroidRam");
            int[] vc = (int[]) get(lb, "vmCluster");
            int[] cnt = new int[cm.length];
            for (int c : vc) cnt[c]++;
            System.out.println("RESULT DC" + (dc + 1) + " k=" + cm.length + " hash=" + hash + " queued(-1)=" + neg);
            for (int c = 0; c < cm.length; c++)
                System.out.println("RESULT   cluster " + c + " n=" + cnt[c] + " mips=" + cm[c] + " ram=" + cr[c]);
            System.out.println("RESULT   first40=" + seq.toString().trim());
        }
    }
}
