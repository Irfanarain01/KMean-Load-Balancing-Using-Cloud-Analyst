# Round 3 changes

- New balancers: ETLBA (datacenter/EtlbaVmLoadBalancer.java) and ReT-ELBa (datacenter/RetElbaVmLoadBalancer.java),
  reimplemented from the published descriptions; both one cloudlet per VM, ties rotated like the other baselines.
  Policy names "ETLBA" and "ReT-ELBa" (Constants.java, DatacenterController.java).
- datacenter/CompletionObserver.java: common interface for balancers that learn from completed cloudlets (KM2, ETLBA).
- KM2: smoothing factor is a launch option (-Dca.km2alpha, default 0.3); records when every VM has been measured.
- K-Means performance: VM RAM is cached per VM (it was looked up by scanning the VM list on every clustering call).
  Results are unchanged (checked: short run DCPT 119.6285 vs 119.6298 ms, within replay noise), clustering CPU time
  fell from 7.2 s to 0.66 s at 1,000 VMs.
- -Dca.kmLog=false switches off K-Means diagnostic logging (WCSS/silhouette) so overhead measures only clustering.
- Overhead counters (study/Overhead.java): thread CPU time per dispatch decision, clustering and completion update,
  stored values, wall time and peak heap per run.
- Topologies (study/Topologies.java, -Dca.topology=B|C) and VM-population scaling (-Dca.vmScale=k).
  Checked: every configured VM is created in B (5 x 200) and C (60 + 4 x 235); under DR the central data center of C
  grew from 60 to 95 VMs in a short test, so DR's reconfiguration now takes effect.
- -Dca.durationMin=N shortens the simulated period (used for the scalability runs).
- MechStats: data centers DC1 to DC5, busy VM-time per data center, KM2 learning-phase execution times.
- StudyDriver: groups MCAP, ALPHA, TOPOB, TOPOC, SCALE_CDC (ROUND3) and SCALE_ORT, SCALE_DR.

Defaults are unchanged: without the new options every earlier configuration runs as before.
