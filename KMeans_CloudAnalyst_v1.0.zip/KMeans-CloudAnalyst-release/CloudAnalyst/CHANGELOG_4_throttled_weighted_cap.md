# Attribution test: Throttled with the K-Means hybrid's weighted cap

Files changed: source/cloudsim/ext/Constants.java,
source/cloudsim/ext/datacenter/ThrottledVmLoadBalancer.java,
source/cloudsim/ext/Simulation.java

## Purpose
The K-sensitivity sweep (K=2/3/4, restarts=10) showed clustering quality
improving sharply (WCSS 90 -> 5, silhouette 0.62 -> 0.90) with NO change in
RT/DCPT. That points to the weighted admission cap, not K-Means's
clustering, as the source of the hybrid's edge over RR/ESCEL/Throttled.
This change isolates the cap by adding it to Throttled -- no clustering,
no size-aware routing, same cap formula as K-Means.

## New flag (default false = zero behaviour change)
ENABLE_THROTTLED_WEIGHTED_CAP in Constants.java. When true, Throttled:
- tracks an integer load per VM instead of a binary AVAILABLE/BUSY state
- applies cap(vm) = max(1, floor(vm.mips / MIN_MIPS_SHARE_PER_JOB)) --
  the SAME constant and formula the K-Means hybrid uses
- picks the least-loaded VM under its own cap, round-robin tie-break
  (same selection rule K-Means uses within a cluster, applied across all
  VMs since Throttled does no clustering)
- still returns -1 (queues) only when every VM is at/over its own cap

Simulation.java now also passes the real host processor speed to
Throttled (mirrors the existing call for KMeanVmLoadBalancer); this value
is only read when the new flag is on.

## Verified
- Compiled cleanly (javac -source 8 -target 8) against the project jars.
- Offline harness: with the flag left false (default), Throttled's
  dispatch hash over 8000 calls per DC is IDENTICAL between the old and
  new builds -- confirms zero behaviour change by default.
- Targeted unit check (3 VMs, hand-set loads) confirms the cap logic
  itself: an over-cap VM is correctly excluded, the least-loaded eligible
  VM is chosen, and -1 is returned only when every VM is at/over cap.
- Did NOT run the full CloudAnalyst simulator -- that's the next step.

## How to run the test
Set ENABLE_THROTTLED_WEIGHTED_CAP = true (MIN_MIPS_SHARE_PER_JOB stays at
70000.0, or whatever value the K-Means hybrid is using). Leave every
K-Means constant as-is; they don't affect Throttled. Run Throttled under
ORT with the same heterogeneous config as the existing four-way table.

Compare against the existing ORT table:
  K-Means hybrid : RT 310.41  DCPT 32.61
  Round Robin    : RT 310.71  DCPT 33.32
  ESCEL          : RT 312.09  DCPT 34.33
  Throttled (cap=1, current) : RT 314.93  DCPT 37.48
If Throttled-with-weighted-cap scores close to the K-Means hybrid, that
confirms the cap -- not the clustering -- drives the improvement. If it
stays close to plain Throttled instead, clustering/size-aware routing
must be contributing something the cap-only test isn't capturing.
