package cloudsim.ext;

public interface Constants {

	final String STANDARD_SEPARATOR = "-";

	final int WORLD_REGIONS = 6;
	final String INTERNET = "Internet";

	final int REQUEST_INTERNET_CLOUDLET_TAG = 2001;

	final int RESPONSE_INTERNET_CLOUDLET_TAG = 2002;

	final String MEASURE_TYPE_OVERALL_USER_BASE_RESPONSE = "Overall userbase response time";
	final String MEASURE_TYPE_USER_BASE_RESPONSE = "Userbase Response Time";
	final String MEASURE_TYPE_DC_PROCESSING_TIME = "DC Processing Time";
	final String UB_RESPONSE_TIME = "UB Response time";
	final String HOURLY_RESPONSE_TIME = "Hourly Response Time";
	final String DC_SERVICE_TIME = "Service time";

	final String INTERNET_ENTITIES = "internet_entities";

	final String DELAYMATRIX_FILE = "config/delaymatrix.xml";
	final String BWMATRIX_FILE = "config/bwmatrix.xml";

	final String PARAM_DATA_ELEMENT = "data_element";
	final String PARAM_VM_ID = "vm_id";
	final String PARAM_TIME = "time";
	final String PARAM_PROCESSING_TIME = "processing_time";
	final String PARAM_COMM_PATH = "commPath";

	final double MILLI_SECONDS_TO_MINS = 1000 * 60;
	final double MILLI_SECONDS_TO_HOURS = 1000 * 60 * 60;
	final double MILLI_SECONDS_TO_DAYS = 1000 * 60 * 60 * 24;

	final int DEFAULT_APP_ID = 1;
	final String SIMULATION_COMPLETED_TIME = "sim_completed_at";
	final String PDF_EXTENSION = ".pdf";

	//Default Data Center characteristics
	final String DEFAULT_DATA_CENTER_NAME = "DC1";
	final String DEFAULT_ARCHITECTURE = "x86";
	final String DEFAULT_OS = "Linux";
	final String DEFAULT_VMM = "Xen";
	final int DEFAULT_DC_REGION = 0;
	final int DEFAULT_VM_COUNT = 5;
	final double DEFAULT_COST_PER_PROC = 0.1; // the cost of using processing in this resource
	final double DEFAULT_COST_PER_MEM = 0.05; // the cost of using memory in this resource
	final double DEFAULT_COST_PER_STOR = 0.1; // the cost of using storage in this resource
	final double DEFAULT_COST_PER_BW = 0.1;

	final int DEFAULT_MC_MEMORY = 204800;
	final long DEFAULT_MC_STORAGE = 100000000;
	final int DEFAULT_MC_BW = 1000000;
	final int DEFAULT_MC_PROCESSORS =  4;
	final int DEFAULT_MC_SPEED = 10000;

	final long DEFAULT_VM_IMAGE_SIZE = 10000;//MB
	final int DEFAULT_VM_MEMORY = 512;//MB
	final long DEFAULT_VM_BW = 1000;

	//-----------------------------------------------------------------
	// Heterogeneous VM resource-profile switch (K-Means MIPS/RAM study)
	//-----------------------------------------------------------------
	// When false (default), every VM created in a data center gets the
	// SAME memory (from the GUI's Application Deployment Configuration)
	// and 1 vCPU, exactly reproducing the original homogeneous baseline
	// used for Tables 8-14 (only MIPS differs, and only across DCs).
	//
	// When true, VMs within EACH data center are cycled across the
	// tiers below, so both MIPS (via vCPU count) and RAM vary WITHIN a
	// single DC's VM pool as well as across DCs. This gives K-Means a
	// genuinely two-dimensional feature space instead of one collapsed
	// onto MIPS alone. Set this to true, recompile, and re-run CDC/ORT/DR
	// to produce the heterogeneous-VM experiment requested by reviewers.
	final boolean ENABLE_HETEROGENEOUS_VMS = true;

	// RAM tiers (MB) cycled across each DC's VM pool when heterogeneity
	// is enabled. Values are deliberately spread (4/8/16 GB) so RAM
	// contributes real variance alongside MIPS.
	final int[] VM_RAM_TIERS_MB = new int[] {8192,10240, 16384};
	


	// vCPU tiers cycled independently of the RAM tiers above (using a
	// different cycle length) so RAM and vCPU count are NOT perfectly
	// correlated - this is what forces K-Means to use both dimensions
	// rather than reducing to a 1-D sort on either feature alone.
	final int[] VM_VCPU_TIERS = new int[] {1, 2};

	//-----------------------------------------------------------------
	// K-Means hybrid: size-aware routing + capability-weighted admission control
	//-----------------------------------------------------------------
	// ENABLE_KMEANS_ADMISSION_CONTROL: when true, K-Means only dispatches
	// to a VM whose current load is below that VM's admission cap. It
	// still prefers the less-utilised cluster first (resource-profile
	// affinity), falls back to the other cluster if the preferred one has
	// no VM under the cap, and only queues (returns -1, exactly like
	// Throttled) if NO VM in EITHER cluster is under the cap. When false,
	// K-Means always dispatches immediately, even onto an already-busy VM
	// (the same as RR and ESCEL).
	//
	// ENABLE_KMEANS_WEIGHTED_ADMISSION_CONTROL: when false, every VM gets
	// the same flat cap, KMEANS_MAX_CONCURRENT_PER_VM (1 = Throttled's
	// strict single-tenant policy). When true (default), each VM gets its
	// own cap from its real MIPS:
	//     cap(vm) = max(1, floor(vm.mips / MIN_MIPS_SHARE_PER_JOB))
	// NOTE: vm.mips is host speed x vCPUs (see KMeanVmLoadBalancer
	// .getVmMips), so with heterogeneous VMs each DC has TWO MIPS levels
	// (VM_VCPU_TIERS = {1,2}): DC1 100k/200k, DC2 120k/240k, DC3 90k/180k.
	//
	// Ablation history (all runs: ORT policy, size-aware routing on, same
	// heterogeneous instruction lengths, K-Means vs RR; RR steady at
	// RT ~310.7, DCPT ~33.3). Caps listed as 1-vCPU / 2-vCPU VM per DC:
	//   admission control OFF (unlimited)                -> RT 341.41, DCPT 64.49
	//   flat cap 1 everywhere                            -> RT 314.97, DCPT 37.37
	//   weighted, floor 45000 (DC1 2/4, DC2 2/5, DC3 2/4) -> RT 312.94, DCPT 36.41
	//   weighted, floor 50000 (DC1 2/4, DC2 2/4, DC3 1/3) -> RT 311.47, DCPT 34.52
	//   weighted, floor 60000 (DC1 1/3, DC2 2/4, DC3 1/3) -> RT 311.51, DCPT 34.37
	//   weighted, floor 70000 (DC1 1/2, DC2 1/3, DC3 1/2) -> RT 310.42, DCPT 32.61
	// Best result is floor 70000: slow (1-vCPU) VMs stay at cap 1 while
	// fast (2-vCPU) VMs get 2-3, and it is the only run that beat RR on
	// every average metric. Both extremes are worse: too loose (45000-
	// 60000) lets contended DCs stack jobs on VMs and dilute their MIPS
	// (TimeSharedVMScheduler splits a VM's MIPS across concurrent jobs);
	// too tight (flat 1) leaves fast VMs underused and forces jobs to
	// queue. NOTE: an earlier version of this comment claimed floor 70000
	// "collapsed to a flat cap of 1" and that weighting did not help; that
	// was wrong (it ignored the vCPU doubling above), and the flat-cap
	// result above disproves it. Single runs only so far -- confirm with
	// multiple seeds before reporting the small margin over RR.
	final boolean ENABLE_KMEANS_ADMISSION_CONTROL = true;
	final boolean ENABLE_KMEANS_WEIGHTED_ADMISSION_CONTROL = true;
	final int KMEANS_MAX_CONCURRENT_PER_VM = 1;
	/* Default 70000. Batch runs may override with -Dca.tshare=N (no rebuild needed). */
	double MIN_MIPS_SHARE_PER_JOB = Double.parseDouble(System.getProperty("ca.tshare", "70000"));

	//-----------------------------------------------------------------
	// K-Means size-aware routing switch (use job size, not just load)
	//-----------------------------------------------------------------
	// When false, K-Means always prefers the LEAST-UTILISED cluster
	// first, regardless of how big the incoming job is -- the right
	// baseline as long as every job needs the same amount of computation
	// (Advanced tab's single global Executable Instruction Length), since
	// there is then no "wrong VM" to route a job to.
	//
	// When true (default -- part of the tested hybrid above), and
	// per-user-base Instruction Length is actually varied (see
	// UserBaseUIElement.instructionLength / the Main Configuration
	// table's "Instruction Length" column), K-Means instead prefers the
	// HIGHEST-MIPS cluster first for any job at or above
	// KMEANS_HEAVY_JOB_THRESHOLD, and falls back to least-utilised
	// ordering for smaller jobs.
	/* Default true. Batch runs may override with -Dca.sizeAware=false (no rebuild needed). */
	boolean ENABLE_KMEANS_SIZE_AWARE_ROUTING = Boolean.parseBoolean(System.getProperty("ca.sizeAware", "true"));

	// Cloudlet length (GridSim "gridlet length") at or above which a job
	// is treated as "heavy" when ENABLE_KMEANS_SIZE_AWARE_ROUTING is true.
	// Pick this roughly between your lightest and heaviest configured
	// per-user-base Instruction Length values.
	/* Default 2000. Batch runs may override with -Dca.theta=N (no rebuild needed).
	   NOTE: the balancer compares this with the length of the cloudlet it dispatches,
	   which is the per-request instruction length times the number of requests the
	   data center grouped into that cloudlet (up to the DC request grouping factor). */
	double KMEANS_HEAVY_JOB_THRESHOLD = Double.parseDouble(System.getProperty("ca.theta", "2000"));

	//-----------------------------------------------------------------
	// K-Means cluster count / restarts / quality logging (K-sensitivity)
	//-----------------------------------------------------------------
	// KMEANS_NUM_CLUSTERS: K, the number of groups each data center's VM
	// pool is split into. 2 reproduces every result reported so far.
	// Dispatch, ordering and the admission cap already work for any K.
	/* Default 2. Batch runs may override with -Dca.k=N (no rebuild needed). */
	int KMEANS_NUM_CLUSTERS = Integer.getInteger("ca.k", 2).intValue();

	// KMEANS_NUM_RESTARTS: how many independent random initialisations to
	// try per clustering; the run with the lowest WCSS is kept. 1 (default)
	// reproduces the previous behaviour exactly. NOTE: plain K-Means can
	// land in a poor local optimum. With the default single start (seed
	// 42) K=2 splits DC1/DC2 by RAM instead of by MIPS (see the quality
	// log), so both clusters have almost the same average MIPS. More
	// restarts find the lower-WCSS split.
	/* Default 1. Batch runs may override with -Dca.restarts=N (no rebuild needed). */
	int KMEANS_NUM_RESTARTS = Integer.getInteger("ca.restarts", 1).intValue();

	// Seed for restart 0; restart r uses KMEANS_BASE_SEED + r. 42 is the
	// value that was previously hard-coded, so runs stay reproducible.
	final long KMEANS_BASE_SEED = 42L;

	// When true, each clustering also prints WCSS (within-cluster sum of
	// squares, in min-max scaled units) and the mean silhouette score to
	// the console. Logging only; it never changes dispatch.
	/* Diagnostic only (WCSS and silhouette in the log); -Dca.kmLog=false switches off all K-Means logging,
	   so that overhead measurements contain only the clustering itself. */
	boolean ENABLE_KMEANS_QUALITY_LOGGING = Boolean.parseBoolean(System.getProperty("ca.kmLog", "true"));

	//-----------------------------------------------------------------
	// Throttled with the SAME MIPS-weighted cap as the K-Means hybrid
	// (attribution test -- isolates the admission cap's contribution
	// from K-Means's clustering/size-aware routing)
	//-----------------------------------------------------------------
	// When false (default), Throttled is completely unchanged: strict
	// single-tenant-per-VM (AVAILABLE/BUSY), identical to the original
	// published behaviour.
	//
	// When true, Throttled instead tracks an integer load per VM (like
	// K-Means/ESCEL do) and applies the SAME per-VM cap formula as the
	// K-Means hybrid, reusing MIN_MIPS_SHARE_PER_JOB above:
	//     cap(vm) = max(1, floor(vm.mips / MIN_MIPS_SHARE_PER_JOB))
	// Selection among VMs under their cap is least-loaded-first with
	// round-robin tie-break -- exactly K-Means's pickLeastLoaded, minus
	// the cluster-preference step (Throttled still does no resource-
	// profile matching and no size-aware routing; only the admission
	// policy changes). No queueing behaviour differs otherwise: -1 is
	// still returned when nothing qualifies.
	//
	// Purpose: if ThrottledVmLoadBalancer with this flag on scores close
	// to the K-Means hybrid, that is strong evidence the hybrid's edge
	// over plain RR/Throttled/ESCEL comes from the weighted admission
	// cap itself, not from K-Means's clustering or size-aware routing.
	/* Default false. Batch runs may override with -Dca.throttledCap=true (no rebuild needed). */
	boolean ENABLE_THROTTLED_WEIGHTED_CAP = Boolean.getBoolean("ca.throttledCap");

	//-----------------------------------------------------------------
	// ESCEL with the SAME MIPS-weighted cap (attribution test, part 2)
	//-----------------------------------------------------------------
	// Same idea as ENABLE_THROTTLED_WEIGHTED_CAP above, applied to ESCEL
	// (ActiveVmLoadBalancer) instead: when true, ESCEL keeps its existing
	// least-loaded selection, but a VM whose current allocation count is
	// at or above cap(vm) = max(1, floor(vm.mips / MIN_MIPS_SHARE_PER_JOB))
	// is excluded, and -1 (queue) is returned if every VM is over cap.
	// When false (default), ESCEL is completely unchanged: it always
	// dispatches to the least-loaded VM, never blocks.
	//
	// Purpose: if capped ESCEL also converges to the K-Means-hybrid /
	// capped-Throttled result, that confirms the weighted cap is a
	// general fix independent of which base algorithm carries it, not
	// something specific to Throttled's single-tenant starting point.
	/* Default false. Batch runs may override with -Dca.escelCap=true (no rebuild needed). */
	boolean ENABLE_ESCEL_WEIGHTED_CAP = Boolean.getBoolean("ca.escelCap");

	//Default User base characteristics
	final String DEFAULT_USER_BASE_NAME = "UB1";
	final int DEFAULT_UB_REGION = 2;
	final int DEFAULT_REQ_PER_USER_PER_HR = 60;
	final long DEFAULT_REQ_SIZE = 100;
	final int[] DEFAULT_PEAK_HOURS = new int[]{3, 9};
	final int DEFAULT_PEAK_USERS = 1000;
	final int DEFAULT_OFFPEAK_USERS = 100;


	final String UB_STATS = "UB stats";
	final String DC_ARRIVAL_STATS = "DC stats";
	final String DC_PROCESSING_TIME_STATS = "DC processing time stats";
	final String DC_OVER_LOADING_STATS = "DC overloading stats";
	final String COSTS = "Costs";
	final String VM_COST = "VM Cost";
	final String DATA_COST = "Data Cost";
	final String TOTAL_COST = "Total Cost";

	final String BROKER_POLICY_PROXIMITY = "Closest Data Center";
	final String BROKER_POLICY_OPTIMAL_RESPONSE = "Optimise Response Time";
	final String BROKER_POLICY_DYNAMIC = "Reconfigure Dynamically with Load";

	final String LOAD_BALANCE_POLICY_RR = "Round Robin";
	final String LOAD_BALANCE_ACTIVE = "Equally Spread Current Execution Load";
	final String LOAD_BALANCE_THROTTLED = "Throttled";
	final String LOAD_BALANCE_DLB = "KMean";
	final String LOAD_BALANCE_ETLBA = "ETLBA";
	final String LOAD_BALANCE_RETELBA = "ReT-ELBa";

	//-----------------------------------------------------------------
	// Master random seed (multi-seed experiments)
	//-----------------------------------------------------------------
	// -1 (default) = legacy behaviour, unchanged: GridSim's default
	// Poisson seed sequence plus unseeded Math.random() in the CDC/ORT
	// brokers. A value >= 0 seeds ALL randomness (workload Poisson streams
	// and broker choices) from that one number, so runs are reproducible
	// and different seeds give different workloads. Can also be set
	// without recompiling via the JVM option -Dca.seed=N (takes precedence).
	// See SeedControl.java.
	final long MASTER_SEED = -1L;

}
