package cloudsim.ext.datacenter;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import cloudsim.ext.Constants;
import cloudsim.ext.event.CloudSimEvent;
import cloudsim.ext.event.CloudSimEventListener;
import cloudsim.ext.event.CloudSimEvents;

/**
 * ActiveVmLoadBalancer load balances the tasks among available VM's in a way to even out
 * the number of active tasks at any given time on each VM.
 *
 * With Constants.ENABLE_ESCEL_WEIGHTED_CAP true, this class additionally
 * applies the SAME per-VM MIPS-weighted admission cap as the K-Means
 * hybrid and the capped-Throttled variant (see Constants.java) -- part 2
 * of the attribution test isolating the cap's contribution. False
 * (default) reproduces the original always-dispatch behaviour exactly.
 * 
 * @author Bhathiya Wickremasinghe
 *
 */
public class ActiveVmLoadBalancer extends VmLoadBalancer implements CloudSimEventListener {
	/** Holds the count current active allcoations on each VM */
	private Map<Integer, Integer> currentAllocationCounts;
	
	private Map<Integer, VirtualMachineState> vmStatesList;

	// --- Used only when Constants.ENABLE_ESCEL_WEIGHTED_CAP is true ---
	private final java.util.List vmList;
	private double configuredMips = 100000.0;

	/**
	 * Round-robin pointer used to break ties (multiple VMs sharing the
	 * same -- lowest -- allocation count, or multiple VMs never yet
	 * allocated to). Without this, scanning a HashMap-backed keySet and
	 * returning the first match always favours the same VM (in practice
	 * the lowest id, since HashMap iteration order for small dense
	 * integer keys comes out ascending in practice).
	 */
	private int rrTieBreaker = 0;
	
	
	public ActiveVmLoadBalancer(DatacenterController dcb){
		dcb.addCloudSimEventListener(this);
		this.vmStatesList = dcb.getVmStatesList();
		this.vmList       = dcb.getVmList();
		this.currentAllocationCounts = Collections.synchronizedMap(new HashMap<Integer, Integer>());
	}

	/** Sets the real host processor speed, for the weighted-cap formula only. */
	public void setVmMips(double mips) {
		this.configuredMips = mips;
	}

	/** MIPS = host processor speed x vCPUs, same as KMeanVmLoadBalancer.getVmMips(). */
	private final java.util.Map<Integer, Integer> cpusCache = new java.util.HashMap<Integer, Integer>();
	private double getVmMips(int vmId) {
		// Performance only (results identical): the vCPU count of a VM never changes,
		// so look it up once per VM instead of scanning the whole VM list on every
		// call (capForVm() calls this for every VM on every dispatch, which made a
		// 500-VM data center cost ~250,000 list steps per dispatch).
		Integer cpus = cpusCache.get(vmId);
		if (cpus == null && vmList != null) {
			for (int i = 0; i < vmList.size(); i++) {
				cloudsim.VirtualMachine vm = (cloudsim.VirtualMachine) vmList.get(i);
				if (vm.getVmId() == vmId) {
					cpus = vm.getCharacteristics().getCpus();
					cpusCache.put(vmId, cpus);
					break;
				}
			}
		}
		if (cpus != null) {
			// MIPS = host processor speed x number of vCPUs
			return configuredMips * cpus;
		}
		return configuredMips;
	}

	/** Same formula as KMeanVmLoadBalancer.capForVm() / ThrottledVmLoadBalancer.capForVm(). */
	private int capForVm(int vmId) {
		double mips = getVmMips(vmId);
		int cap = (int) Math.floor(mips / Constants.MIN_MIPS_SHARE_PER_JOB);
		return Math.max(1, cap);
	}

	/**
	 * @return The VM id of a VM so that the number of active tasks on each VM is kept
	 * 			evenly distributed among the VMs.
	 */
	@Override
	public int getNextAvailableVm(double cloudletLength){
		int vmId = -1;
		
		//Find the vm with least number of allocations
		
		//If all available vms are not allocated, allocated the new ones
		if (currentAllocationCounts.size() < vmStatesList.size()){
			java.util.List<Integer> fresh = new java.util.ArrayList<Integer>();
			for (int availableVmId : vmStatesList.keySet()){
				if (!currentAllocationCounts.containsKey(availableVmId)){
					fresh.add(availableVmId);
				}				
			}
			if (!fresh.isEmpty()) {
				vmId = fresh.get(rrTieBreaker % fresh.size());
				rrTieBreaker++;
			}
		} else {
			int currCount;
			int minCount = Integer.MAX_VALUE;
			java.util.List<Integer> candidates = new java.util.ArrayList<Integer>();
			
			for (int thisVmId : currentAllocationCounts.keySet()){
				currCount = currentAllocationCounts.get(thisVmId);
				if (Constants.ENABLE_ESCEL_WEIGHTED_CAP && currCount >= capForVm(thisVmId)) continue; // over this VM's admission cap
				if (currCount < minCount){
					minCount = currCount;
					candidates.clear();
					candidates.add(thisVmId);
				} else if (currCount == minCount) {
					candidates.add(thisVmId);
				}
			}
			if (!candidates.isEmpty()) {
				vmId = candidates.get(rrTieBreaker % candidates.size());
				rrTieBreaker++;
			}
		}
		
		allocatedVm(vmId);
		
		return vmId;
		
	}
	
	public void cloudSimEventFired(CloudSimEvent e) {
		if (e.getId() == CloudSimEvents.EVENT_CLOUDLET_ALLOCATED_TO_VM){
			int vmId = (Integer) e.getParameter(Constants.PARAM_VM_ID);
			
			Integer currCount = currentAllocationCounts.remove(vmId);
			if (currCount == null){
				currCount = 1;
			} else {
				currCount++;
			}
			
			currentAllocationCounts.put(vmId, currCount);
			
		} else if (e.getId() == CloudSimEvents.EVENT_VM_FINISHED_CLOUDLET){
			int vmId = (Integer) e.getParameter(Constants.PARAM_VM_ID);
			Integer currCount = currentAllocationCounts.remove(vmId);
			if (currCount != null){
				currCount--;
				currentAllocationCounts.put(vmId, currCount);
			}
		}
	}
	


}
