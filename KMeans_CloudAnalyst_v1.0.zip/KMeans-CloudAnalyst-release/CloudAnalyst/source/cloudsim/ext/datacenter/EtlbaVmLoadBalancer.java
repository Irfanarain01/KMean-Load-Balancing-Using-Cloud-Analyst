package cloudsim.ext.datacenter;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import cloudsim.ext.Constants;
import cloudsim.ext.event.CloudSimEvent;
import cloudsim.ext.event.CloudSimEventListener;
import cloudsim.ext.event.CloudSimEvents;

/**
 * ETLBA (Enhanced Throttled Load Balancing Algorithm), reimplemented from the published description
 * (Hanumantha Rao and Rajakumar, Scalable Computing: Practice and Experience 25(5), 2024), VM-level part:
 *  - availability index: one cloudlet per VM; a VM is available when it runs no cloudlet;
 *  - usage index: among available VMs choose the one with the lowest usage, where usage is the
 *    processing time of the VM's most recent task (VMs not yet used have usage 0);
 *  - if no VM is available, return -1 so the controller queues the request.
 * The paper's "nearest data center adoption" is a broker-level step; here the SBP is varied separately.
 * Ties are rotated, the same tie-break fix as the other baselines.
 */
public class EtlbaVmLoadBalancer extends VmLoadBalancer implements CloudSimEventListener, CompletionObserver {
    private final Map<Integer, VirtualMachineState> vmStatesList;
    private final Map<Integer, Integer> load = new HashMap<Integer, Integer>();
    private final Map<Integer, Double> usage = new HashMap<Integer, Double>();
    private int rrTieBreaker = 0;

    public EtlbaVmLoadBalancer(DatacenterController dcb) {
        this.vmStatesList = dcb.getVmStatesList();
        dcb.addCloudSimEventListener(this);
    }

    private int loadOf(int vmId) { Integer l = load.get(vmId); return l == null ? 0 : l; }

    @Override
    public int getNextAvailableVm(double cloudletLength) {
        java.util.List<Integer> cand = new java.util.ArrayList<Integer>();
        double best = Double.MAX_VALUE;
        for (Iterator<Integer> it = vmStatesList.keySet().iterator(); it.hasNext();) {
            int id = it.next();
            if (loadOf(id) > 0) continue;                       // busy: not in the available index
            Double u = usage.get(id);
            double us = u == null ? 0.0 : u;
            if (us < best) { best = us; cand.clear(); cand.add(id); }
            else if (us == best) cand.add(id);
        }
        int vmId = -1;
        if (!cand.isEmpty()) { vmId = cand.get(rrTieBreaker % cand.size()); rrTieBreaker++; }
        allocatedVm(vmId);
        return vmId;
    }

    public boolean wantsCompletions() { return true; }

    public void observeCompletion(int vmId, double length, double execTime) {
        long t0 = cloudsim.ext.study.Overhead.cpu();
        if (!usage.containsKey(vmId)) cloudsim.ext.study.Overhead.addState();
        usage.put(vmId, execTime);
        cloudsim.ext.study.Overhead.addUpdate(cloudsim.ext.study.Overhead.cpu() - t0);
    }

    public void cloudSimEventFired(CloudSimEvent e) {
        if (e.getId() == CloudSimEvents.EVENT_CLOUDLET_ALLOCATED_TO_VM) {
            int vmId = (Integer) e.getParameter(Constants.PARAM_VM_ID);
            load.put(vmId, loadOf(vmId) + 1);
            vmStatesList.put(vmId, VirtualMachineState.BUSY);
        } else if (e.getId() == CloudSimEvents.EVENT_VM_FINISHED_CLOUDLET) {
            int vmId = (Integer) e.getParameter(Constants.PARAM_VM_ID);
            int l = Math.max(0, loadOf(vmId) - 1);
            load.put(vmId, l);
            if (l == 0) vmStatesList.put(vmId, VirtualMachineState.AVAILABLE);
        }
    }
}
