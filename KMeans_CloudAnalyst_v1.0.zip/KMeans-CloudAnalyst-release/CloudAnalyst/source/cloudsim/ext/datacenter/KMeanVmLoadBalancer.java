package cloudsim.ext.datacenter;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import cloudsim.VirtualMachine;
import cloudsim.VMCharacteristics;
import cloudsim.ext.Constants;
import cloudsim.ext.event.CloudSimEvent;
import cloudsim.ext.event.CloudSimEventListener;
import cloudsim.ext.event.CloudSimEvents;

/**
 * KMeanVmLoadBalancer - K-Means clustering based VM load balancer.
 *
 * Clusters VMs into K groups (Constants.KMEANS_NUM_CLUSTERS, default 2) using two dimensions:
 *   X = MIPS  (processor speed × vCPUs, set via setVmMipsAndRam())
 *   Y = RAM   (memory in MB, read from VMCharacteristics)
 *
 * Dispatch policy (matches the paper's Algorithm 1, lines 18-20):
 *   1. Cluster selection: compute the mean CURRENT load of each cluster,
 *      U_k = (1/|S_k|) * sum load(vi). Prefer the cluster with the most
 *      free capacity right now.
 *   2. VM selection: within the preferred cluster, pick the least-loaded
 *      VM. With Constants.ENABLE_KMEANS_ADMISSION_CONTROL true, only a VM
 *      under its admission cap qualifies -- a flat cap for every VM, or,
 *      with ENABLE_KMEANS_WEIGHTED_ADMISSION_CONTROL also true, a per-VM
 *      cap derived from that VM's own MIPS (see capForVm()). If the
 *      preferred cluster has none, the other cluster is tried first.
 *   3. With admission control disabled (default), always dispatch to v* --
 *      like RR and ESCEL, never blocking. With it enabled, queue (-1) only
 *      if NO VM in ANY cluster is under the cap -- same coverage guarantee
 *      Throttled has, so the two remain directly comparable.
 *
 * "load(vi)" is tracked the same way ActiveVmLoadBalancer (ESCEL) tracks
 * it: a per-VM count of currently-executing cloudlets, incremented on
 * EVENT_CLOUDLET_ALLOCATED_TO_VM and decremented on
 * EVENT_VM_FINISHED_CLOUDLET. This is a real, continuous signal (not the
 * coarse binary AVAILABLE/BUSY flag used by Throttled), which is what lets
 * "cluster is less utilised" / "VM is free" be compared meaningfully.
 *
 * Bugs fixed vs original KMean.java / earlier versions of this class:
 *   1. Extends VmLoadBalancer — properly integrated into CA scheduling.
 *   2. Uses real VM MIPS and RAM — no hardcoded dummy data.
 *   3. Centroids randomly initialised from actual VM data points.
 *   4. Correct K-Means: assign ALL points THEN update centroids (no
 *      mid-assignment recalculation).
 *   5. Wrong centroid-update-before-assign order corrected.
 *   6. Distance calculation scaled per-feature (see mipsScale/ramScale)
 *      so RAM isn't numerically swamped by MIPS's larger magnitude.
 *   7. Cluster/VM selection now genuinely compares CURRENT LOAD between
 *      the two clusters (argmin U_k) instead of always preferring the
 *      higher-MIPS cluster and only touching the other one as a
 *      last-resort fallback when the preferred cluster was completely
 *      full. The previous logic never actually checked which cluster had
 *      more free resources — it hardcoded a static preference.
 *
 * NOTE on RAM variance: this class always reads the real per-VM memory
 * value, but until Simulation.createVM() was fixed, EVERY VM was created
 * with a hardcoded 512 MB regardless of GUI configuration, so RAM had
 * zero variance and K-Means's second dimension contributed nothing.
 * createVM() now reads the GUI-configured memory correctly, and — when
 * Constants.ENABLE_HETEROGENEOUS_VMS is true — assigns varying RAM/vCPU
 * tiers per VM, so clustering genuinely uses both MIPS and RAM. With
 * heterogeneity disabled (the default), this class reproduces the
 * original published behaviour exactly.
 */
public class KMeanVmLoadBalancer extends VmLoadBalancer implements CloudSimEventListener, CompletionObserver {

    private static final int MAX_ITERATIONS = 10;
    /** Silhouette is O(n^2); skip it (log n/a) above this pool size. */
    private static final int SILHOUETTE_MAX_N = 5000;

    private final Map<Integer, VirtualMachineState> vmStatesList;
    private final List vmList;   // raw List from DatacenterBroker

    /**
     * Real per-VM current load: number of cloudlets currently executing on
     * each VM right now. Tracked the same way ESCEL (ActiveVmLoadBalancer)
     * tracks it. This is load(vi) in the paper's Algorithm 1 — used to
     * compute each cluster's mean utilisation U_k and to pick the least
     * loaded VM within the chosen cluster. Not present => 0 (idle/free).
     */
    private final Map<Integer, Integer> currentLoad =
            Collections.synchronizedMap(new HashMap<Integer, Integer>());

    // MIPS per VM set from Simulation.java using host machine speed
    private double configuredMips = 100000.0;  // default from Table 8
    private double configuredRam  = 8192.0;    // default 8 GB in MB

    /** Cluster assignment: index -> clusterId (index matches vmIds[]) */
    private int[]    vmIds;
    private int[]    vmCluster;

    /** Centroid values for each cluster (kept in ORIGINAL units for reporting) */
    private double[] centroidMips;
    private double[] centroidRam;

    /**
     * Per-run feature scales (range = max-min) used ONLY inside the distance
     * calculation, so that MIPS (values in the tens/hundreds of thousands)
     * and RAM (values in the thousands of MB) contribute proportionally to
     * cluster assignment instead of MIPS dominating purely because of its
     * larger numeric scale. Without this, RAM can vary genuinely across VMs
     * and still have almost no effect on which cluster a VM lands in.
     */
    private double mipsScale = 1.0;
    private double ramScale  = 1.0;

    /**
     * Caches the clustering so it is only recomputed when the VM pool size
     * actually changes, instead of on every single dispatch call. Besides
     * the obvious performance cost of re-clustering from scratch on every
     * cloudlet (tens of thousands of times over a run), recomputing on
     * every call meant the very FIRST dispatch -- which can happen before
     * all VMs have finished registering -- got permanently logged as "the"
     * clustering result, hiding the real, mature clustering entirely.
     */
    private int lastClusteredN = -1;

    /**
     * Round-robin pointer used to break ties when multiple VMs in the
     * chosen cluster share the same (lowest) current load -- which is
     * common, since many VMs are simultaneously idle. Without this,
     * scanning "first VM found with the minimum load" always prefers
     * whichever VM happens to sort first in vmIds (in practice VM id 0,
     * since HashMap iteration order for small dense integer keys comes
     * out ascending), so that one VM absorbs a hugely disproportionate
     * share of dispatches. Rotating among tied candidates fixes this.
     */
    private int rrTieBreaker = 0;

    /** Name of the owning data center's broker (e.g. "DC1-Broker"), for clear per-DC logging. */
    private final String ownerName;

    public KMeanVmLoadBalancer(DatacenterController dcb) {
        this.vmStatesList = dcb.getVmStatesList();
        this.vmList       = dcb.getVmList();
        this.ownerName    = dcb.get_name();
        dcb.addCloudSimEventListener(this);
    }

    /**
     * Called from Simulation.java after controller is created,
     * passing the real host-level processor speed and memory.
     *
     * @param mips  processor speed × processors per machine (e.g. 100000)
     * @param ram   machine memory in MB (e.g. 262144 for 256 GB)
     */
    public void setVmMipsAndRam(double mips, double ram) {
        this.configuredMips = mips;
        this.configuredRam  = ram;
    }

    /**
     * Returns the VM id chosen by the two-level K-Means dispatch policy:
     * pick the less-utilised cluster (by real current load), then the
     * least-loaded VM within it.
     *
     * With admission control disabled (default), this always returns a
     * valid VM id (never -1) as long as at least one VM exists, matching
     * RR/ESCEL's behaviour -- it will dispatch even onto an already-busy
     * VM if that's the least-loaded option available.
     *
     * With Constants.ENABLE_KMEANS_ADMISSION_CONTROL true, a VM is only
     * chosen if its current load is below KMEANS_MAX_CONCURRENT_PER_VM.
     * The preferred (less-utilised) cluster is tried first; if it has no
     * VM under the cap, the other cluster is tried; only if NO VM in
     * EITHER cluster is under the cap does this return -1 to queue,
     * exactly like Throttled. This avoids queueing while the other
     * cluster still has genuine spare capacity.
     */
    @Override
    public int getNextAvailableVm(double cloudletLength) {
        if (vmStatesList == null || vmStatesList.isEmpty()) {
            return -1;
        }

        runKMeans();
        if (SPEED_AWARE) return speedAwarePick(cloudletLength);

        int k = centroidMips.length;

        // Step 1 (Algorithm 1, line 19): U_k = mean current load of cluster k.
        double[] sumLoad = new double[k];
        int[]    count   = new int[k];
        for (int idx = 0; idx < vmIds.length; idx++) {
            int c = vmCluster[idx];
            sumLoad[c] += loadOf(vmIds[idx]);
            count[c]++;
        }

        final boolean preferCapability = Constants.ENABLE_KMEANS_SIZE_AWARE_ROUTING
                && cloudletLength >= Constants.KMEANS_HEAVY_JOB_THRESHOLD;

        // Rank non-empty clusters. Normally: ascending utilisation (least
        // utilised first) -- with k=2 this is just "best cluster then the
        // other one", written generally so it still works if k changes.
        // When size-aware routing is on AND this job is "heavy", rank by
        // DESCENDING MIPS instead -- prefer the more capable cluster even
        // if it's currently a bit busier, since finishing a heavy job
        // faster matters more than avoiding a small amount of contention.
        // Light jobs still use plain utilisation ordering either way,
        // since their absolute processing time barely differs by VM speed.
        List<Integer> clusterOrder = new ArrayList<Integer>();
        for (int c = 0; c < k; c++) {
            if (count[c] > 0) clusterOrder.add(c);
        }
        Collections.sort(clusterOrder, new java.util.Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                if (preferCapability) {
                    return Double.compare(centroidMips[b], centroidMips[a]); // descending
                }
                double ua = sumLoad[a] / count[a];
                double ub = sumLoad[b] / count[b];
                return Double.compare(ua, ub); // ascending
            }
        });

        int selectedVmId = -1;

        if (!Constants.ENABLE_KMEANS_ADMISSION_CONTROL) {
            // Original always-dispatch behaviour: least-loaded VM in the
            // most-preferred (first) cluster, with round-robin tie-break.
            if (!clusterOrder.isEmpty()) {
                selectedVmId = pickLeastLoaded(clusterOrder.get(0), false);
            }
            if (selectedVmId == -1) {
                // Defensive fallback across all VMs (shouldn't normally
                // trigger -- see original comment history).
                selectedVmId = pickLeastLoadedGlobal(Integer.MAX_VALUE);
            }
        } else {
            // Admission-controlled: walk clusters in preference order,
            // only accepting a VM under its own cap (see capForVm());
            // queue (-1) only if nothing in ANY cluster qualifies.
            for (int c : clusterOrder) {
                selectedVmId = pickLeastLoaded(c, true);
                if (selectedVmId != -1) break;
            }
        }

        allocatedVm(selectedVmId);
        return selectedVmId;
    }

    /**
     * Finds the least-loaded VM in the given cluster, using round-robin
     * tie-breaking among equally-loaded qualifying candidates. Returns -1
     * if no VM in this cluster qualifies (either the cluster is empty, or
     * -- when applyAdmissionCap is true -- every VM in it is already at or
     * above its own cap, see capForVm()).
     *
     * @param applyAdmissionCap false disables the cap entirely (matches
     *        the original always-dispatch behaviour); true enforces each
     *        candidate VM's own cap from capForVm().
     */
    private int pickLeastLoaded(int cluster, boolean applyAdmissionCap) {
        List<Integer> candidates = new ArrayList<Integer>();
        int bestLoad = Integer.MAX_VALUE;
        for (int idx = 0; idx < vmIds.length; idx++) {
            if (vmCluster[idx] != cluster) continue;
            int vmId = vmIds[idx];
            int load = loadOf(vmId);
            if (applyAdmissionCap && load >= capForVm(vmId)) continue; // over this VM's admission cap
            if (load < bestLoad) {
                bestLoad = load;
                candidates.clear();
                candidates.add(vmId);
            } else if (load == bestLoad) {
                candidates.add(vmId);
            }
        }
        if (candidates.isEmpty()) return -1;
        int selected = candidates.get(rrTieBreaker % candidates.size());
        rrTieBreaker++;
        return selected;
    }

    /**
     * Admission cap for this specific VM. With
     * Constants.ENABLE_KMEANS_WEIGHTED_ADMISSION_CONTROL false, every VM
     * gets the flat KMEANS_MAX_CONCURRENT_PER_VM. When true, the cap is
     * max(1, floor(vmMips / MIN_MIPS_SHARE_PER_JOB)), where vmMips is
     * host speed x vCPUs (getVmMips), so a 2-vCPU VM gets a higher cap
     * than a 1-vCPU VM in the same data center. Always at least 1.
     */
    private int capForVm(int vmId) {
        if (!Constants.ENABLE_KMEANS_WEIGHTED_ADMISSION_CONTROL) {
            return Constants.KMEANS_MAX_CONCURRENT_PER_VM;
        }
        double mips = getVmMips(vmId);
        int cap = (int) Math.floor(mips / Constants.MIN_MIPS_SHARE_PER_JOB);
        return Math.max(1, cap);
    }

    /**
     * Same as pickLeastLoaded, but across ALL VMs regardless of cluster.
     * Used only as a defensive fallback when admission control is
     * disabled and, for some unexpected reason, every cluster came back
     * empty (shouldn't normally happen when at least one VM exists).
     */
    private int pickLeastLoadedGlobal(int maxLoad) {
        List<Integer> candidates = new ArrayList<Integer>();
        int bestLoad = Integer.MAX_VALUE;
        for (int vmId : vmIds) {
            int load = loadOf(vmId);
            if (load >= maxLoad) continue;
            if (load < bestLoad) {
                bestLoad = load;
                candidates.clear();
                candidates.add(vmId);
            } else if (load == bestLoad) {
                candidates.add(vmId);
            }
        }
        if (candidates.isEmpty()) return -1;
        int selected = candidates.get(rrTieBreaker % candidates.size());
        rrTieBreaker++;
        return selected;
    }

    /** Current number of cloudlets executing on this VM right now (0 = idle/free). */
    private int loadOf(int vmId) {
        Integer load = currentLoad.get(vmId);
        return (load == null) ? 0 : load;
    }

    /**
     * Standard K-Means clustering on (MIPS, RAM) dimensions.
     *
     * Step 1: Build data from real VM MIPS and RAM values.
     * Step 2: Random centroid initialisation from data points.
     * Step 3: Assign ALL points to nearest centroid.
     * Step 4: Update centroids from assignments.
     * Step 5: Repeat 3-4 until convergence or MAX_ITERATIONS.
     */
    /** Timed wrapper: clustering cost (including the cache check) is added to the overhead counters. */
    private void runKMeans() {
        long t0 = cloudsim.ext.study.Overhead.cpu();
        runKMeansInner();
        cloudsim.ext.study.Overhead.addCluster(cloudsim.ext.study.Overhead.cpu() - t0);
    }

    private void runKMeansInner() {
        List<Integer> activeIds = new ArrayList<Integer>(vmStatesList.keySet());
        int n = activeIds.size();
        if (n == 0) return;

        // Cache: skip recomputation if the VM pool hasn't changed size
        // since last time. Re-clustering from scratch on every single
        // dispatch call is wasteful (this ran tens of thousands of times
        // per simulation) and, worse, means the very first dispatch --
        // which can fire before every VM has finished registering -- was
        // being treated identically to a dispatch happening once the pool
        // is fully populated. Recluster whenever the count changes (VMs
        // still coming online, or, in principle, being removed).
        if (n == lastClusteredN && vmCluster != null) {
            return;
        }
        lastClusteredN = n;

        vmIds      = new int[n];
        vmCluster  = new int[n];
        double[] mipsData = new double[n];
        double[] ramData  = new double[n];

        // Build data arrays using REAL VM MIPS and RAM
        for (int i = 0; i < n; i++) {
            int vmId    = activeIds.get(i);
            vmIds[i]    = vmId;
            mipsData[i] = getVmMips(vmId);   // real MIPS from host config
            ramData[i]  = getVmRam(vmId);    // real RAM from VMCharacteristics
        }

        // Compute feature scales (range) so distance is not dominated by
        // whichever of MIPS/RAM happens to have the larger raw magnitude.
        // If a feature has zero variance (e.g. homogeneous-VM baseline
        // mode), its range is 0; guard with 1.0 so it contributes exactly
        // 0 to every distance rather than dividing by zero.
        double mipsMin = mipsData[0], mipsMax = mipsData[0];
        double ramMin  = ramData[0],  ramMax  = ramData[0];
        for (int i = 1; i < n; i++) {
            if (mipsData[i] < mipsMin) mipsMin = mipsData[i];
            if (mipsData[i] > mipsMax) mipsMax = mipsData[i];
            if (ramData[i]  < ramMin)  ramMin  = ramData[i];
            if (ramData[i]  > ramMax)  ramMax  = ramData[i];
        }
        mipsScale = (mipsMax - mipsMin > 0) ? (mipsMax - mipsMin) : 1.0;
        ramScale  = (ramMax  - ramMin  > 0) ? (ramMax  - ramMin)  : 1.0;

        int k = Math.max(1, Math.min(Constants.KMEANS_NUM_CLUSTERS, n));
        int restarts = Math.max(1, Constants.KMEANS_NUM_RESTARTS);

        // Best-of-restarts holders (with the default of 1 restart this
        // just carries the single run through unchanged).
        int[]    bestCluster = null;
        double[] bestMips    = null;
        double[] bestRam     = null;
        double   bestWcss    = Double.MAX_VALUE;

        for (int restart = 0; restart < restarts; restart++) {

        centroidMips = new double[k];
        centroidRam  = new double[k];

        // Fix 3: Random centroid initialisation from actual data points.
        // Seeded (restart r uses KMEANS_BASE_SEED + r) so runs are
        // reproducible; restart 0 with the default seed 42 is exactly the
        // previous behaviour.
        Random rand   = new Random(Constants.KMEANS_BASE_SEED + restart);
        List<Integer> chosen = new ArrayList<Integer>();
        for (int c = 0; c < k; c++) {
            int pick;
            do { pick = rand.nextInt(n); } while (chosen.contains(pick));
            chosen.add(pick);
            centroidMips[c] = mipsData[pick];
            centroidRam[c]  = ramData[pick];
        }

        boolean changed = true;
        int iter = 0;

        // Sentinel: -1 means "not yet assigned". Using 0 as the default
        // (Java's int[] default) would make the very first VM whose real
        // nearest centroid IS cluster 0 look like "no change happened",
        // which is harmless for a single VM but combines badly with the
        // empty-cluster case below if it's never corrected.
        Arrays.fill(vmCluster, -1);

        while (changed && iter < MAX_ITERATIONS) {
            changed = false;
            iter++;

            // Fix 4 & 5: Assign ALL points first
            for (int i = 0; i < n; i++) {
                int nearest = nearestCentroid(mipsData[i], ramData[i], k);
                if (vmCluster[i] != nearest) {
                    vmCluster[i] = nearest;
                    changed = true;
                }
            }

            // Then update centroids from new assignments
            double[] sumMips = new double[k];
            double[] sumRam  = new double[k];
            int[]    count   = new int[k];

            for (int i = 0; i < n; i++) {
                int c = vmCluster[i];
                sumMips[c] += mipsData[i];
                sumRam[c]  += ramData[i];
                count[c]++;
            }

            for (int c = 0; c < k; c++) {
                if (count[c] > 0) {
                    centroidMips[c] = sumMips[c] / count[c];
                    centroidRam[c]  = sumRam[c]  / count[c];
                }
            }

            // Empty-cluster guard: if a centroid ended up with zero VMs
            // assigned to it (possible with unlucky random initialisation,
            // especially at small n or low real variance), it would
            // otherwise stay frozen at its old position forever and never
            // receive any VMs in later iterations either. Reseed it to the
            // data point currently farthest (in scaled distance) from
            // whichever centroid it IS closest to, and force another
            // iteration so points get a chance to redistribute around it.
            for (int c = 0; c < k; c++) {
                if (count[c] == 0) {
                    int    farthestIdx  = -1;
                    double farthestDist = -1;
                    for (int i = 0; i < n; i++) {
                        int    ownCluster = vmCluster[i];
                        double dm = (mipsData[i] - centroidMips[ownCluster]) / mipsScale;
                        double dr = (ramData[i]  - centroidRam[ownCluster])  / ramScale;
                        double d  = Math.sqrt(dm * dm + dr * dr);
                        if (d > farthestDist) {
                            farthestDist = d;
                            farthestIdx  = i;
                        }
                    }
                    if (farthestIdx != -1) {
                        centroidMips[c] = mipsData[farthestIdx];
                        centroidRam[c]  = ramData[farthestIdx];
                        changed = true; // force at least one more pass
                    }
                }
            }
        }

        // Score this restart and keep it if it is the best so far.
        double wcss = computeWcss(mipsData, ramData, k);
        if (wcss < bestWcss) {
            bestWcss    = wcss;
            bestCluster = vmCluster.clone();
            bestMips    = centroidMips.clone();
            bestRam     = centroidRam.clone();
        }
        } // end restarts loop

        vmCluster    = bestCluster;
        centroidMips = bestMips;
        centroidRam  = bestRam;

        logClusterSummary(mipsData, ramData, k, bestWcss, restarts);
    }

    /**
     * Prints per-cluster size/centroid stats every time clustering is
     * actually recomputed (now only when the VM pool size changes, thanks
     * to the caching in runKMeans() above -- not instance-static and not
     * "first call only", since either of those previously meant only ONE
     * data center's (and often an unrepresentative, too-early) snapshot
     * ever got logged for the whole simulation. Labelled by owner (e.g.
     * "DC1-Broker") so multi-DC console output is unambiguous.
     */
    private void logClusterSummary(double[] mipsData, double[] ramData, int k,
                                   double wcss, int restarts) {
        if (!Boolean.parseBoolean(System.getProperty("ca.kmLog", "true"))) return;
        int[] count = new int[k];
        for (int c : vmCluster) {
            count[c]++;
        }
        System.out.println("[K-Means LB] " + ownerName + " clustering summary (n=" + vmIds.length + "):");
        for (int c = 0; c < k; c++) {
            System.out.println("  Cluster " + c + ": n=" + count[c]
                    + "  centroidMips=" + centroidMips[c]
                    + "  centroidRam=" + centroidRam[c]);
        }
        if (Constants.ENABLE_KMEANS_QUALITY_LOGGING) {
            double sil = computeSilhouette(mipsData, ramData, k);
            System.out.println("[K-Means LB] " + ownerName + " quality: K=" + k
                    + " restarts=" + restarts
                    + " WCSS=" + String.format("%.4f", wcss)
                    + " silhouette=" + (Double.isNaN(sil) ? "n/a" : String.format("%.4f", sil)));
        }
    }

    /**
     * Within-cluster sum of squares: sum over VMs of the squared distance
     * to the VM's own centroid, in the same min-max scaled (MIPS, RAM)
     * space used for clustering. Lower is tighter; used to pick the best
     * restart and for the elbow analysis.
     */
    private double computeWcss(double[] mipsData, double[] ramData, int k) {
        double sum = 0;
        for (int i = 0; i < mipsData.length; i++) {
            int c = vmCluster[i];
            double dm = (mipsData[i] - centroidMips[c]) / mipsScale;
            double dr = (ramData[i]  - centroidRam[c])  / ramScale;
            sum += dm * dm + dr * dr;
        }
        return sum;
    }

    /**
     * Mean silhouette score in the scaled (MIPS, RAM) space: for each VM,
     * a = mean distance to the other VMs in its cluster, b = smallest mean
     * distance to another cluster, s = (b - a) / max(a, b); a VM alone in
     * its cluster scores 0. Returns NaN when it is undefined (fewer than
     * two non-empty clusters) or the pool is larger than SILHOUETTE_MAX_N.
     * Range -1..1; higher means better-separated clusters.
     */
    private double computeSilhouette(double[] mipsData, double[] ramData, int k) {
        int n = mipsData.length;
        if (k < 2 || n < 3 || n > SILHOUETTE_MAX_N) return Double.NaN;
        int[] count = new int[k];
        for (int c : vmCluster) count[c]++;
        int nonEmpty = 0;
        for (int c = 0; c < k; c++) if (count[c] > 0) nonEmpty++;
        if (nonEmpty < 2) return Double.NaN;

        double total = 0;
        for (int i = 0; i < n; i++) {
            double[] sumDist = new double[k];
            for (int j = 0; j < n; j++) {
                if (j == i) continue;
                double dm = (mipsData[i] - mipsData[j]) / mipsScale;
                double dr = (ramData[i]  - ramData[j])  / ramScale;
                sumDist[vmCluster[j]] += Math.sqrt(dm * dm + dr * dr);
            }
            int ci = vmCluster[i];
            double s = 0;
            if (count[ci] > 1) {
                double a = sumDist[ci] / (count[ci] - 1);
                double b = Double.MAX_VALUE;
                for (int c = 0; c < k; c++) {
                    if (c != ci && count[c] > 0) {
                        b = Math.min(b, sumDist[c] / count[c]);
                    }
                }
                double m = Math.max(a, b);
                s = (m > 0) ? (b - a) / m : 0;
            }
            total += s;
        }
        return total / n;
    }

    /**
     * Euclidean distance in (MIPS, RAM) space, with each dimension divided
     * by its scale (feature range) before squaring. This is the standard
     * fix for mixed-scale K-Means: without it, MIPS (~1e4-1e5) swamps RAM
     * (~1e3-1e4) in the distance calculation regardless of how much RAM
     * actually varies across the VM pool.
     */
    private int nearestCentroid(double mips, double ram, int k) {
        int    best     = 0;
        double bestDist = Double.MAX_VALUE;
        for (int c = 0; c < k; c++) {
            double dm   = (mips - centroidMips[c]) / mipsScale;
            double dr   = (ram  - centroidRam[c])  / ramScale;
            double dist = Math.sqrt(dm * dm + dr * dr);
            if (dist < bestDist) {
                bestDist = dist;
                best     = c;
            }
        }
        return best;
    }

    /**
     * Returns MIPS for a VM.
     * Uses configuredMips (set from host machine speed via setVmMipsAndRam).
     * All VMs in the same DC share the same host speed in CA's model,
     * so configuredMips × getCpus() gives total MIPS per VM.
     */
    private final java.util.Map<Integer, Integer> cpusCache = new java.util.HashMap<Integer, Integer>();
	private double getVmMips(int vmId) {
		// Performance only (results identical): the vCPU count of a VM never changes,
		// so look it up once per VM instead of scanning the whole VM list on every
		// call (capForVm() calls this for every VM on every dispatch, which made a
		// 500-VM data center cost ~250,000 list steps per dispatch).
		Integer cpus = cpusCache.get(vmId);
		if (cpus == null && vmList != null) {
			for (int i = 0; i < vmList.size(); i++) {
				VirtualMachine vm = (VirtualMachine) vmList.get(i);
				if (vm.getVmId() == vmId) {
					cpus = vm.getCharacteristics().getCpus();
					cpusCache.put(vmId, cpus);
					break;
				}
			}
		}
		if (cpus != null) {
			// MIPS = host processor speed x number of vCPUs
			return configuredMips * cpus;
		}
		return configuredMips;
	}

    /**
     * Returns RAM for a VM from VMCharacteristics.
     * Falls back to configuredRam if VM not found.
     */
    /** VM RAM never changes after creation, so it is cached per VM (performance only; results unchanged). */
    private final java.util.Map<Integer, Double> ramCache = new java.util.HashMap<Integer, Double>();

    private double getVmRam(int vmId) {
        Double cached = ramCache.get(vmId);
        if (cached != null) return cached;
        if (vmList != null) {
            for (int i = 0; i < vmList.size(); i++) {
                VirtualMachine vm = (VirtualMachine) vmList.get(i);
                if (vm.getVmId() == vmId) {
                    double ram = vm.getCharacteristics().getMemory();
                    ramCache.put(vmId, ram);
                    return ram;
                }
            }
        }
        return configuredRam;
    }

    @Override
    public void cloudSimEventFired(CloudSimEvent e) {
        if (e.getId() == CloudSimEvents.EVENT_CLOUDLET_ALLOCATED_TO_VM) {
            int vmId = (Integer) e.getParameter(Constants.PARAM_VM_ID);
            vmStatesList.put(vmId, VirtualMachineState.BUSY);
            currentLoad.put(vmId, loadOf(vmId) + 1);
        } else if (e.getId() == CloudSimEvents.EVENT_VM_FINISHED_CLOUDLET) {
            int vmId = (Integer) e.getParameter(Constants.PARAM_VM_ID);
            vmStatesList.put(vmId, VirtualMachineState.AVAILABLE);
            int newLoad = loadOf(vmId) - 1;
            currentLoad.put(vmId, Math.max(newLoad, 0));
        }
    }

    // ------------------------------------------------------------------
    // Speed-aware mode (-Dca.km2=true): cluster VMs on their MEASURED
    // per-slot speed instead of nominal MIPS/RAM. In CA a host time-shares
    // its processors among all vCPUs placed on it, so a VM's real speed
    // depends on how crowded its host is, which nominal MIPS cannot show.
    // Each completed cloudlet gives a sample (length / execution time); with
    // the cap at one cloudlet per vCPU no cloudlet shares a vCPU, so the
    // sample equals the per-vCPU share of the VM's host.
    // Unmeasured VMs count as fastest (optimistic start), so every VM gets
    // sampled early. Tiers are re-clustered every TIER_REFRESH samples.
    // Optional size-aware assignment (-Dca.km2sita=true): cloudlets below
    // the large-request threshold try the SLOWEST tier first, keeping the
    // fast tier free for large ones.
    // ------------------------------------------------------------------
    static final boolean SPEED_AWARE = Boolean.getBoolean("ca.km2");
    static final boolean SITA = Boolean.getBoolean("ca.km2sita");
    static final int SPEED_K = Integer.getInteger("ca.km2k", 2).intValue();
    static final int TIER_REFRESH = Integer.getInteger("ca.km2refresh", 25).intValue();
    /** Smoothing factor of the speed estimate (Eq. 9); default 0.3, override with -Dca.km2alpha. */
    static final double ALPHA = Double.parseDouble(System.getProperty("ca.km2alpha", "0.3"));
    private long completionsSeen = 0;
    private boolean allMeasured = false;
    static final double SINGLE_TIER_SPREAD = 0.02;
    /** Extra cloudlets a VM may take above its cap when NO VM is under its cap (0 = queue, as before). */
    static final int SOFT_EXTRA = Integer.getInteger("ca.km2soft", 0).intValue();
    private final java.util.Map<Integer, Double> speedEst = new java.util.HashMap<Integer, Double>();
    private final java.util.Map<Integer, Integer> speedTier = new java.util.HashMap<Integer, Integer>();
    private double[] tierCentroid = new double[0];
    private int samplesSinceTiers = Integer.MAX_VALUE / 2;
    private int tiersForN = -1;

    /** Called by the controller when a cloudlet completes on vmId. */
    public boolean wantsCompletions() { return SPEED_AWARE; }

    public void observeCompletion(int vmId, double length, double execTime) {
        if (!SPEED_AWARE || execTime <= 0 || length <= 0) return;
        long t0 = cloudsim.ext.study.Overhead.cpu();
        double rate = length / execTime;
        Double old = speedEst.get(vmId);
        if (old == null) cloudsim.ext.study.Overhead.addState();
        speedEst.put(vmId, old == null ? rate : (1 - ALPHA) * old + ALPHA * rate);
        samplesSinceTiers++;
        completionsSeen++;
        if (!allMeasured && vmIds != null && speedEst.size() >= vmIds.length) {
            allMeasured = true;
            String dc = ownerName.endsWith("-Broker") ? ownerName.substring(0, ownerName.length() - 7) : ownerName;
            cloudsim.ext.study.Overhead.learnedAt(dc, completionsSeen, gridsim.GridSim.clock());
        }
        cloudsim.ext.study.Overhead.addUpdate(cloudsim.ext.study.Overhead.cpu() - t0);
    }

    private void refreshTiers() {
        if (samplesSinceTiers < TIER_REFRESH && tiersForN == vmIds.length) return;
        long ovT0 = cloudsim.ext.study.Overhead.cpu();
        try { refreshTiersInner(); } finally {
            cloudsim.ext.study.Overhead.addCluster(cloudsim.ext.study.Overhead.cpu() - ovT0);
        }
    }

    private void refreshTiersInner() {
        samplesSinceTiers = 0; tiersForN = vmIds.length;
        speedTier.clear();
        java.util.List<Double> vals = new java.util.ArrayList<Double>();
        for (int id : vmIds) { Double v = speedEst.get(id); if (v != null) vals.add(v); }
        if (vals.isEmpty()) { tierCentroid = new double[0]; return; }
        java.util.Collections.sort(vals);
        double lo = vals.get(0), hi = vals.get(vals.size() - 1);
        int k = (hi - lo) / hi < SINGLE_TIER_SPREAD ? 1 : Math.min(SPEED_K, vals.size());
        double[] c = new double[k];
        for (int j = 0; j < k; j++) c[j] = vals.get((int) Math.round((j + 0.5) * vals.size() / k - 0.5));
        for (int it = 0; it < 30; it++) {
            double[] sum = new double[k]; int[] cnt = new int[k];
            for (int i = 0; i < vals.size(); i++) {
                int best = 0;
                for (int j = 1; j < k; j++) if (Math.abs(vals.get(i) - c[j]) < Math.abs(vals.get(i) - c[best])) best = j;
                sum[best] += vals.get(i); cnt[best]++;
            }
            boolean moved = false;
            for (int j = 0; j < k; j++) if (cnt[j] > 0) { double nc = sum[j] / cnt[j]; if (nc != c[j]) moved = true; c[j] = nc; }
            if (!moved) break;
        }
        tierCentroid = c;
        for (int id : vmIds) {
            Double v = speedEst.get(id);
            if (v == null) continue;
            int best = 0;
            for (int j = 1; j < k; j++) if (Math.abs(v - c[j]) < Math.abs(v - c[best])) best = j;
            speedTier.put(id, best);
        }
    }

    private int speedAwarePick(double cloudletLength) {
        refreshTiers();
        final int k = tierCentroid.length;
        java.util.List<Integer> order = new java.util.ArrayList<Integer>();
        for (int j = 0; j < k; j++) order.add(j);
        final boolean small = SITA && cloudletLength >= 0 && cloudletLength < Constants.KMEANS_HEAVY_JOB_THRESHOLD;
        java.util.Collections.sort(order, new java.util.Comparator<Integer>() {
            public int compare(Integer a, Integer b) {
                return small ? Double.compare(tierCentroid[a], tierCentroid[b]) : Double.compare(tierCentroid[b], tierCentroid[a]);
            }
        });
        order.add(0, -1); // -1 = not yet measured (tried first, so every VM gets sampled)
        int sel = pickInTiers(order, 0);
        if (sel == -1 && SOFT_EXTRA > 0) sel = pickInTiers(order, SOFT_EXTRA);
        if (sel != -1) allocatedVm(sel);
        return sel;
    }

    /** First tier (in order) holding a VM with load < cap + extra; least-loaded inside the tier, ties rotated. */
    private int pickInTiers(java.util.List<Integer> order, int extra) {
        for (int t : order) {
            java.util.List<Integer> cand = new java.util.ArrayList<Integer>();
            int bestLoad = Integer.MAX_VALUE;
            for (int id : vmIds) {
                Integer tier = speedTier.get(id);
                int g = (tier == null) ? -1 : tier;
                if (g != t) continue;
                int load = loadOf(id);
                if (Constants.ENABLE_KMEANS_ADMISSION_CONTROL && load >= capForVm(id) + extra) continue;
                if (load < bestLoad) { bestLoad = load; cand.clear(); cand.add(id); }
                else if (load == bestLoad) cand.add(id);
            }
            if (!cand.isEmpty()) {
                int selected = cand.get(rrTieBreaker % cand.size());
                rrTieBreaker++;
                return selected;
            }
        }
        return -1;
    }
}
