package cloudsim.ext.datacenter;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import cloudsim.ext.Constants;
import cloudsim.ext.event.CloudSimEvent;
import cloudsim.ext.event.CloudSimEventListener;
import cloudsim.ext.event.CloudSimEvents;

/**
 * ReT-ELBa (Response Time Efficient Load Balancer), reimplemented from the published description
 * (Rashid and Nakpih, Asian J. Res. Comput. Sci. 17(5), 2024, Algorithm 1). Thresholds as published:
 * t_v = 0.7 and t_r = 0.5. All VMs form the primary list; a VM is engaged while it runs a cloudlet
 * (one per VM, as in Throttled). When at least 70% of the VMs are engaged and at least 50% of the
 * engaged VMs run a bigger request, the free VMs form the secondary list and serve smaller requests
 * only; a bigger request then waits in the controller's queue.
 * Assumptions where the paper is silent (stated in our paper): a request is "bigger" when its
 * per-request instruction length is at least 2000 (run with -Dca.perRequestLength=true); a free VM is
 * chosen in index order with ties rotated (the same tie-break fix as the other baselines).
 */
public class RetElbaVmLoadBalancer extends VmLoadBalancer implements CloudSimEventListener {
    static final double TV = 0.7, TR = 0.5;
    private final Map<Integer, VirtualMachineState> vmStatesList;
    private final Map<Integer, Integer> load = new HashMap<Integer, Integer>();
    private final Map<Integer, Boolean> runningBig = new HashMap<Integer, Boolean>();
    private final Map<Integer, Boolean> pendingBig = new HashMap<Integer, Boolean>();
    private int rrTieBreaker = 0;

    public RetElbaVmLoadBalancer(DatacenterController dcb) {
        this.vmStatesList = dcb.getVmStatesList();
        dcb.addCloudSimEventListener(this);
    }

    private int loadOf(int vmId) { Integer l = load.get(vmId); return l == null ? 0 : l; }

    @Override
    public int getNextAvailableVm(double cloudletLength) {
        int n = vmStatesList.size(), engaged = 0, bigEngaged = 0;
        java.util.List<Integer> free = new java.util.ArrayList<Integer>();
        for (Iterator<Integer> it = vmStatesList.keySet().iterator(); it.hasNext();) {
            int id = it.next();
            if (loadOf(id) > 0) {
                engaged++;
                Boolean b = runningBig.get(id);
                if (b != null && b) bigEngaged++;
            } else free.add(id);
        }
        boolean reserve = n > 0 && engaged > 0 && engaged >= TV * n && bigEngaged >= TR * engaged;
        boolean big = cloudletLength >= Constants.KMEANS_HEAVY_JOB_THRESHOLD;
        int vmId = -1;
        if (!(reserve && big) && !free.isEmpty()) {
            vmId = free.get(rrTieBreaker % free.size());
            rrTieBreaker++;
            if (cloudletLength >= 0) pendingBig.put(vmId, big);
        }
        allocatedVm(vmId);
        return vmId;
    }

    public void cloudSimEventFired(CloudSimEvent e) {
        if (e.getId() == CloudSimEvents.EVENT_CLOUDLET_ALLOCATED_TO_VM) {
            int vmId = (Integer) e.getParameter(Constants.PARAM_VM_ID);
            load.put(vmId, loadOf(vmId) + 1);
            Boolean b = pendingBig.get(vmId);
            runningBig.put(vmId, b != null && b);
            vmStatesList.put(vmId, VirtualMachineState.BUSY);
        } else if (e.getId() == CloudSimEvents.EVENT_VM_FINISHED_CLOUDLET) {
            int vmId = (Integer) e.getParameter(Constants.PARAM_VM_ID);
            int l = Math.max(0, loadOf(vmId) - 1);
            load.put(vmId, l);
            if (l == 0) { runningBig.remove(vmId); vmStatesList.put(vmId, VirtualMachineState.AVAILABLE); }
        }
    }
}
