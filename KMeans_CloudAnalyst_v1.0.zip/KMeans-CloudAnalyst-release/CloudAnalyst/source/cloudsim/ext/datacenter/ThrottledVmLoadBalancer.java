package cloudsim.ext.datacenter;

import java.util.Iterator;
import java.util.Map;

import cloudsim.ext.Constants;
import cloudsim.ext.event.CloudSimEvent;
import cloudsim.ext.event.CloudSimEventListener;
import cloudsim.ext.event.CloudSimEvents;

/**
 * This class implements {@link VmLoadBalancer} as a Throttled load balancer. Each VM is
 * allocated only one task at a time and can be allocated another task only when the current
 * task has completed. The ThrottledVmLoadBalancer does not implement any task queueing 
 * functionality, but returns a valid VM id in the <code>getNextAvailableVm</code>
 * only if available. The calling {@link DatacenterController} should implement the task 
 * queueing locally.
 * 
 * The ThrottledVmLoadBalancer implements CloudSimEventListener to get notified of the VM's
 * being allocated and freed up by the {@link DatacenterController}
 *
 * With Constants.ENABLE_THROTTLED_WEIGHTED_CAP true, this class instead
 * applies the SAME per-VM MIPS-weighted admission cap as the K-Means
 * hybrid (see KMeanVmLoadBalancer and Constants.java) -- an attribution
 * test to isolate the cap's contribution from K-Means's clustering and
 * size-aware routing. False (default) reproduces the original strict
 * single-tenant-per-VM behaviour exactly.
 * 
 * @author Bhathiya Wickremasinghe
 *
 */
public class ThrottledVmLoadBalancer extends VmLoadBalancer implements CloudSimEventListener {
	
	private Map<Integer, VirtualMachineState> vmStatesList;

	// --- Used only when Constants.ENABLE_THROTTLED_WEIGHTED_CAP is true ---
	private final java.util.List vmList;
	private double configuredMips = 100000.0;
	private final Map<Integer, Integer> currentLoad =
			java.util.Collections.synchronizedMap(new java.util.HashMap<Integer, Integer>());

	/**
	 * Round-robin pointer used to break ties when multiple VMs are
	 * simultaneously AVAILABLE. Without this, scanning the HashMap-backed
	 * vmStatesList and returning the first AVAILABLE VM found always
	 * favours the same VM (in practice the lowest id, since HashMap
	 * iteration order for small dense integer keys comes out ascending in
	 * practice), causing one VM to absorb a hugely disproportionate share
	 * of dispatches while others sit comparatively idle.
	 */
	private int rrTieBreaker = 0;
	
	/** 
	 * Constructor
	 * 
	 * @param dcb The {@link DatacenterController} using the load balancer.
	 */
	public ThrottledVmLoadBalancer(DatacenterController dcb){
		this.vmStatesList = dcb.getVmStatesList();
		this.vmList       = dcb.getVmList();
		dcb.addCloudSimEventListener(this);
	}

	/**
	 * Sets the real host processor speed, for the weighted-cap formula
	 * only. Mirrors KMeanVmLoadBalancer.setVmMipsAndRam() (same call
	 * site in Simulation.java); RAM is not used here since Throttled
	 * does no clustering.
	 */
	public void setVmMips(double mips) {
		this.configuredMips = mips;
	}

	/** MIPS = host processor speed x vCPUs, same as KMeanVmLoadBalancer.getVmMips(). */
	private final java.util.Map<Integer, Integer> cpusCache = new java.util.HashMap<Integer, Integer>();
	private double getVmMips(int vmId) {
		// Performance only (results identical): the vCPU count of a VM never changes,
		// so look it up once per VM instead of scanning the whole VM list on every
		// call (capForVm() calls this for every VM on every dispatch, which made a
		// 500-VM data center cost ~250,000 list steps per dispatch).
		Integer cpus = cpusCache.get(vmId);
		if (cpus == null && vmList != null) {
			for (int i = 0; i < vmList.size(); i++) {
				cloudsim.VirtualMachine vm = (cloudsim.VirtualMachine) vmList.get(i);
				if (vm.getVmId() == vmId) {
					cpus = vm.getCharacteristics().getCpus();
					cpusCache.put(vmId, cpus);
					break;
				}
			}
		}
		if (cpus != null) {
			// MIPS = host processor speed x number of vCPUs
			return configuredMips * cpus;
		}
		return configuredMips;
	}

	/** Same formula as KMeanVmLoadBalancer.capForVm(). */
	private int capForVm(int vmId) {
		double mips = getVmMips(vmId);
		int cap = (int) Math.floor(mips / Constants.MIN_MIPS_SHARE_PER_JOB);
		return Math.max(1, cap);
	}

	private int loadOf(int vmId) {
		Integer l = currentLoad.get(vmId);
		return (l == null) ? 0 : l;
	}

	/**
	 * @return VM id of an available VM from the vmStatesList in the calling
	 * 			{@link DatacenterController}, chosen by rotating among all
	 * 			currently-available VMs rather than always returning the
	 * 			first one found.
	 */
	@Override
	public int getNextAvailableVm(double cloudletLength){
		int vmId = -1;

		if (!Constants.ENABLE_THROTTLED_WEIGHTED_CAP) {
			// Original behaviour, unchanged.
			if (vmStatesList.size() > 0){
				java.util.List<Integer> available = new java.util.ArrayList<Integer>();
				for (Iterator<Integer> itr = vmStatesList.keySet().iterator(); itr.hasNext();){
					int temp = itr.next();
					VirtualMachineState state = vmStatesList.get(temp);
					if (state.equals(VirtualMachineState.AVAILABLE)){
						available.add(temp);
					}
				}
				if (!available.isEmpty()) {
					vmId = available.get(rrTieBreaker % available.size());
					rrTieBreaker++;
				}
			}
		} else {
			// Attribution test: least-loaded VM under its own MIPS-weighted
			// cap, round-robin tie-break -- same selection rule K-Means
			// uses within a cluster, but applied across ALL VMs (Throttled
			// does no clustering).
			java.util.List<Integer> candidates = new java.util.ArrayList<Integer>();
			int bestLoad = Integer.MAX_VALUE;
			for (Iterator<Integer> itr = vmStatesList.keySet().iterator(); itr.hasNext();){
				int cand = itr.next();
				int load = loadOf(cand);
				if (load >= capForVm(cand)) continue; // over this VM's admission cap
				if (load < bestLoad) {
					bestLoad = load;
					candidates.clear();
					candidates.add(cand);
				} else if (load == bestLoad) {
					candidates.add(cand);
				}
			}
			if (!candidates.isEmpty()) {
				vmId = candidates.get(rrTieBreaker % candidates.size());
				rrTieBreaker++;
			}
		}
		
		allocatedVm(vmId);
		
		return vmId;
		
	}
	
	public void cloudSimEventFired(CloudSimEvent e) {
		if (e.getId() == CloudSimEvents.EVENT_CLOUDLET_ALLOCATED_TO_VM){
			int vmId = (Integer) e.getParameter(Constants.PARAM_VM_ID);
			vmStatesList.put(vmId, VirtualMachineState.BUSY);
			if (Constants.ENABLE_THROTTLED_WEIGHTED_CAP) {
				currentLoad.put(vmId, loadOf(vmId) + 1);
			}
		} else if (e.getId() == CloudSimEvents.EVENT_VM_FINISHED_CLOUDLET){
			int vmId = (Integer) e.getParameter(Constants.PARAM_VM_ID);
			vmStatesList.put(vmId, VirtualMachineState.AVAILABLE);
			if (Constants.ENABLE_THROTTLED_WEIGHTED_CAP) {
				currentLoad.put(vmId, Math.max(0, loadOf(vmId) - 1));
			}
		}
	}
	

}
