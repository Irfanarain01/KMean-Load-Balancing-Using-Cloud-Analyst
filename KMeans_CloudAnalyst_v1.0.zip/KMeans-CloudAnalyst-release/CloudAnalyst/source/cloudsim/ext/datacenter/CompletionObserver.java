package cloudsim.ext.datacenter;

/** A load balancer that learns from completed cloudlets (execution time per VM). */
public interface CompletionObserver {
    /** True if the controller should record dispatch times and report completions. */
    boolean wantsCompletions();
    /** Called by the controller when a cloudlet of the given length finishes on vmId after execTime (ms). */
    void observeCompletion(int vmId, double length, double execTime);
}
