package cloudsim.ext;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import gridsim.util.Poisson;

/**
 * Single place that controls every source of randomness in a run.
 *
 * Before this class existed there were two sources:
 *  (a) the Poisson generators in UserBase, created with GridSim's default
 *      seed sequence (a fixed global sequence that advances each time a
 *      Poisson object is created), and
 *  (b) Math.random() in BestResponseTimeServiceBroker (ORT) and
 *      ServiceProximityServiceBroker (CDC), which is never seeded.
 *
 * Default (MASTER_SEED < 0, no -Dca.seed): behaviour is exactly the legacy
 * behaviour, byte for byte. With a master seed >= 0 (Constants.MASTER_SEED
 * or the JVM option -Dca.seed=N, which takes precedence), every generator
 * is seeded from (master seed, stream name), so a run is reproducible and
 * changing the master seed changes BOTH the workload and the broker choices.
 * Streams are keyed by user-base name / region, not by global call order,
 * so one entity's draws cannot shift another's.
 */
public final class SeedControl {

	private static final Map<String, Random> rngs = new HashMap<String, Random>();

	private SeedControl() {}

	/** Master seed in force, or -1 if running in legacy (unseeded) mode. */
	public static long masterSeed() {
		return Long.getLong("ca.seed", Constants.MASTER_SEED).longValue();
	}

	public static boolean isSeeded() {
		return masterSeed() >= 0;
	}

	/** Call once at the start of every simulation run (clears stream state). */
	public static synchronized void reset() {
		rngs.clear();
		if (isSeeded()) {
			System.out.println("[SeedControl] master seed = " + masterSeed());
		} else {
			System.out.println("[SeedControl] unseeded (legacy behaviour)");
		}
	}

	/** splitmix64 mix of the master seed and a stream name; always in [1, 2^31-2]. */
	public static long derive(String stream) {
		long h = 1125899906842597L;
		for (int i = 0; i < stream.length(); i++) {
			h = 31 * h + stream.charAt(i);
		}
		long z = masterSeed() + h * 0x9E3779B97F4A7C15L;
		z = (z ^ (z >>> 30)) * 0xBF58476D1CE4E5B9L;
		z = (z ^ (z >>> 27)) * 0x94D049BB133111EBL;
		z = z ^ (z >>> 31);
		// GridSim's LCG-based generators need a seed in [1, 2^31-2]; larger
		// values were observed to make Poisson.sample() return 0 forever.
		return 1L + ((z & 0x7fffffffffffffffL) % 2147483646L);
	}

	private static synchronized Random rng(String stream) {
		Random r = rngs.get(stream);
		if (r == null) {
			r = new Random(derive(stream));
			rngs.put(stream, r);
		}
		return r;
	}

	/** Replacement for Math.random() in the brokers. */
	public static double nextDouble(String stream) {
		if (!isSeeded()) {
			return Math.random();
		}
		Random r = rng(stream);
		synchronized (r) {
			return r.nextDouble();
		}
	}

	/** Replacement for new Poisson(name, mean) in UserBase. */
	public static Poisson poisson(String owner, String name, double mean) {
		if (!isSeeded()) {
			return new Poisson(name, mean);
		}
		return new Poisson(name, mean, derive("poisson:" + owner + ":" + name));
	}
}
