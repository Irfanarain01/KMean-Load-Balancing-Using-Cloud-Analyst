package cloudsim.ext.study;

import java.io.*;
import java.util.*;
import cloudsim.ext.*;
import cloudsim.ext.event.*;
import cloudsim.ext.gui.*;
import cloudsim.ext.gui.utils.SimMeasure;
import cloudsim.ext.util.IOUtil;

/**
 * Headless ONE-RUN runner. Loads a saved CloudAnalyst configuration (.sim),
 * overrides the load balancer and broker policy, runs the simulation, and
 * appends one CSV row. The seed and cap flags come from JVM options
 * (-Dca.seed=N, -Dca.throttledCap=true, -Dca.escelCap=true), so the
 * driver script starts a fresh JVM for every run (same as restarting the GUI).
 *
 *   java -Dca.seed=1 -cp ... BatchRunner config.sim "KMean" results.csv [label]
 */
public class BatchRunner {
    public static final String HEADER = "seed,label,broker,throttledCap,escelCap,RT_avg,DCPT_avg,throughput_req_hr,n_ub_msgs,n_dc_msgs,UB1_avg,UB2_avg,UB3_avg,UB4_avg,UB5_avg,UB6_avg,DC1_avg,DC1_max,DC1_n,DC2_avg,DC2_max,DC2_n,DC3_avg,DC3_max,DC3_n,DC4_avg,DC4_max,DC4_n,DC5_avg,DC5_max,DC5_n,kmeans_k,kmeans_restarts,kmeans_sizeAware,group,tshare,theta,userScale,lenScale" + MechStats.header()
        + ",topology,vmScale,km2alpha,DC1_vms,DC2_vms,DC3_vms,DC4_vms,DC5_vms,sim_ms,wall_s,heap_peak_mb,dispatch_us,dispatch_calls,cluster_ms,cluster_calls,update_us,update_calls,state_entries,learn_completions,learn_time_s";

    @SuppressWarnings("unchecked")
    public static void main(String[] args) throws Exception {
        String simFile = args[0], lb = args[1], csv = args[2];
        String label = args.length > 3 ? args[3] : lb;

        List<Object> e = (List<Object>) IOUtil.loadFromXml(simFile);
        List<UserBaseUIElement> ubs = (List<UserBaseUIElement>) e.get(0);
        List<DataCenterUIElement> dcs = (List<DataCenterUIElement>) e.get(1);
        double dur = Double.parseDouble(((String) e.get(3)).trim());
        String unit = (String) e.get(4);
        // optional shorter simulated period for the scalability runs (-Dca.durationMin=N)
        if (System.getProperty("ca.durationMin") != null) { dur = Double.parseDouble(System.getProperty("ca.durationMin")); unit = "min"; }
        int ugf = Integer.parseInt(((String) e.get(5)).trim());
        int dgf = Integer.parseInt(((String) e.get(6)).trim());
        int instr = Integer.parseInt(((String) e.get(7)).trim());
        String sbp = (String) e.get(8);
        if (System.getProperty("ca.broker") != null) sbp = System.getProperty("ca.broker");
        // optional workload scaling for extra scenarios (defaults leave the saved configuration unchanged)
        double userScale = Double.parseDouble(System.getProperty("ca.userScale", "1"));
        double lenScale = Double.parseDouble(System.getProperty("ca.lenScale", "1"));
        // optional per-user-base instruction lengths, e.g. -Dca.ubLengths=300,5000,300,1500,5000,1500 (UB1..UB6)
        String ubl = System.getProperty("ca.ubLengths");
        if (ubl != null) {
            String[] parts = ubl.split(",");
            for (UserBaseUIElement u : ubs) {
                int idx = Integer.parseInt(u.getName().replaceAll("[^0-9]", "")) - 1;
                if (idx >= 0 && idx < parts.length) u.setInstructionLength(Integer.parseInt(parts[idx].trim()));
            }
        }
        StringBuilder lens = new StringBuilder();
        for (UserBaseUIElement u : ubs) lens.append(u.getName()).append('=').append(u.getInstructionLength()).append(' ');
        System.out.println("[BatchRunner] instruction length per user base: " + lens.toString().trim());
        for (UserBaseUIElement u : ubs) {
            if (userScale != 1) { u.setPeakUserCount((int) Math.round(u.getPeakUserCount() * userScale)); u.setOffPeakUserCount((int) Math.round(u.getOffPeakUserCount() * userScale)); }
            if (lenScale != 1) u.setInstructionLength((int) Math.round(u.getInstructionLength() * lenScale));
        }

        // ---- optional topology replacement (-Dca.topology=B|C) and VM-population scaling (-Dca.vmScale=k) ----
        String topo = System.getProperty("ca.topology", "A");
        if (topo.equals("B") || topo.equals("C")) dcs = Topologies.build(topo, dcs);
        int vmScale = Integer.parseInt(System.getProperty("ca.vmScale", "1"));
        if (vmScale > 1) Topologies.scale(dcs, vmScale);
        Map<String, Integer> vmsPerDc = new TreeMap<String, Integer>();
        for (DataCenterUIElement d : dcs) vmsPerDc.put(d.getName(), d.getVmAllocation() == null ? 0 : d.getVmAllocation().getVmCount());
        System.out.println("[BatchRunner] topology " + topo + ", vmScale " + vmScale + ", VMs per DC " + vmsPerDc);

        Simulation sim = new Simulation(new CloudSimEventListener() {
            public void cloudSimEventFired(CloudSimEvent ev) {}
        });
        sim.getUserBases().replaceContent(ubs);
        sim.getDataCenters().replaceContent(dcs);
        double ms = unit.equals("min") ? dur * Constants.MILLI_SECONDS_TO_MINS
                  : unit.equals("hours") ? dur * Constants.MILLI_SECONDS_TO_HOURS
                  : unit.equals("days") ? dur * Constants.MILLI_SECONDS_TO_DAYS : dur * 1000;
        sim.setSimulationTime(ms);
        sim.setServiceBrokerPolicy(sbp);
        sim.setUserGroupingFactor(ugf);
        sim.setDcRequestGroupingFactor(dgf);
        sim.setInstructionLengthPerRequest(instr);
        sim.setLoadBalancePolicy(lb);
        long wall0 = System.nanoTime();
        sim.runSimulation();
        double wallS = (System.nanoTime() - wall0) / 1e9;
        long heapPeak = 0;
        for (java.lang.management.MemoryPoolMXBean mp : java.lang.management.ManagementFactory.getMemoryPoolMXBeans())
            if (mp.getType() == java.lang.management.MemoryType.HEAP && mp.getPeakUsage() != null) heapPeak += mp.getPeakUsage().getUsed();

        Map<String, Object> res = sim.getResults();
        @SuppressWarnings("unchecked") Map<String, SimMeasure> ub = (Map<String, SimMeasure>) res.get(Constants.UB_STATS);
        @SuppressWarnings("unchecked") Map<String, SimMeasure> dc = (Map<String, SimMeasure>) res.get(Constants.DC_PROCESSING_TIME_STATS);

        double rt = 0; long rtN = 0; double dt = 0; long dtN = 0;
        Map<String, Double> ubAvg = new TreeMap<String, Double>(), dcAvg = new TreeMap<String, Double>(), dcMax = new TreeMap<String, Double>();
        Map<String, Long> dcCnt = new TreeMap<String, Long>();
        for (SimMeasure m : ub.values()) {
            if (m.getName().equals(Constants.UB_RESPONSE_TIME) && m.getType().equals(Constants.MEASURE_TYPE_USER_BASE_RESPONSE)) {
                rt += m.getAvg() * m.getCount(); rtN += m.getCount(); ubAvg.put(m.getEntityName(), m.getAvg());
            }
        }
        for (SimMeasure m : dc.values()) {
            if (m.getName().equals(Constants.DC_SERVICE_TIME) && m.getType().equals(Constants.MEASURE_TYPE_DC_PROCESSING_TIME)) {
                dt += m.getAvg() * m.getCount(); dtN += m.getCount();
                dcAvg.put(m.getEntityName(), m.getAvg()); dcMax.put(m.getEntityName(), m.getMax()); dcCnt.put(m.getEntityName(), (long) m.getCount());
            }
        }
        double hours = ms / Constants.MILLI_SECONDS_TO_HOURS;
        StringBuilder row = new StringBuilder();
        row.append(SeedControl.masterSeed()).append(',').append(label).append(',').append(sbp.replace(',', ' '))
           .append(",throttledCap=").append(Constants.ENABLE_THROTTLED_WEIGHTED_CAP)
           .append(",escelCap=").append(Constants.ENABLE_ESCEL_WEIGHTED_CAP);
        row.append(String.format(",%.4f,%.4f,%.4f", rt / rtN, dt / dtN, (dtN / hours)));
        row.append(',').append(rtN).append(',').append(dtN);
        for (String k : new String[]{"UB1","UB2","UB3","UB4","UB5","UB6"}) row.append(String.format(",%.4f", ubAvg.containsKey(k) ? ubAvg.get(k) : Double.NaN));
        for (String k : new String[]{"DC1","DC2","DC3","DC4","DC5"}) {
            if (dcAvg.containsKey(k)) row.append(String.format(",%.4f,%.4f,%d", dcAvg.get(k), dcMax.get(k), dcCnt.get(k)));
            else row.append(",0,0,0");
        }
        row.append(",").append(Constants.KMEANS_NUM_CLUSTERS).append(",").append(Constants.KMEANS_NUM_RESTARTS).append(",").append(Constants.ENABLE_KMEANS_SIZE_AWARE_ROUTING);
        row.append(",").append(System.getProperty("ca.group", "")).append(",").append(Constants.MIN_MIPS_SHARE_PER_JOB).append(",").append(Constants.KMEANS_HEAVY_JOB_THRESHOLD).append(",").append(userScale).append(",").append(lenScale);
        row.append(MechStats.row());
        row.append(",").append(topo).append(",").append(vmScale).append(",").append(System.getProperty("ca.km2alpha", "0.3"));
        for (String k : new String[]{"DC1","DC2","DC3","DC4","DC5"}) row.append(",").append(vmsPerDc.containsKey(k) ? vmsPerDc.get(k) : 0);
        double learnN = 0, learnT = 0;
        for (double[] v : Overhead.learned.values()) { learnN += v[0]; learnT = Math.max(learnT, v[1]); }
        row.append(String.format(",%.0f,%.2f,%.1f,%.3f,%d,%.2f,%d,%.3f,%d,%d,%.0f,%.1f", ms, wallS, heapPeak / 1048576.0,
                Overhead.dispatchCalls > 0 ? Overhead.dispatchNanos / 1e3 / Overhead.dispatchCalls : 0.0, Overhead.dispatchCalls,
                Overhead.clusterNanos / 1e6, Overhead.clusterCalls,
                Overhead.updateCalls > 0 ? Overhead.updateNanos / 1e3 / Overhead.updateCalls : 0.0, Overhead.updateCalls,
                Overhead.stateEntries, learnN, learnT / 1000.0));
        final String header = HEADER;
        if (!csv.equals("-")) {   // "-" = just print the row (StudyDriver collects it)
            File f = new File(csv);
            boolean fresh = !f.exists();
            PrintWriter w = new PrintWriter(new FileWriter(f, true));
            if (fresh) w.println(header);
            w.println(row);
            w.close();
        }
        System.out.println("BATCHROW " + row);
        System.exit(0);
    }
}
