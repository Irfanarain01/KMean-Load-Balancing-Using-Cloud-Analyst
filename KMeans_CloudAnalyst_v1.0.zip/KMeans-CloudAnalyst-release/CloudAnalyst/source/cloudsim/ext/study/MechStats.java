package cloudsim.ext.study;

import java.util.HashMap;
import java.util.IdentityHashMap;
import java.util.Map;

/**
 * Optional per-cloudlet instrumentation for the mechanism study (-Dca.mech=true).
 * Off by default; when off every method returns immediately.
 * For each data center it records, per VM vCPU class (1 or 2) and per job class
 * (light: cloudlet length below the heavy-job threshold; heavy: at or above it):
 * the number of cloudlets, their mean wait in the controller queue and their mean
 * execution time on the VM, plus how many admissions landed in slot 1, 2 or 3+
 * (the number of cloudlets running on the VM right after admission).
 */
public final class MechStats {
    public static final boolean ON = Boolean.getBoolean("ca.mech");
    private static final int[] RAMS = {8192, 10240, 16384};
    private static final String[] DCS = {"DC1", "DC2", "DC3", "DC4", "DC5"};
    private static final Map<String, Double> busyStart = new HashMap<String, Double>();   // per VM
    private static final Map<String, Double> busyTime = new HashMap<String, Double>();    // per DC, VM-ms with >= 1 cloudlet
    private static final double[] phase = new double[4];                                  // n and sumExec: learning, converged
    private static final Map<Object, double[]> live = new IdentityHashMap<Object, double[]>(); // arrive, dispatch, vcpu, heavy, ram, length
    private static final Map<String, double[]> byRam = new HashMap<String, double[]>();        // n, sumExec, sumRate
    private static final Map<String, double[]> agg = new HashMap<String, double[]>();          // n, sumWait, sumExec
    private static final Map<String, long[]> slots = new HashMap<String, long[]>();            // slot1, slot2, slot3plus
    private static final Map<String, Integer> running = new HashMap<String, Integer>();
    private static long lightAll = 0, totalAll = 0;
    private MechStats() {}

    public static synchronized void arrived(Object cl, double t) {
        if (!ON) return;
        live.put(cl, new double[]{t, -1, 0, 0, 0, 0});
    }

    private static String dcName(String broker) { return broker.endsWith("-Broker") ? broker.substring(0, broker.length() - 7) : broker; }

    /** routingLen: the length the balancer compared with the threshold; perReqLen: per-request instruction length.
     *  Job class for the wait/exec columns is fixed by the per-request length: heavy if at least 2000 (the 5000-instruction user bases). */
    public static synchronized void dispatched(String dc, Object cl, int vmId, int vcpu, int ram, double routingLen, double perReqLen, double threshold, double t) {
        if (!ON) return;
        dc = dcName(dc);
        double[] r = live.get(cl);
        if (r == null) { r = new double[]{t, -1, 0, 0, 0, 0}; live.put(cl, r); }
        boolean heavy = perReqLen >= 2000;
        r[1] = t; r[2] = vcpu; r[3] = heavy ? 1 : 0; r[4] = ram; r[5] = routingLen;
        totalAll++; if (routingLen < threshold) lightAll++;
        String vk = dc + "#" + vmId;
        int n = (running.containsKey(vk) ? running.get(vk) : 0) + 1;
        running.put(vk, n);
        if (n == 1) busyStart.put(vk, t);
        String sk = dc + "|" + vcpu;
        long[] s = slots.get(sk);
        if (s == null) { s = new long[3]; slots.put(sk, s); }
        s[Math.min(n, 3) - 1]++;
    }

    public static synchronized void completed(String dc, Object cl, int vmId, double t) {
        if (!ON) return;
        dc = dcName(dc);
        String vk = dc + "#" + vmId;
        if (running.containsKey(vk)) {
            int left = Math.max(0, running.get(vk) - 1);
            running.put(vk, left);
            Double st = busyStart.get(vk);
            if (left == 0 && st != null) {
                Double b = busyTime.get(dc);
                busyTime.put(dc, (b == null ? 0 : b) + (t - st));
                busyStart.remove(vk);
            }
        }
        double[] r = live.remove(cl);
        if (r == null || r[1] < 0) return;
        String key = dc + "|" + (int) r[2] + "|" + (r[3] > 0 ? "H" : "L");
        double[] a = agg.get(key);
        if (a == null) { a = new double[3]; agg.put(key, a); }
        a[0] += 1; a[1] += r[1] - r[0]; a[2] += t - r[1];
        String rk = dc + "|" + (int) r[2] + "|" + (int) r[4];
        double[] b = byRam.get(rk);
        if (b == null) { b = new double[3]; byRam.put(rk, b); }
        double ex = t - r[1];
        Double lt = Overhead.learnedTime(dc);
        int ph = (lt != null && r[1] >= lt) ? 1 : 0;
        if (Overhead.learned.isEmpty()) ph = -1;            // no learning balancer in this run
        if (ph >= 0) { phase[2 * ph] += 1; phase[2 * ph + 1] += ex; }
        b[0] += 1; b[1] += ex; if (ex > 0) b[2] += r[5] / ex;
    }

    /** Column names appended to every CSV row (values are empty-safe zeros when off). */
    public static String header() {
        StringBuilder h = new StringBuilder();
        for (String dc : DCS)
            for (int v = 1; v <= 2; v++)
                for (String c : new String[]{"L", "H"})
                    h.append(",").append(dc).append("_v").append(v).append(c).append("_n")
                     .append(",").append(dc).append("_v").append(v).append(c).append("_wait")
                     .append(",").append(dc).append("_v").append(v).append(c).append("_exec");
        for (int v = 1; v <= 2; v++)
            for (int s = 1; s <= 3; s++) h.append(",DC2_v").append(v).append("_slot").append(s == 3 ? "3plus" : String.valueOf(s));
        h.append(",below_threshold_cloudlets,all_cloudlets");
        for (String dc : DCS) h.append(",").append(dc).append("_busyVmMs");
        h.append(",learn_n,learn_exec,conv_n,conv_exec");
        for (int v = 1; v <= 2; v++)
            for (int ram : RAMS)
                h.append(",DC2_v").append(v).append("_ram").append(ram).append("_n")
                 .append(",DC2_v").append(v).append("_ram").append(ram).append("_exec")
                 .append(",DC2_v").append(v).append("_ram").append(ram).append("_rate");
        return h.toString();
    }

    public static synchronized String row() {
        StringBuilder b = new StringBuilder();
        for (String dc : DCS)
            for (int v = 1; v <= 2; v++)
                for (String c : new String[]{"L", "H"}) {
                    double[] a = agg.get(dc + "|" + v + "|" + c);
                    if (a == null || a[0] == 0) b.append(",0,0,0");
                    else b.append(String.format(",%d,%.4f,%.4f", (long) a[0], a[1] / a[0], a[2] / a[0]));
                }
        for (int v = 1; v <= 2; v++) {
            long[] s = slots.get("DC2|" + v);
            for (int i = 0; i < 3; i++) b.append(",").append(s == null ? 0 : s[i]);
        }
        b.append(",").append(lightAll).append(",").append(totalAll);
        for (String dc : DCS) { Double v = busyTime.get(dc); b.append(String.format(",%.1f", v == null ? 0.0 : v)); }
        b.append(String.format(",%d,%.4f,%d,%.4f", (long) phase[0], phase[0] > 0 ? phase[1] / phase[0] : 0.0,
                (long) phase[2], phase[2] > 0 ? phase[3] / phase[2] : 0.0));
        for (int v = 1; v <= 2; v++)
            for (int ram : RAMS) {
                double[] a = byRam.get("DC2|" + v + "|" + ram);
                if (a == null || a[0] == 0) b.append(",0,0,0");
                else b.append(String.format(",%d,%.4f,%.1f", (long) a[0], a[1] / a[0], a[2] / a[0]));
            }
        return b.toString();
    }
}
