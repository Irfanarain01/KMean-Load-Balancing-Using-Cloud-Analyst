package cloudsim.ext.study;

import java.util.HashMap;
import java.util.Map;

/**
 * Overhead counters for one simulation run (each run is its own JVM).
 * Times are thread CPU times on the machine that runs the study,
 * so they describe the algorithm's computational cost, not simulated time.
 */
public final class Overhead {
    private Overhead() {}
    private static final java.lang.management.ThreadMXBean TMX = java.lang.management.ManagementFactory.getThreadMXBean();
    private static final boolean CPU_OK = TMX.isCurrentThreadCpuTimeSupported();
    /** CPU time of the calling thread (ns); falls back to wall-clock time if CPU time is unavailable. */
    public static long cpu() { return CPU_OK ? TMX.getCurrentThreadCpuTime() : System.nanoTime(); }
    public static long dispatchNanos = 0, dispatchCalls = 0;   // whole getNextAvailableVm call
    public static long clusterNanos = 0, clusterCalls = 0;     // clustering routine (nominal or speed tiers)
    public static long updateNanos = 0, updateCalls = 0;       // KM2 / ETLBA completion feedback
    public static long stateEntries = 0;                       // values kept per run by feedback balancers
    /** KM2 learning phase per data center: completions and simulated time until every VM was measured. */
    public static final Map<String, double[]> learned = new HashMap<String, double[]>();

    public static synchronized void addCluster(long ns) { clusterNanos += ns; clusterCalls++; }
    public static synchronized void addDispatch(long ns) { dispatchNanos += ns; dispatchCalls++; }
    public static synchronized void addUpdate(long ns) { updateNanos += ns; updateCalls++; }
    public static synchronized void addState() { stateEntries++; }

    public static synchronized void learnedAt(String dc, long completions, double simTime) {
        if (!learned.containsKey(dc)) learned.put(dc, new double[]{completions, simTime});
    }
    public static synchronized Double learnedTime(String dc) {
        double[] v = learned.get(dc);
        return v == null ? null : v[1];
    }
}
