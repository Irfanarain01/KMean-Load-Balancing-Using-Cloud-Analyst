package cloudsim.ext.study;

import java.util.ArrayList;
import java.util.List;

import cloudsim.ext.gui.DataCenterUIElement;
import cloudsim.ext.gui.MachineUIElement;
import cloudsim.ext.gui.VmAllocationUIElement;

/**
 * Alternative data-center layouts for the study (selected with -Dca.topology), and VM-population scaling.
 * User bases, costs, OS/VMM and the VM allocation policy are taken from the saved configuration; only the
 * data centers change. Every host has 32 processors. Host memory is sized so that every VM is created
 * (checked in each run's log) while hosts stay slightly oversubscribed, as in the base layout.
 *
 * B: five data centers in five different regions (0 to 4), 200 VMs each, so user bases see different
 *    regional distances to the data centers.
 * C: one central data center in region 0 (lowest mean latency to the other regions) with only 60 VMs,
 *    serving its own region and the region without a data center, and four 235-VM data centers in
 *    regions 1, 3, 4 and 5. The central data center is heavily loaded, and because it holds fewer than
 *    100 VMs, the DR broker can add VMs to it.
 */
public final class Topologies {
    private Topologies() {}

    // name, region, vms, hosts, hostMemoryMB, hostBw, hostSpeedMIPS, vmBw
    private static final int[][] B = {
            {0, 200, 9, 288000, 250000, 100000, 8000},
            {1, 200, 9, 288000, 250000, 120000, 8000},
            {2, 200, 9, 288000, 250000,  90000, 8000},
            {3, 200, 9, 288000, 250000, 110000, 8000},
            {4, 200, 9, 288000, 250000,  80000, 8000}};
    private static final int[][] C = {
            {0,  60,  4, 512000, 300000, 100000, 10000},
            {1, 235, 11, 288000, 250000, 120000,  8000},
            {3, 235, 11, 288000, 250000,  90000,  8000},
            {4, 235, 11, 288000, 250000, 110000,  8000},
            {5, 235, 11, 288000, 250000,  80000,  8000}};

    public static List<DataCenterUIElement> build(String topo, List<DataCenterUIElement> base) {
        DataCenterUIElement ref = base.get(0);
        MachineUIElement refM = ref.getMachineList().get(0);
        VmAllocationUIElement refA = ref.getVmAllocation();
        int[][] spec = topo.equals("B") ? B : C;
        List<DataCenterUIElement> out = new ArrayList<DataCenterUIElement>();
        for (int i = 0; i < spec.length; i++) {
            int[] r = spec[i];
            DataCenterUIElement dc = new DataCenterUIElement("DC" + (i + 1), r[0], ref.getArchitecture(), ref.getOs(),
                    ref.getVmm(), ref.getCostPerProcessor(), ref.getCostPerMem(), ref.getCostPerStorage(), ref.getCostPerBw());
            List<MachineUIElement> ms = new ArrayList<MachineUIElement>();
            for (int h = 0; h < r[2]; h++)
                ms.add(new MachineUIElement(r[3], refM.getStorage(), r[4], 32, r[5], refM.getVmAllocationPolicy()));
            dc.setMachineList(ms);
            long img = refA != null ? refA.getImageSize() : 1000000L;
            int mem = refA != null ? refA.getMemory() : 10240;
            dc.setVmAllocation(new VmAllocationUIElement(dc, r[1], img, mem, r[6]));
            out.add(dc);
        }
        return out;
    }

    /** Multiplies every data center's VM count and host count by k (host specification unchanged). */
    public static void scale(List<DataCenterUIElement> dcs, int k) {
        for (DataCenterUIElement dc : dcs) {
            VmAllocationUIElement a = dc.getVmAllocation();
            if (a != null) a.setVmCount(a.getVmCount() * k);
            List<MachineUIElement> ms = new ArrayList<MachineUIElement>();
            for (int rep = 0; rep < k; rep++)
                for (MachineUIElement m : dc.getMachineList())
                    ms.add(new MachineUIElement(m.getMemory(), m.getStorage(), m.getBw(), m.getProcessors(), m.getSpeed(),
                            m.getVmAllocationPolicy()));
            dc.setMachineList(ms);
        }
    }
}
