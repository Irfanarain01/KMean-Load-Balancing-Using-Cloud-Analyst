package cloudsim.ext.study;

import java.io.*;
import java.util.*;
import java.util.concurrent.*;

/**
 * Runs groups of simulations, each in a fresh JVM (the same as restarting CloudAnalyst),
 * and collects one CSV row per run. Resumable: rows already in the CSV are skipped.
 *
 * Program arguments:  <config.sim> <results.csv> <seeds> [workers] [groups or labels]
 *   seeds   : "1-10", "1,2,3,5", or "auto" (each job uses its own seeds; see JOBS)
 *   workers : how many runs at the same time (default 2)
 *   groups  : MAIN (default), ABLATION, ROUND2 (all seven round-2 groups), TUNE, LOAD,
 *             PROC, REPLAY, MECH, HETERO, DRFINAL, HEAVY, HTUNE,
 *             ROUND3 (MCAP, ALPHA, TOPOB, TOPOC, SCALE_CDC), SCALE_ORT, SCALE_DR, NKCAP, ACHUNK, NKBC, CONF, ALL, or a comma list of labels
 * Per-run console output is saved in study_logs/.
 */
public class StudyDriver {

    static final class Job {
        final String group, label, lb; final String[] props; final int[] seeds;
        Job(String group, String label, String lb, int[] seeds, String... props) {
            this.group = group; this.label = label; this.lb = lb; this.seeds = seeds; this.props = props;
        }
    }

    static final String KM = "KMean", TH = "Throttled", ES = "Equally Spread Current Execution Load", RRP = "Round Robin";
    static final String DR = "Reconfigure Dynamically with Load";
    static int[] range(int a, int b) { int[] r = new int[b - a + 1]; for (int i = 0; i < r.length; i++) r[i] = a + i; return r; }
    static final int[] S1_10 = range(1, 10), S11_20 = range(11, 20), S21_30 = range(21, 30), S1_3 = range(1, 3);

    static final List<Job> JOBS = new ArrayList<Job>();
    static {
        // MAIN: the six configurations of the first study (unchanged)
        JOBS.add(new Job("MAIN", "KMEANS_HYBRID", KM, S1_10));
        JOBS.add(new Job("MAIN", "THROTTLED_CAP", TH, S1_10, "ca.throttledCap=true"));
        JOBS.add(new Job("MAIN", "ESCEL_CAP", ES, S1_10, "ca.escelCap=true"));
        JOBS.add(new Job("MAIN", "RR", RRP, S1_10));
        JOBS.add(new Job("MAIN", "ESCEL_UNCAPPED", ES, S1_10));
        JOBS.add(new Job("MAIN", "THROTTLED_FLAT", TH, S1_10));
        // ABLATION: K-Means variants (cap on)
        JOBS.add(new Job("ABLATION", "KMEANS_NOSIZE", KM, S1_10, "ca.sizeAware=false"));
        JOBS.add(new Job("ABLATION", "KMEANS_K1", KM, S1_10, "ca.k=1"));
        JOBS.add(new Job("ABLATION", "KMEANS_K2_R10", KM, S1_10, "ca.k=2", "ca.restarts=10"));
        JOBS.add(new Job("ABLATION", "KMEANS_K2_R10_NOSIZE", KM, S1_10, "ca.k=2", "ca.restarts=10", "ca.sizeAware=false"));
        JOBS.add(new Job("ABLATION", "KMEANS_K3_R10", KM, S1_10, "ca.k=3", "ca.restarts=10"));
        JOBS.add(new Job("ABLATION", "KMEANS_K4_R10", KM, S1_10, "ca.k=4", "ca.restarts=10"));
        // ROUND 2 ---------------------------------------------------------------
        // TUNE: choose T_share on seeds 11-20, which the final comparison (seeds 1-10) never uses
        for (int ts : new int[]{50000, 60000, 70000, 90000, 100000, 120000})
            JOBS.add(new Job("TUNE", "TUNE_HYB_TS" + (ts / 1000) + "K", KM, S11_20, "ca.tshare=" + ts));
        JOBS.add(new Job("TUNE", "TUNE_RR", RRP, S11_20));
        // LOAD: 1.5x users (higher load), same topology
        JOBS.add(new Job("LOAD", "LOAD_HYB", KM, S1_10, "ca.userScale=1.5"));
        JOBS.add(new Job("LOAD", "LOAD_ESCEL_CAP", ES, S1_10, "ca.userScale=1.5", "ca.escelCap=true"));
        JOBS.add(new Job("LOAD", "LOAD_RR", RRP, S1_10, "ca.userScale=1.5"));
        JOBS.add(new Job("LOAD", "LOAD_K4R10", KM, S1_10, "ca.userScale=1.5", "ca.k=4", "ca.restarts=10"));
        // PROC: 4x instruction lengths (processing is a larger share of RT)
        JOBS.add(new Job("PROC", "PROC_HYB", KM, S1_10, "ca.lenScale=4"));
        JOBS.add(new Job("PROC", "PROC_ESCEL_CAP", ES, S1_10, "ca.lenScale=4", "ca.escelCap=true"));
        JOBS.add(new Job("PROC", "PROC_RR", RRP, S1_10, "ca.lenScale=4"));
        JOBS.add(new Job("PROC", "PROC_K4R10", KM, S1_10, "ca.lenScale=4", "ca.k=4", "ca.restarts=10"));
        // REPLAY: ten repeats of seeds 1-3, to measure replay noise
        for (int r = 1; r <= 10; r++) {
            String rr = String.format("%02d", r);
            JOBS.add(new Job("REPLAY", "REPLAY_RR_" + rr, RRP, S1_3));
            JOBS.add(new Job("REPLAY", "REPLAY_HYB_" + rr, KM, S1_3));
        }
        // MECH: per-cloudlet instrumentation (wait/exec by VM class and job class, admission slots)
        JOBS.add(new Job("MECH", "MECH_HYB", KM, S1_10, "ca.mech=true"));
        JOBS.add(new Job("MECH", "MECH_NOSIZE", KM, S1_10, "ca.mech=true", "ca.sizeAware=false"));
        JOBS.add(new Job("MECH", "MECH_ESCEL_CAP", ES, S1_10, "ca.mech=true", "ca.escelCap=true"));
        JOBS.add(new Job("MECH", "MECH_K2R10", KM, S1_10, "ca.mech=true", "ca.k=2", "ca.restarts=10"));
        JOBS.add(new Job("MECH", "MECH_K4R10", KM, S1_10, "ca.mech=true", "ca.k=4", "ca.restarts=10"));
        // HETERO: the workload the paper's design describes -- per-user-base instruction lengths
        // (UB1..UB6 = 300, 5000, 300, 1500, 5000, 1500). The saved configuration CA_H1.sim keeps every
        // user base at the default 1000, so all earlier runs used a uniform length. PERREQ variants route
        // on the per-request length, so only UB2 and UB5 count as heavy (as the design intended).
        String UBL = "ca.ubLengths=300,5000,300,1500,5000,1500";
        JOBS.add(new Job("HETERO", "HET_HYB", KM, S1_10, UBL, "ca.mech=true"));
        JOBS.add(new Job("HETERO", "HET_HYB_PERREQ", KM, S1_10, UBL, "ca.mech=true", "ca.perRequestLength=true"));
        JOBS.add(new Job("HETERO", "HET_K2R10_PERREQ", KM, S1_10, UBL, "ca.mech=true", "ca.perRequestLength=true", "ca.k=2", "ca.restarts=10"));
        JOBS.add(new Job("HETERO", "HET_K4R10_PERREQ", KM, S1_10, UBL, "ca.mech=true", "ca.perRequestLength=true", "ca.k=4", "ca.restarts=10"));
        JOBS.add(new Job("HETERO", "HET_ESCEL_CAP", ES, S1_10, UBL, "ca.mech=true", "ca.escelCap=true"));
        JOBS.add(new Job("HETERO", "HET_THROTTLED_CAP", TH, S1_10, UBL, "ca.mech=true", "ca.throttledCap=true"));
        JOBS.add(new Job("HETERO", "HET_RR", RRP, S1_10, UBL, "ca.mech=true"));
        JOBS.add(new Job("HETERO", "HET_ESCEL_UNCAPPED", ES, S1_10, UBL, "ca.mech=true"));
        JOBS.add(new Job("HETERO", "HET_THROTTLED_FLAT", TH, S1_10, UBL, "ca.mech=true"));
        // HEAVY: heavy heterogeneous load -- per-request lengths 4x the HETERO values
        // (UB1..UB6 = 1200, 20000, 1200, 6000, 20000, 6000), at 1.0x and 1.5x users, under CDC, ORT and DR.
        // KM2 = speed-aware hybrid: K-Means on MEASURED per-vCPU speed, cap = one cloudlet per vCPU.
        String HUBL = "ca.ubLengths=1200,20000,1200,6000,20000,6000";
        String CDC = "Closest Data Center", ORTP = "Optimise Response Time", DRP = "Reconfigure Dynamically with Load";
        for (String[] sc : new String[][]{{"H1", "1.0"}, {"H15", "1.5"}}) {
            for (String[] br : new String[][]{{"CDC", CDC}, {"ORT", ORTP}, {"DR", DRP}}) {
                String p = "HV_" + sc[0] + "_" + br[0] + "_";
                String U = "ca.userScale=" + sc[1], B = "ca.broker=" + br[1];
                JOBS.add(new Job("HEAVY", p + "RR", RRP, S1_10, HUBL, U, B));
                JOBS.add(new Job("HEAVY", p + "ESCEL", ES, S1_10, HUBL, U, B));
                JOBS.add(new Job("HEAVY", p + "THROTTLED", TH, S1_10, HUBL, U, B));
                JOBS.add(new Job("HEAVY", p + "HYB", KM, S1_10, HUBL, U, B));
                JOBS.add(new Job("HEAVY", p + "KM2", KM, S1_10, HUBL, U, B, "ca.km2=true", "ca.tshare=90000"));
                JOBS.add(new Job("HEAVY", p + "ESCEL_CAP", ES, S1_10, HUBL, U, B, "ca.escelCap=true"));
            }
        }
        // HTUNE: choose the speed-aware settings on seeds 11-20 (never reported as results)
        for (String[] br : new String[][]{{"CDC", CDC}, {"ORT", ORTP}, {"DR", DRP}}) {
            String p = "HT_H15_" + br[0] + "_", U = "ca.userScale=1.5", B = "ca.broker=" + br[1];
            JOBS.add(new Job("HTUNE", p + "HYB", KM, S11_20, HUBL, U, B));
            JOBS.add(new Job("HTUNE", p + "KM2_K2", KM, S11_20, HUBL, U, B, "ca.km2=true", "ca.tshare=90000"));
            JOBS.add(new Job("HTUNE", p + "KM2_K3", KM, S11_20, HUBL, U, B, "ca.km2=true", "ca.km2k=3", "ca.tshare=90000"));
            JOBS.add(new Job("HTUNE", p + "KM2_SOFT1", KM, S11_20, HUBL, U, B, "ca.km2=true", "ca.km2soft=1", "ca.tshare=90000"));
            JOBS.add(new Job("HTUNE", p + "RR", RRP, S11_20, HUBL, U, B));
        }
        // ROUND 3 ---------------------------------------------------------------
        // Common: heavy heterogeneous lengths, instrumentation on, K-Means diagnostic logging off.
        String L3 = "ca.ubLengths=1200,20000,1200,6000,20000,6000", M3 = "ca.mech=true", Q3 = "ca.kmLog=false";
        String[][] SBP3 = {{"CDC", "Closest Data Center"}, {"ORT", "Optimise Response Time"}, {"DR", "Reconfigure Dynamically with Load"}};
        // configuration name, load balancer, extra options
        String[][] CFG8 = {
                {"RR", RRP, ""}, {"ESCEL", ES, ""}, {"THROTTLED", TH, ""}, {"HYB", KM, ""},
                {"KM2", KM, "ca.km2=true;ca.tshare=90000"}, {"ESCEL_CAP90", ES, "ca.escelCap=true;ca.tshare=90000"},
                {"ETLBA", "ETLBA", ""}, {"RETELBA", "ReT-ELBa", "ca.perRequestLength=true"}};
        // MCAP: base topology, both loads -- matched-cap control and the two reimplemented algorithms (RR anchors the pairing with study_heavy.csv)
        for (String[] ld : new String[][]{{"H1", "1.0"}, {"H15", "1.5"}})
            for (String[] br : SBP3)
                for (String[] c : CFG8)
                    if (c[0].equals("RR") || c[0].equals("ESCEL_CAP90") || c[0].equals("ETLBA") || c[0].equals("RETELBA"))
                        JOBS.add(job3("MCAP", "R3_MCAP_" + ld[0] + "_" + br[0] + "_" + c[0], c, S1_10, L3, M3, Q3, "ca.userScale=" + ld[1], "ca.broker=" + br[1]));
        // NKCAP: the nominal K-Means baseline (HYB) with the SAME admission floor as SAKMLB/KM2 (T_share 90,000),
        // so that nominal versus measured-speed clustering differs in one factor only. Both loads, all three SBPs.
        // Not part of ROUND3: run it separately with the group name NKCAP.
        for (String[] ld : new String[][]{{"H1", "1.0"}, {"H15", "1.5"}})
            for (String[] br : SBP3)
                JOBS.add(job3("NKCAP", "R3_NKCAP_" + ld[0] + "_" + br[0] + "_NKMLB90", new String[]{"NKMLB90", KM, "ca.tshare=90000"},
                        S1_10, L3, M3, Q3, "ca.userScale=" + ld[1], "ca.broker=" + br[1]));
        // ACHUNK: topology A, instrumented re-runs of the three algorithms whose heavy-load runs (study_heavy.csv) had no
        // per-sub-cloudlet waiting/execution instrumentation: ESCEL, Throttled and SAKMLB (label KM2). With the instrumented
        // runs already in study_round3.csv and study_nkcap.csv this gives the mean completion time over ALL sub-cloudlets
        // for every algorithm in topology A. CDC and ORT only (DR equals CDC with these pools).
        for (String[] ld : new String[][]{{"H1", "1.0"}, {"H15", "1.5"}})
            for (String[] br : new String[][]{SBP3[0], SBP3[1]})
                for (String[] c : CFG8)
                    if (c[0].equals("ESCEL") || c[0].equals("THROTTLED") || c[0].equals("KM2"))
                        JOBS.add(job3("ACHUNK", "R4_ACHUNK_" + ld[0] + "_" + br[0] + "_" + c[0], c, S1_10, L3, M3, Q3,
                                "ca.userScale=" + ld[1], "ca.broker=" + br[1]));
        // NKBC: nominal K-Means (NKMLB) at the SAME admission floor as SAKMLB (T_share 90,000) in topologies B and C.
        // The earlier TOPOB/TOPOC runs used 70,000 for NKMLB, which gives a different cap on the 2-vCPU VMs of the
        // 120,000, 110,000 and 80,000 MIPS data centers, so SAKMLB versus NKMLB there mixed clustering with the cap.
        // CDC and ORT only (DR equals CDC in B; DR is excluded in C because CA's DR fails when it adds VMs).
        for (String t : new String[]{"B", "C"})
            for (String[] br : new String[][]{SBP3[0], SBP3[1]})
                JOBS.add(job3("NKBC", "R4_NKBC_" + t + "_" + br[0] + "_NKMLB90", new String[]{"NKMLB90", KM, "ca.tshare=90000"},
                        S1_10, L3, M3, Q3, "ca.userScale=1.5", "ca.broker=" + br[1], "ca.topology=" + t));
        // CONF: confirmatory runs on seeds 21 to 30, which no earlier analysis used. The hypotheses and the analysis
        // (HYPOTHESES.md, analysis/analyze_conf.py) were fixed before these runs. SAKMLB (label KM2), NKMLB and capped
        // ESCEL all use T_share 90,000, so each pair differs in one factor only. Topologies A, B and C, 1.5x users,
        // CDC and ORT (DR equals CDC in A and B; CA's DR fails in C).
        String[][] CONF3 = {{"SAKMLB", KM, "ca.km2=true;ca.tshare=90000"}, {"NKMLB90", KM, "ca.tshare=90000"},
                {"ESCEL_CAP90", ES, "ca.escelCap=true;ca.tshare=90000"}};
        for (String t : new String[]{"A", "B", "C"})
            for (String[] br : new String[][]{SBP3[0], SBP3[1]})
                for (String[] c : CONF3)
                    JOBS.add(job3("CONF", "R5_CONF_" + t + "_" + br[0] + "_" + c[0], c, S21_30, L3, M3, Q3,
                            "ca.userScale=1.5", "ca.broker=" + br[1], "ca.topology=" + t));
        // ALPHA: KM2 smoothing factor 0.1 and 0.5 (0.3 is in study_heavy.csv), higher load
        for (String a : new String[]{"0.1", "0.5"})
            for (String[] br : SBP3)
                JOBS.add(job3("ALPHA", "R3_ALPHA_" + a.replace(".", "") + "_" + br[0] + "_KM2", new String[]{"KM2", KM, "ca.km2=true;ca.tshare=90000"},
                        S1_10, L3, M3, Q3, "ca.userScale=1.5", "ca.broker=" + br[1], "ca.km2alpha=" + a));
        // TOPOB / TOPOC: five-data-center layouts, higher load, all eight configurations
        for (String t : new String[]{"B", "C"})
            for (String[] br : SBP3)
                for (String[] c : CFG8)
                    JOBS.add(job3("TOPO" + t, "R3_TOPO" + t + "_" + br[0] + "_" + c[0], c, S1_10, L3, M3, Q3, "ca.userScale=1.5", "ca.broker=" + br[1], "ca.topology=" + t));
        // SCALE: 3,000 / 7,000 / 10,000 VMs (VMs, hosts and users scaled together), first 180 simulated minutes, seeds 1-3.
        // SCALE_CDC is part of ROUND3; SCALE_ORT and SCALE_DR are separate because these runs are long.
        for (String[] br : SBP3)
            for (String[] sz : new String[][]{{"S1", "3"}, {"S2", "7"}, {"S3", "10"}})
                for (String[] c : CFG8)
                    if (!c[0].equals("ESCEL_CAP90"))
                        JOBS.add(job3("SCALE_" + br[0], "R3_SCALE_" + sz[0] + "_" + br[0] + "_" + c[0], c, S1_3, L3, M3, Q3,
                                "ca.vmScale=" + sz[1], "ca.userScale=" + sz[1], "ca.durationMin=180", "ca.broker=" + br[1]));
        // DRFINAL: DR with the final VM pools (all larger than DR's 100-VM ceiling)
        JOBS.add(new Job("DRFINAL", "DR_HYB", KM, S1_10, "ca.broker=" + DR));
        JOBS.add(new Job("DRFINAL", "DR_ESCEL_CAP", ES, S1_10, "ca.broker=" + DR, "ca.escelCap=true"));
        JOBS.add(new Job("DRFINAL", "DR_RR", RRP, S1_10, "ca.broker=" + DR));
    }
    static final Set<String> ROUND2 = new HashSet<String>(Arrays.asList("TUNE", "LOAD", "PROC", "REPLAY", "MECH", "DRFINAL", "HETERO"));
    static final Set<String> ROUND3 = new HashSet<String>(Arrays.asList("MCAP", "ALPHA", "TOPOB", "TOPOC", "SCALE_CDC"));

    /** Builds a job from a configuration triple {name, load balancer, "opt1;opt2"} plus extra options. */
    static Job job3(String group, String label, String[] cfg, int[] seeds, String... extra) {
        List<String> props = new ArrayList<String>(Arrays.asList(extra));
        if (cfg[2].length() > 0) props.addAll(Arrays.asList(cfg[2].split(";")));
        return new Job(group, label, cfg[1], seeds, props.toArray(new String[0]));
    }

    static List<Integer> parseSeeds(String spec) {
        List<Integer> out = new ArrayList<Integer>();
        for (String part : spec.split(",")) {
            part = part.trim();
            if (part.contains("-")) {
                String[] ab = part.split("-");
                for (int s = Integer.parseInt(ab[0].trim()); s <= Integer.parseInt(ab[1].trim()); s++) out.add(s);
            } else if (part.length() > 0) out.add(Integer.parseInt(part));
        }
        return out;
    }

    static synchronized void appendRow(File csv, String row) throws IOException {
        boolean fresh = !csv.exists() || csv.length() == 0;
        PrintWriter w = new PrintWriter(new FileWriter(csv, true));
        if (fresh) w.println(BatchRunner.HEADER);
        w.println(row);
        w.close();
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 3) {
            System.out.println("Usage: StudyDriver <config.sim> <results.csv> <seeds e.g. 1-10 or auto> [workers] [groups]");
            return;
        }
        final String sim = new File(args[0]).getAbsolutePath();
        final File csv = new File(args[1]);
        final boolean auto = args[2].trim().equalsIgnoreCase("auto");
        final List<Integer> seeds = auto ? null : parseSeeds(args[2]);
        int workers = args.length > 3 ? Integer.parseInt(args[3]) : 2;
        Set<String> only = new HashSet<String>();
        if (args.length > 4) for (String l : args[4].split(",")) only.add(l.trim());
        if (only.isEmpty()) only.add("MAIN");
        if (only.contains("ROUND2")) only.addAll(ROUND2);
        if (only.contains("ROUND3")) only.addAll(ROUND3);

        Set<String> done = new HashSet<String>();
        if (csv.exists()) {
            BufferedReader r = new BufferedReader(new FileReader(csv));
            String line; r.readLine();
            while ((line = r.readLine()) != null) {
                String[] c = line.split(",");
                if (c.length > 5) done.add(c[0] + "|" + c[1]);
            }
            r.close();
        }
        final File logDir = new File("study_logs");
        logDir.mkdirs();
        final String javaBin = System.getProperty("java.home") + File.separator + "bin" + File.separator
                + (System.getProperty("os.name").toLowerCase().contains("win") ? "java.exe" : "java");
        final String cp = System.getProperty("java.class.path");

        // seed-major order so that complete seeds finish first
        TreeMap<Integer, List<Job>> bySeed = new TreeMap<Integer, List<Job>>();
        for (Job j : JOBS) {
            if (!(only.contains("ALL") || only.contains(j.group) || only.contains(j.label))) continue;
            List<Integer> ss = new ArrayList<Integer>();
            if (auto) for (int s : j.seeds) ss.add(s); else ss.addAll(seeds);
            for (int s : ss) {
                if (done.contains(s + "|" + j.label)) continue;
                if (!bySeed.containsKey(s)) bySeed.put(s, new ArrayList<Job>());
                bySeed.get(s).add(j);
            }
        }
        List<Callable<Boolean>> tasks = new ArrayList<Callable<Boolean>>();
        final int[] counters = new int[2];
        final long t0 = System.currentTimeMillis();
        for (Map.Entry<Integer, List<Job>> e : bySeed.entrySet()) {
            final int seed = e.getKey();
            for (final Job j : e.getValue()) {
                tasks.add(new Callable<Boolean>() {
                    public Boolean call() throws Exception {
                        File log = new File(logDir, j.label + "_s" + seed + ".log");
                        List<String> cmd = new ArrayList<String>();
                        cmd.add(javaBin);
                        cmd.add("-Djava.awt.headless=true");
                        cmd.add("-Dca.seed=" + seed);
                        cmd.add("-Dca.group=" + j.group);
                        for (String p : j.props) cmd.add("-D" + p);
                        cmd.add("-cp"); cmd.add(cp);
                        cmd.add("cloudsim.ext.study.BatchRunner");
                        cmd.add(sim); cmd.add(j.lb); cmd.add("-"); cmd.add(j.label);
                        ProcessBuilder pb = new ProcessBuilder(cmd);
                        pb.redirectErrorStream(true);
                        pb.redirectOutput(log);
                        int code = pb.start().waitFor();
                        String row = null;
                        BufferedReader r = new BufferedReader(new FileReader(log));
                        String line;
                        while ((line = r.readLine()) != null) if (line.startsWith("BATCHROW ")) row = line.substring(9);
                        r.close();
                        boolean ok = (code == 0 && row != null);
                        if (ok) appendRow(csv, row);
                        synchronized (counters) {
                            counters[ok ? 0 : 1]++;
                            int n = counters[0] + counters[1];
                            long el = (System.currentTimeMillis() - t0) / 1000;
                            System.out.println(String.format("[%d finished, %d failed] %s seed %d %s   elapsed %d min",
                                    n, counters[1], j.label, seed, ok ? "OK" : "FAILED (see " + log.getName() + ")", el / 60));
                        }
                        return ok;
                    }
                });
            }
        }
        System.out.println("Runs to do: " + tasks.size() + " (already in CSV: " + done.size() + "), workers: " + workers);
        ExecutorService ex = Executors.newFixedThreadPool(workers);
        ex.invokeAll(tasks);
        ex.shutdown();

        // Pairing check: within one group and seed, every configuration must send the same number of requests
        Map<String, Set<String>> byKey = new TreeMap<String, Set<String>>();
        if (csv.exists()) {
            BufferedReader r = new BufferedReader(new FileReader(csv));
            String header = r.readLine();
            int gcol = header == null ? -1 : Arrays.asList(header.split(",")).indexOf("group");
            int ucol = header == null ? -1 : Arrays.asList(header.split(",")).indexOf("userScale");
            int lcol = header == null ? -1 : Arrays.asList(header.split(",")).indexOf("lenScale");
            String line;
            while ((line = r.readLine()) != null) {
                String[] c = line.split(",");
                if (c.length > 9) {
                    String key = (gcol >= 0 && gcol < c.length ? c[gcol] : "")
                            + (ucol >= 0 && ucol < c.length && !c[ucol].equals("1.0") ? " users x" + c[ucol] : "")
                            + (lcol >= 0 && lcol < c.length && !c[lcol].equals("1.0") ? " length x" + c[lcol] : "")
                            + " seed " + c[0];
                    if (!byKey.containsKey(key)) byKey.put(key, new TreeSet<String>());
                    byKey.get(key).add(c[8]);
                }
            }
            r.close();
        }
        System.out.println("\nPAIRING CHECK (same workload across configurations within a group, load level and seed):");
        int bad = 0;
        for (Map.Entry<String, Set<String>> e : byKey.entrySet()) {
            boolean ok = e.getValue().size() == 1;
            if (!ok) bad++;
            System.out.println("  " + e.getKey() + ": " + (ok ? "OK" : "MISMATCH " + e.getValue()));
        }
        System.out.println("\nDone. Failed runs: " + counters[1] + (counters[1] > 0 ? "  -> start the driver again to retry them." : "")
                + (bad > 0 ? "  Pairing mismatches: " + bad : ""));
        System.out.println("Results: " + csv.getAbsolutePath());
    }
}
