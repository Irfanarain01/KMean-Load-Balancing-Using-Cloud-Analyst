# K-sensitivity support: configurable K, restarts, seed, WCSS/silhouette logging

Files changed: source/cloudsim/ext/Constants.java,
source/cloudsim/ext/datacenter/KMeanVmLoadBalancer.java
New (not part of the build): tools/ClusterHarness.java (offline check)

## New constants (defaults reproduce all earlier results exactly)
- KMEANS_NUM_CLUSTERS = 2   (K; was hard-coded NUM_CLUSTERS = 2)
- KMEANS_NUM_RESTARTS = 1   (best-of-N random starts by lowest WCSS)
- KMEANS_BASE_SEED = 42L    (restart r uses seed 42 + r; 42 was the old hard-coded seed)
- ENABLE_KMEANS_QUALITY_LOGGING = true  (console only: WCSS + mean silhouette per clustering)

## Verified
Compiled with javac -source 8 against the project jars. An offline harness
(tools/ClusterHarness.java) built the real per-DC VM pools (500/350/150 VMs,
RAM tiers 8/10/16 GB, vCPU tiers 1/2) and ran 8000 dispatches per DC on the OLD
and NEW builds with default settings: cluster sizes, centroids, the first 40
selections and a hash of all 8000 selections were IDENTICAL.

## Findings from the offline sweep (clustering quality only, not simulator runs)
1. The clustering is deterministic (seed 42), not random run to run.
2. With the default single start, K=2 splits DC1 and DC2 by RAM, NOT by speed:
   DC1 cluster 0 n=334 (mips 149,701, ram 9,216) vs cluster 1 n=166 (mips 150,000,
   ram 16,384). Both clusters have almost the same average MIPS, so "prefer the
   highest-MIPS cluster" (size-aware routing) cannot separate fast from slow there.
   DC3 splits 100 VMs (avg 112,500) vs 50 fast VMs (180,000).
3. With 10 restarts K=2 finds the fast/slow split (DC1: 251 VMs at 100k vs 249 at
   200k), WCSS drops about 31% and silhouette rises 0.50 -> 0.62.

DC1 (DC2 and DC3 follow the same pattern):
| K | WCSS | silhouette |
|---|---|---|
| 1 | 215.12 | n/a |
| 2, 1 start (default) | 130.22 | 0.499 |
| 2, 10 restarts | 90.12 | 0.617 |
| 3, 10 restarts | 46.72 | 0.726 |
| 4 | 5.22 | 0.902 |
| 5 | 2.59 | 0.951 |
| 6 | 0.00 | 1.000 |
K=4 recovers the four groups in the VM design (slow/fast x 8-10 GB/16 GB). K=6 is
trivially perfect because each DC has exactly six distinct VM profiles. These
curves reflect the synthetic tier design, so present them as such.

## How to try it
Set KMEANS_NUM_RESTARTS = 10 in Constants.java (everything else unchanged) and
re-run K-Means to get the fast/slow K=2 clustering. Change KMEANS_NUM_CLUSTERS
for other K. Read the quality lines in the console:
  [K-Means LB] DC1-Broker quality: K=2 restarts=10 WCSS=90.1167 silhouette=0.6172
