# Round 2: launch options, mechanism instrumentation, new run groups

- Constants.java: MIN_MIPS_SHARE_PER_JOB (-Dca.tshare) and KMEANS_HEAVY_JOB_THRESHOLD (-Dca.theta) are launch options.
  Defaults 70000 and 2000 are unchanged.
- DatacenterController.java: optional per-request routing length (-Dca.perRequestLength=true; default keeps the
  grouped cloudlet length). Hooks for MechStats (no effect unless -Dca.mech=true).
- study/MechStats.java (new): per data center, VM vCPU class, VM RAM tier and job class -- counts, mean queue wait,
  mean execution time, effective rate (cloudlet length / execution time) and admission slot (cloudlets running on
  the VM after admission).
- study/BatchRunner.java: -Dca.userScale, -Dca.lenScale, -Dca.ubLengths; prints the instruction length used for
  each user base; extra CSV columns (group, tshare, theta, userScale, lenScale, mechanism columns).
- study/StudyDriver.java: groups TUNE, LOAD, PROC, REPLAY, MECH, HETERO, DRFINAL (ROUND2 runs all); seeds "auto";
  pairing check per group and seed.

Checked here: whole project compiles (Java 8 target); defaults reproduce earlier rows (legacy hybrid RT 310.416,
DCPT 32.614, DC3 max 130.21; seed-1 rows within replay noise); every option reaches the run (recorded in the CSV);
a short smoke run of one label per group finished without failures.
