# Heavy heterogeneous load: speed-aware hybrid (KM2)

## What to do
1. Copy these files over your Eclipse project (eclipse-workspace\CloudAnalyst_BatchStudy.zip_expanded\CloudAnalyst), then press F5:
   - source\cloudsim\ext\Constants.java
   - source\cloudsim\ext\datacenter\DatacenterController.java
   - source\cloudsim\ext\datacenter\KMeanVmLoadBalancer.java
   - source\cloudsim\ext\study\BatchRunner.java
   - source\cloudsim\ext\study\StudyDriver.java
   - source\cloudsim\ext\study\MechStats.java
   Check the Problems tab shows no red errors.
2. Run configuration "Study", Program arguments (VM arguments empty):
       CA_H1.sim study_heavy.csv auto 2 HEAVY,HTUNE
   Use 3 or 4 instead of 2 if your PC has 4 or more cores. Resumable: start it again with the same arguments if it stops.
3. When it shows "Failed runs: 0" and the pairing checks are OK, send study_heavy.csv.

510 runs (360 HEAVY + 150 HTUNE). Expect roughly 4 hours with 2 workers, less with 3 or 4.

## Groups
| Group | Runs | Purpose |
|---|---|---|
| HEAVY | 36 labels x seeds 1-10 | Results: lengths 4x heterogeneous (UB1..UB6 = 1200, 20000, 1200, 6000, 20000, 6000) at 1.0x and 1.5x users, under all three broker policies (CDC, ORT, DR); RR, ESCEL, Throttled, default hybrid, KM2 (the K-Means version for the paper), and capped ESCEL as a control |
| HTUNE | 15 labels x seeds 11-20 | Settings check on seeds never reported: KM2 with K=2, K=3, soft cap, against the default hybrid and RR (1.5x users, CDC, ORT and DR) |

Labels: HV_<H1|H15>_<CDC|ORT|DR>_<config> and HT_H15_<CDC|ORT|DR>_<config>.

## KM2 (speed-aware hybrid)
-Dca.km2=true: K-Means clusters VMs on their MEASURED per-vCPU speed (length / execution time of completed
cloudlets), learned online; VMs not yet measured are tried first so every VM gets measured. Dispatch tries the
fastest tier first, least-loaded inside a tier, ties rotated. Used with -Dca.tshare=90000 (cap = one cloudlet per vCPU).
Options: -Dca.km2k=N (tiers, default 2), -Dca.km2soft=N (extra cloudlets above the cap when every VM is at its cap;
default 0 = queue), -Dca.km2sita=true (small requests try the slowest tier first; needs -Dca.perRequestLength=true).
