package cloudsim.ext.datacenter;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Random;

import cloudsim.VirtualMachine;
import cloudsim.VMCharacteristics;
import cloudsim.ext.Constants;
import cloudsim.ext.event.CloudSimEvent;
import cloudsim.ext.event.CloudSimEventListener;
import cloudsim.ext.event.CloudSimEvents;

/**
 * KMeanVmLoadBalancer - K-Means clustering based VM load balancer.
 *
 * Clusters VMs into K=2 groups using two dimensions:
 *   X = MIPS  (processor speed × CPUs, set via setVmMipsAndRam())
 *   Y = RAM   (memory in MB, read from VMCharacteristics)
 *
 * Each cloudlet is dispatched to the AVAILABLE VM with the highest MIPS
 * in the best-matching cluster (nearest centroid by Euclidean distance).
 *
 * Bugs fixed vs original KMean.java:
 *   1. Extends VmLoadBalancer — properly integrated into CA scheduling.
 *   2. Uses real VM MIPS and RAM — no hardcoded dummy data.
 *   3. Centroids randomly initialised from actual VM data points.
 *   4. Correct K-Means: assign ALL points THEN update centroids (no
 *      mid-assignment recalculation).
 *   5. Wrong centroid-update-before-assign order corrected.
 */
public class KMeanVmLoadBalancer extends VmLoadBalancer implements CloudSimEventListener {

    private static final int NUM_CLUSTERS = 2;
    private static final int MAX_ITERATIONS = 10;

    private final Map<Integer, VirtualMachineState> vmStatesList;
    private final List vmList;   // raw List from DatacenterBroker

    // MIPS per VM set from Simulation.java using host machine speed
    private double configuredMips = 100000.0;  // default from Table 8
    private double configuredRam  = 8192.0;    // default 8 GB in MB

    /** Cluster assignment: index -> clusterId (index matches vmIds[]) */
    private int[]    vmIds;
    private int[]    vmCluster;

    /** Centroid values for each cluster */
    private double[] centroidMips;
    private double[] centroidRam;

    public KMeanVmLoadBalancer(DatacenterController dcb) {
        this.vmStatesList = dcb.getVmStatesList();
        this.vmList       = dcb.getVmList();
        dcb.addCloudSimEventListener(this);
    }

    /**
     * Called from Simulation.java after controller is created,
     * passing the real host-level processor speed and memory.
     *
     * @param mips  processor speed × processors per machine (e.g. 100000)
     * @param ram   machine memory in MB (e.g. 262144 for 256 GB)
     */
    public void setVmMipsAndRam(double mips, double ram) {
        this.configuredMips = mips;
        this.configuredRam  = ram;
    }

    /**
     * Returns the VM id of the best available VM chosen by K-Means.
     * Clusters VMs by MIPS and RAM, selects from the high-resource
     * cluster first, falls back to any available VM if needed.
     */
    @Override
    public int getNextAvailableVm() {
        if (vmStatesList == null || vmStatesList.isEmpty()) {
            return -1;
        }

        runKMeans();

        // Choose cluster with higher MIPS centroid
        int bestCluster = 0;
        for (int c = 1; c < centroidMips.length; c++) {
            if (centroidMips[c] > centroidMips[bestCluster]) {
                bestCluster = c;
            }
        }

        // Pick AVAILABLE VM in best cluster with highest MIPS
        int    selectedVmId = -1;
        double bestMips     = -1;

        for (int idx = 0; idx < vmIds.length; idx++) {
            int vmId = vmIds[idx];
            if (vmCluster[idx] == bestCluster) {
                VirtualMachineState state = vmStatesList.get(vmId);
                if (state != null && state.equals(VirtualMachineState.AVAILABLE)) {
                    double mips = getVmMips(vmId);
                    if (mips > bestMips) {
                        bestMips     = mips;
                        selectedVmId = vmId;
                    }
                }
            }
        }

        // Fallback: any available VM from any cluster
        if (selectedVmId == -1) {
            for (int vmId : vmStatesList.keySet()) {
                VirtualMachineState state = vmStatesList.get(vmId);
                if (state != null && state.equals(VirtualMachineState.AVAILABLE)) {
                    selectedVmId = vmId;
                    break;
                }
            }
        }

        allocatedVm(selectedVmId);
        return selectedVmId;
    }

    /**
     * Standard K-Means clustering on (MIPS, RAM) dimensions.
     *
     * Step 1: Build data from real VM MIPS and RAM values.
     * Step 2: Random centroid initialisation from data points.
     * Step 3: Assign ALL points to nearest centroid.
     * Step 4: Update centroids from assignments.
     * Step 5: Repeat 3-4 until convergence or MAX_ITERATIONS.
     */
    private void runKMeans() {
        List<Integer> activeIds = new ArrayList<Integer>(vmStatesList.keySet());
        int n = activeIds.size();
        if (n == 0) return;

        vmIds      = new int[n];
        vmCluster  = new int[n];
        double[] mipsData = new double[n];
        double[] ramData  = new double[n];

        // Build data arrays using REAL VM MIPS and RAM
        for (int i = 0; i < n; i++) {
            int vmId    = activeIds.get(i);
            vmIds[i]    = vmId;
            mipsData[i] = getVmMips(vmId);   // real MIPS from host config
            ramData[i]  = getVmRam(vmId);    // real RAM from VMCharacteristics
        }

        int k = Math.min(NUM_CLUSTERS, n);
        centroidMips = new double[k];
        centroidRam  = new double[k];

        // Fix 3: Random centroid initialisation from actual data points
        Random rand   = new Random(42);
        List<Integer> chosen = new ArrayList<Integer>();
        for (int c = 0; c < k; c++) {
            int pick;
            do { pick = rand.nextInt(n); } while (chosen.contains(pick));
            chosen.add(pick);
            centroidMips[c] = mipsData[pick];
            centroidRam[c]  = ramData[pick];
        }

        boolean changed = true;
        int iter = 0;

        while (changed && iter < MAX_ITERATIONS) {
            changed = false;
            iter++;

            // Fix 4 & 5: Assign ALL points first
            for (int i = 0; i < n; i++) {
                int nearest = nearestCentroid(mipsData[i], ramData[i], k);
                if (vmCluster[i] != nearest) {
                    vmCluster[i] = nearest;
                    changed = true;
                }
            }

            // Then update centroids from new assignments
            double[] sumMips = new double[k];
            double[] sumRam  = new double[k];
            int[]    count   = new int[k];

            for (int i = 0; i < n; i++) {
                int c = vmCluster[i];
                sumMips[c] += mipsData[i];
                sumRam[c]  += ramData[i];
                count[c]++;
            }

            for (int c = 0; c < k; c++) {
                if (count[c] > 0) {
                    centroidMips[c] = sumMips[c] / count[c];
                    centroidRam[c]  = sumRam[c]  / count[c];
                }
            }
        }
    }

    /** Euclidean distance in (MIPS, RAM) space */
    private int nearestCentroid(double mips, double ram, int k) {
        int    best     = 0;
        double bestDist = Double.MAX_VALUE;
        for (int c = 0; c < k; c++) {
            double dm   = mips - centroidMips[c];
            double dr   = ram  - centroidRam[c];
            double dist = Math.sqrt(dm * dm + dr * dr);
            if (dist < bestDist) {
                bestDist = dist;
                best     = c;
            }
        }
        return best;
    }

    /**
     * Returns MIPS for a VM.
     * Uses configuredMips (set from host machine speed via setVmMipsAndRam).
     * All VMs in the same DC share the same host speed in CA's model,
     * so configuredMips × getCpus() gives total MIPS per VM.
     */
    private double getVmMips(int vmId) {
        if (vmList != null) {
            for (int i = 0; i < vmList.size(); i++) {
                VirtualMachine vm = (VirtualMachine) vmList.get(i);
                if (vm.getVmId() == vmId) {
                    // MIPS = host processor speed × number of vCPUs
                    return configuredMips * vm.getCharacteristics().getCpus();
                }
            }
        }
        return configuredMips;
    }

    /**
     * Returns RAM for a VM from VMCharacteristics.
     * Falls back to configuredRam if VM not found.
     */
    private double getVmRam(int vmId) {
        if (vmList != null) {
            for (int i = 0; i < vmList.size(); i++) {
                VirtualMachine vm = (VirtualMachine) vmList.get(i);
                if (vm.getVmId() == vmId) {
                    return vm.getCharacteristics().getMemory();
                }
            }
        }
        return configuredRam;
    }

    @Override
    public void cloudSimEventFired(CloudSimEvent e) {
        if (e.getId() == CloudSimEvents.EVENT_CLOUDLET_ALLOCATED_TO_VM) {
            int vmId = (Integer) e.getParameter(Constants.PARAM_VM_ID);
            vmStatesList.put(vmId, VirtualMachineState.BUSY);
        } else if (e.getId() == CloudSimEvents.EVENT_VM_FINISHED_CLOUDLET) {
            int vmId = (Integer) e.getParameter(Constants.PARAM_VM_ID);
            vmStatesList.put(vmId, VirtualMachineState.AVAILABLE);
        }
    }
}
