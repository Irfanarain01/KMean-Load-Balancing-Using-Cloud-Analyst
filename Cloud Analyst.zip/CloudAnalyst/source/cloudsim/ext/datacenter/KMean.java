package cloudsim.ext.datacenter;

import java.util.*;

public class KMean {

    private static final int NUM_CLUSTERS = 2;    // Total clusters.
    private static final int TOTAL_DATA = 6;      // Total data points.

    private static ArrayList<Data> dataSet = new ArrayList<Data>();
    private static ArrayList<Centroid> centroids = new ArrayList<Centroid>();

    // Sample dataset (FIXED: previously only one point was provided)
    private static double SAMPLES[][] = new double[][] {
        {1, 2}, {1.5, 1.8}, {5, 8}, {8, 8}, {1, 0.6}, {9, 11}
    };

    private static void initialize() {
        System.out.println("Centroids initialized at:");
        centroids.add(new Centroid(1.0, 1.0)); // Cluster 0
        centroids.add(new Centroid(5.0, 7.0)); // Cluster 1
        System.out.println("     (" + centroids.get(0).X() + ", " + centroids.get(0).Y() + ")");
        System.out.println("     (" + centroids.get(1).X() + ", " + centroids.get(1).Y() + ")");
        System.out.print("\n");
    }

    private static void kMeanCluster() {
        final double bigNumber = Math.pow(10, 10);
        double minimum;
        double distance;
        int sampleNumber = 0;
        int cluster = 0;
        boolean isStillMoving = true;
        Data newData;

        // Step 1: Assign initial samples
        while (dataSet.size() < TOTAL_DATA) {
            newData = new Data(SAMPLES[sampleNumber][0], SAMPLES[sampleNumber][1]);
            dataSet.add(newData);
            minimum = bigNumber;

            for (int i = 0; i < NUM_CLUSTERS; i++) {
                distance = dist(newData, centroids.get(i));
                if (distance < minimum) {
                    minimum = distance;
                    cluster = i;
                }
            }
            newData.cluster(cluster);

            // Recalculate centroids
            for (int i = 0; i < NUM_CLUSTERS; i++) {
                double totalX = 0;
                double totalY = 0;
                int totalInCluster = 0;

                for (Data d : dataSet) {
                    if (d.cluster() == i) {
                        totalX += d.X();
                        totalY += d.Y();
                        totalInCluster++;
                    }
                }

                if (totalInCluster > 0) {
                    centroids.get(i).X(totalX / totalInCluster);
                    centroids.get(i).Y(totalY / totalInCluster);
                }
            }

            sampleNumber++;
        }

        // Step 2: Iterate until stable
        while (isStillMoving) {
            isStillMoving = false;

            for (int i = 0; i < NUM_CLUSTERS; i++) {
                double totalX = 0;
                double totalY = 0;
                int totalInCluster = 0;

                for (Data d : dataSet) {
                    if (d.cluster() == i) {
                        totalX += d.X();
                        totalY += d.Y();
                        totalInCluster++;
                    }
                }

                if (totalInCluster > 0) {
                    centroids.get(i).X(totalX / totalInCluster);
                    centroids.get(i).Y(totalY / totalInCluster);
                }
            }

            // Assign all data to the new centroids
            for (Data tempData : dataSet) {
                minimum = bigNumber;
                int newCluster = 0;

                for (int j = 0; j < NUM_CLUSTERS; j++) {
                    distance = dist(tempData, centroids.get(j));
                    if (distance < minimum) {
                        minimum = distance;
                        newCluster = j;
                    }
                }

                if (tempData.cluster() != newCluster) {
                    tempData.cluster(newCluster);
                    isStillMoving = true;
                }
            }
        }
    }

    private static double dist(Data d, Centroid c) {
        return Math.sqrt(Math.pow((c.Y() - d.Y()), 2) + Math.pow((c.X() - d.X()), 2));
    }

    private static class Data {
        private double mX = 0;
        private double mY = 0;
        private int mCluster = 0;

        public Data() {}

        public Data(double x, double y) {
            this.mX = x;
            this.mY = y;
        }

        public void X(double x) { this.mX = x; }
        public double X() { return this.mX; }

        public void Y(double y) { this.mY = y; }
        public double Y() { return this.mY; }

        public void cluster(int clusterNumber) { this.mCluster = clusterNumber; }
        public int cluster() { return this.mCluster; }
    }

    private static class Centroid {
        private double mX = 0.0;
        private double mY = 0.0;

        public Centroid() {}

        public Centroid(double newX, double newY) {
            this.mX = newX;
            this.mY = newY;
        }

        public void X(double newX) { this.mX = newX; }
        public double X() { return this.mX; }

        public void Y(double newY) { this.mY = newY; }
        public double Y() { return this.mY; }
    }

    public static void main(String[] args) {
        initialize();
        kMeanCluster();

        // Print clustering results
        for (int i = 0; i < NUM_CLUSTERS; i++) {
            System.out.println("Cluster " + i + " includes:");
            for (Data d : dataSet) {
                if (d.cluster() == i) {
                    System.out.println("     (" + d.X() + ", " + d.Y() + ")");
                }
            }
            System.out.println();
        }

        // Print final centroids
        System.out.println("Centroids finalized at:");
        for (int i = 0; i < NUM_CLUSTERS; i++) {
            System.out.println("     (" + centroids.get(i).X() + ", " + centroids.get(i).Y() + ")");
        }

        System.out.print("\n");
    }
}
